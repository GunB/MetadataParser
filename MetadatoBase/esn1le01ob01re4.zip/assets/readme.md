This folder is where the external product will be synced
