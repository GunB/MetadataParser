function product_lesson_model(obj)
{
    obj.started_writing_task = ko.observable(0);
    obj.windowHeight = ko.observable(window.innerHeight);
    obj.windowWidth = ko.observable(window.innerWidth);

    obj.sena_levels = ko.observableArray(["Beginner", "A1.1", "A1.2", "A2.1", "A2.2", "B1.1", "B1.2", "B1.3", "B2.1", "B2.2", "B2.3", "Mapped", "Stubs"]); //HRC
    obj.level_name = ko.observable("");
    obj.sena_lessons = ko.computed( function () {
        ret = [1];
        if(obj._data.level() == 'Beginner'){
            for(var i = 2, len = 6; i <= len; ++i){
                ret.push(i);
            }
        }
        else if(obj._data.level() == 'A1.1'){
            for(var i = 2, len = 9; i <= len; ++i){
                ret.push(i);
            }
        }
        else if(obj._data.level() == 'A1.2'){
            for(var i = 2, len = 9; i <= len; ++i){
                ret.push(i);
            }
        }
        else if(obj._data.level() == 'A2.1'){
            for(var i = 2, len = 18; i <= len; ++i){
                ret.push(i);
            }
        }
        else if(obj._data.level() == 'A2.2'){
            for(var i = 2, len = 18; i <= len; ++i){
                ret.push(i);
            }
        }
        else if(obj._data.level() == 'B1.1'){
            for(var i = 2, len = 23; i <= len; ++i){
                ret.push(i);
            }
        }
        else if(obj._data.level() == 'B1.2'){
            for(var i = 2, len = 23; i <= len; ++i){
                ret.push(i);
            }
        }
        else if(obj._data.level() == 'B1.3'){
            for(var i = 2, len = 24; i <= len; ++i){
                ret.push(i);
            }
        }
        else if(obj._data.level() == 'B2.1'){
            for(var i = 2, len = 32; i <= len; ++i){
                ret.push(i);
            }
        }
        else if(obj._data.level() == 'B2.2'){
            for(var i = 2, len = 32; i <= len; ++i){
                ret.push(i);
            }
        }
        else if(obj._data.level() == 'B2.3'){
            for(var i = 2, len = 31; i <= len; ++i){
                ret.push(i);
            }
        }
        return ret;
    });
    obj.lesson_position = ko.observableArray([1,2,3,4,5,6,7,8,9,10,11,12]); //HRC

    obj.lab_types = ko.observableArray(["act", "scholar", "stm", "oed"]);
    obj.exercise_types = ko.observableArray(["ATA","CAS","CHW","CWD", "DFL", "DMC", "DWS", "ELS", "FLC", "GIW", "GWR", "HNG", "KAR", "MCH", "MF1", "MFL", "MMC", "MMM", "MRW", "MT1", "oea", "PRP", "REC", "rslt", "RSLT", "SFG", "SFL", "SLS", "SLW", "SLWG", "SMC", "SPK", "SR1", "STI", "stm", "TAB", "TTT", "TYP", "WDS", "WLC", "WSB"]);
    obj.question_types = ko.observableArray(["audio", "image", "image-lg", "image-md","image-sm", "pdf", "text", "rec"]);
    obj.no_image_question_types = ko.observableArray(["audio","image", "pdf", "text", "rec"]);
    obj.audio_text_question_types = ko.observableArray(["audio","text"]);
    obj.text_question_types = ko.observableArray(["text"]);
    obj.basic_question_types = ko.observableArray(["audio", "image", "text", "video", "image-lg", "image-md","image-sm", "rec"]);
    obj.basic_question_types_no_rec = ko.observableArray(["audio", "image", "text", "video", "image-lg", "image-md","image-sm"]);
    obj.sfg_question_types = ko.observableArray(["group","text","rec"]); 
    obj.kar_question_types = ko.observableArray(["video","text","rec"]); 
    obj.sls_question_types = ko.observableArray(["text", "rec"]);
    obj.stimulus_types = ko.observableArray(["audio", "static", "stm", "text", "welcome", "video"]);
    obj.audio_stimulus_types = ko.observableArray(["img", "ol", "p", "picture", "slideshow", "ul"]);
    obj.video_stimulus_types = ko.observableArray(["img", "ol", "p", "picture", "ul", "video"]);
    obj.static_stimulus_types = ko.observableArray(["img", "ol", "p", "ul"]);
    obj.text_stimulus_types = ko.observableArray(["img", "p", "thumbnail", "title"]);
    obj.instruction_types = ko.observableArray(["audio", "image", "thumbnail", "table", "text", "image-lg", "image-md","image-sm","video"]);
    obj.response_types = ko.observableArray(["audio", "image", "text", "image-lg", "image-md","image-sm"]);
    obj.welcome_types = ko.observableArray(["Learning Outcomes", "Free Header Item"]);
    obj.cell_types = ko.observableArray(["image","text"]);
    obj.achievement_types = ko.observableArray(["instructions"]);
    obj.pre_quiz_type = ko.observableArray(["pre_quiz"]);
    obj.feedback = localize_json.framework_feedback;
    obj.disabled_submit_exes = ko.observableArray(["WLC","RSLT","DWS", "SPK", "STI","ATA","TTT","MCH"]);
    obj.group_types_sans_objs = ko.observableArray(["Welcome", "Content", "Take Away"]); //sorry Rob, will reevaluate in code audit! KT
    obj.exercise_group_types = ko.observableArray([{'group':'Welcome', 'limit': 2, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Let's Start!"},{'group':'Content', 'limit': 10, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Let's Explore!"},{'group':'Activity 1', 'limit': 1, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Let's Practice!"},{'group':'Activity 2', 'limit': 1, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Let's Practice!"},{'group':'Activity 3', 'limit': 1, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Let's Practice!"},{'group':'Quiz', 'limit': 100, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Check Your Progress!"},{'group':'Take Away', 'limit': 1, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Takeaway"}]);
    obj.disabled_lockout_exes = ko.observableArray(["SPK"]);
    obj.test_options = ko.observableArray(["true", "false"]);
    
    //Achievement Test only 
    if (obj._data.test() == 'true')
    {
        //The final score of the test
        obj.AT_score = ko.observable(-1);
        //Whether the test has been completed or not, used to disable the group bar
        obj.finished_test = ko.observable(false);
        //Recreate array without Content, since that group will have graded exercises
        obj.group_types_sans_objs = ko.observableArray(["Welcome", "Results"]);
        
        obj.min_AT_question = ko.observable(1);
        obj.max_AT_questions = ko.observable(1);
        
        //Re-create the group array with different values
        obj.exercise_group_types = ko.observableArray([{'group':'Welcome', 'limit': 1, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Start Test"},{'group':'Activity 1', 'limit': 1, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Questions"},{'group':'Activity 2', 'limit': 1, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Questions"},{'group':'Activity 3', 'limit': 1, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Questions"},{'group':'Activity 4', 'limit': 1, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Questions"},{'group':'Activity 5', 'limit': 1, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Questions"},{'group':'Results', 'limit': 1, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": "Result"},{'group':'None', 'limit': 100, 'count': ko.observable(0), "exercises": ko.observableArray([]), "group_selected_exercise_idx": ko.observable(0), "heading": ""}]);
        
        /*
            Will go through the AT groups exercise and check to see if all the questions have been answered. 
            If all questions have been answered it will return true, and false if not. This function is used
            on the AT group bar to change the background image of the item accordingly.
            @group_id = The exercise group ID to check.
        */
        obj.achievement_group_answered = function(group_id)
        {
            var ret = true;

            //Make sure there is a exercise in the group before checking the array
            if (obj.exercise_group_types()[group_id].exercises().length > 0)
            {
                for (var i = 0; i < obj.exercise_group_types()[group_id].exercises().length; ++i)
                {
                    //If all the questions haven't been answered, then don't change the group bar state
                    if (obj.labs()[obj.selected_lab()].exercises()[obj.exercise_group_types()[group_id].exercises()[i]].cur_question() != -1)
                        ret = false;
                }
            }
            
            if (obj.finished_test())
                ret = false;
            
            return ret;
        }

        /*
            Returns the final test score for the test. Will go through. each exercise and score them.
            Called when the test is being submitted.
        */
        obj.calc_achievement_test_score = function()
        {
            //Make sure score is 0 before doing any math to it
            obj.AT_score(0);
            
            //Loop through all the groups and check the answers and calculate the score
            //-2 to skip grading the results and the none group. There will be nothing on these groups to check
            for (var i = 0, i_len = obj.exercise_group_types().length; i < i_len; ++i)
            {
                //Make sure the current group is a group that needs to be scored
                if (obj.exercise_group_types()[i].group != "Welcome" && obj.exercise_group_types()[i].group != "Results" && obj.exercise_group_types()[i].group != "None")
                {
                    for (var k = 0, k_len = obj.exercise_group_types()[i].exercises().length; k < k_len; ++k)
                    {
                        //Calculate the score for the questions
                        obj.labs()[obj.selected_lab()].exercises()[viewModel.exercise_group_types()[i].exercises()[k]].check_answers(); 
                        
                        //Go through each question and add the score to an ongoing total
                        for(var q = 0, q_len = obj.labs()[obj.selected_lab()].exercises()[viewModel.exercise_group_types()[i].exercises()[k]].questions().length; q < q_len; ++q)
                            obj.AT_score(obj.AT_score() + obj.labs()[obj.selected_lab()].exercises()[viewModel.exercise_group_types()[i].exercises()[k]].questions()[q].score())
                    }
                }
            }

            //Scorm stuff, we have completed the test
            for(var i = 0; i < obj.global_objectives_array().length; ++i){
                if(obj.global_objectives_array()[i].name == 'primary')
                    obj.global_objectives_array()[i].completed("completed");
            }  

            //Divide the score by the total amount of questions
            obj.AT_score(Math.round(obj.AT_score() / obj.max_AT_questions()));
            //Test has now been finished
            obj.finished_test(true);
            
            //Make sure score gets set with scorm stuff
            obj.labs()[obj.selected_lab()].do_progress_actions();
            if(initialized)
                product_save_scorm_interactions();
            
            //Go to the results page
            viewModel.labs()[viewModel.selected_lab()].change_group(6);
        }
        
        /*
            Checks to see if all exercises in the test have been fully answered or not.
            Used to see if the submit button should be enabled or disabled.
        */
        obj.show_achievement_test_submit = ko.computed( function()
        {
            var ret = true;
            
            //Start at 1 to skip the welcome page, Use 2 to skip the results page and the none group at the end
            for (var i = 1; i < obj.exercise_group_types().length - 2; ++i)
            {
                //If the exercise group hasn't been fully completed then then submit button should not be enabled
                if (obj.achievement_group_answered(i) == false)
                {
                    ret = false;
                    break;
                }
            }
            
            return ret;
        });
        
        /*
            Moves to the next exercise in the group. If it's at the end of the group, it will move to
            the next group. Gets called on the forward sub navigation button.
        */
        obj.next_exercise = function()
        {
            //If the current exercise in group is not the last exercise in the group, then switch to the next one
            if (obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].group_selected_exercise_idx() + 1 < obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].count())
            {
                obj.set_group_selected_exercise(obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].group_selected_exercise_idx() + 1);
                product_select_exercise(obj.labs()[obj.selected_lab()], obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].exercises()[obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].group_selected_exercise_idx()]);
            }
            else //Currently at the last exercise in the group, so go to the next group
                obj.labs()[obj.selected_lab()].change_group(obj.labs()[obj.selected_lab()].selected_group() + 1);
       
        }
        
        /*
            Moves to the previous exercise in group. If at the start of a group, it will move to the
            previous group. Gets called on the backwards sub navigation button.
        */
        obj.previous_exercise = function()
        {
            //If the current exercise in group is not the last exercise in the group, then switch to the next one
            if (obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].count() > 1 && obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].group_selected_exercise_idx() >= obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].count() - 1)
            {
                obj.set_group_selected_exercise(obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].group_selected_exercise_idx() - 1);
                product_select_exercise(obj.labs()[obj.selected_lab()], obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].exercises()[obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].group_selected_exercise_idx()]);
            }
            else //Currently at the last exercise in the group, so go to the next group
                obj.labs()[obj.selected_lab()].change_group(obj.labs()[obj.selected_lab()].selected_group() - 1);
        }
        
        /*
            Checks to see if the current exercise is the very first exercise in the first group.
            Used to disable the the navigation from looping.
        */
        obj.at_achievement_start = ko.computed(function()
        {
            var ret = false;

            if (obj.labs()[obj.selected_lab()].selected_group() == 1)
            {
                if (obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].group_selected_exercise_idx() >= obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].count() - 1)
                    ret = false;
                else
                    ret = true;
            }
            
            return ret;
        });
        
        /*
            Checks to see if the current exercise is the last gradeable exercise.
            Used to disabled the navigation from looping and moving forward past the end.
        */
        obj.at_achievement_end = ko.computed(function()
        {
            var ret = false;
            
            //-3 to ignore the RSLT and None group at the end
            if (obj.labs()[obj.selected_lab()].selected_group() == obj.exercise_group_types().length - 3)
                ret = true;
            
            return ret;
        });
        
        /*
            Returns the string of what exercise # the user is currently on.
        */
        obj.get_navigation_string = ko.computed(function()
        {
            var ret = " of ";
            var current_num = 1;

            //Loop through all the groups to get a proper count
            for (var i = 1; i < obj.exercise_group_types().length - 2; ++i)
            {
                //Check to see if we have hit the current group, so we can stop adding 
                if (i <= obj.labs()[obj.selected_lab()].selected_group())
                {
                    //If there are multiple exercises in the group, don't add the entire list. Just add to what exercise we are on
                    if (obj.exercise_group_types()[i].count() > 1 && i == obj.labs()[obj.selected_lab()].selected_group())
                        current_num += (obj.exercise_group_types()[i].exercises().indexOf(obj.exercise_group_types()[i].group_selected_exercise_idx()) + 1);
                    else if (obj.exercise_group_types()[i].count() == 1 && i == obj.labs()[obj.selected_lab()].selected_group())
                        current_num += obj.exercise_group_types()[i].count() - 1;
                    else //Only 1 exercise, so just add the count
                        current_num += obj.exercise_group_types()[i].count();
                }
            }
            
            //Return the final string. -2 to remove WLC and RSLT from the count
            return current_num + ret + (obj.labs()[obj.selected_lab()].exercises().length - 2);
        });
        
        /*
            Gets the amount of questions on the group in relation to previous groups
            and displays it on the group bar.
            @group = The current group index.
        */
        obj.get_group_questions = function(group)
        {
            var question_min = 1;
            var question_max = 0;

            //Loop through all the groups to get a proper count
            for (var i = 1; i < obj.exercise_group_types().length - 2; ++i)
            {
                if (obj.exercise_group_types()[i].exercises().length > 0)
                {
                    //Check to see if we have hit the current group, so we can stop adding 
                    if (i < group)
                        question_min += obj.labs()[obj.selected_lab()].exercises()[obj.exercise_group_types()[i].exercises()[0]].questions().length;
                    else if (i == group)
                    {
                        //Set the max before we add the current exercise questions to it
                        question_max = question_min;
                        
                        //Only add if there are more than 1 question
                        if (obj.labs()[obj.selected_lab()].exercises()[obj.exercise_group_types()[i].exercises()[0]].questions().length > 1)
                            question_max += (obj.labs()[obj.selected_lab()].exercises()[obj.exercise_group_types()[i].exercises()[0]].questions().length - 1);
                    }
                }
            }
            
            //Set the total amount of questions, to be used in score calculation
            obj.max_AT_questions(question_max);
            
            //Return the final string with both numbers
            return question_min + ' - ' + question_max;
        };
        
        /*
            Gets called when you switch exercises. Will calculate what the minimum question
            number should be in relation to the previous groups and exercises.
            @group = The current selected group.
        */
        obj.get_exercise_start_question = function(group)
        {
            var question_min = 1;

            //Loop through all the groups to get a proper count
            for (var i = 1; i < obj.exercise_group_types().length - 2; ++i)
            {
                if (obj.exercise_group_types()[i].exercises().length > 0)
                {
                    //Check to see if we have hit the current group, so we can stop adding 
                    if (i < group)
                        question_min += obj.labs()[obj.selected_lab()].exercises()[obj.exercise_group_types()[i].exercises()[0]].questions().length;
                }
            }
            
            //Return the final string with both numbers
            obj.min_AT_question(question_min);
        }
    }

    obj.level_name =  ko.computed( function () {
        var name = '';
        if(obj._data.level() == 'Beginner'){
            name = 'Pre A1 Pre-starter';
        }
        else if(obj._data.level() == 'A1.1'){
            name = 'A1.1 Starter';
        }
        else if(obj._data.level() == 'A1.2'){
            name = 'A1.2 Starter';
        }
        else if(obj._data.level() == 'A2.1'){
            name = 'A2.1 Elementary';
        }
        else if(obj._data.level() == 'A2.2'){
            name = 'A2.2 Elementary';
        }
        else if(obj._data.level() == 'B1.1'){
            name = 'B1.1 Pre-intermediate';
        }
        else if(obj._data.level() == 'B1.2'){
            name = 'B1.2 Pre-intermediate';
        }
        else if(obj._data.level() == 'B1.3'){
            name = 'B1.3 Intermediate';
        }
        else if(obj._data.level() == 'B2.1'){
            name = 'B2.1 Intermediate';
        }
        else if(obj._data.level() == 'B2.2'){
            name = 'B2.2 Upper intermediate';
        }
        else if(obj._data.level() == 'B2.3'){
            name = 'B2.3 Upper intermediate';
        }
        return name;
    });

    obj.get_group_selected_exercise = function(){
        return obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].group_selected_exercise_idx();
    }

    obj.set_group_selected_exercise = function(idx){
        //Update value in the exercise_group_types array for progress
        obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].group_selected_exercise_idx(idx);
        //Update observable on the lab layer for UI
        obj.labs()[obj.selected_lab()].selected_group_current_exercise_idx(idx);
    }
    obj.number_of_sco_groups = ko.computed(function(){
        var group_count = 0;
        for(var i = 0; i < obj.exercise_group_types().length; ++i)
        {
            if(obj.exercise_group_types()[i].count() > 0){
                group_count += 1;
            }
        }
        return group_count;
    });
    obj.passing_grade = ko.observable(70);
    obj.selected_group_name = ko.computed(function(){
        var group_name = obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].group;
        return group_name;

    });
    obj.is_group_sans_objs = ko.computed(function(){
        for(var g = 0; g<obj.group_types_sans_objs().length; ++g){
            if(obj.selected_group_name() == obj.group_types_sans_objs()[g]){
                return true;
            }
        }
        return false;
    });
    obj.has_quiz = ko.computed(function(){
        for(var g = 0; g<obj.exercise_group_types().length; ++g){
            if(obj.exercise_group_types()[g].group == 'Quiz' && obj.exercise_group_types()[g].count()>0){
                return true;
            }
        }
        return false;
    });

    obj.at_group_start = ko.computed(function(){
        if(obj.labs()[obj.selected_lab()].selected_group_current_exercise_idx() == 0){
            return true;
        }
        return false;
    });
    obj.at_group_end = ko.computed(function(){
        //Different for quiz because it has the result page which you don't want to be included
        if(obj.selected_group_name() == 'Quiz'){
            if(obj.labs()[obj.selected_lab()].selected_group_current_exercise_idx() == (obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].exercises().length-2)){
                return true;
            }
        }
        else{
            if(obj.labs()[obj.selected_lab()].selected_group_current_exercise_idx() == (obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].exercises().length-1)){
                return true;
            }
        }
        return false; //If it doesn't hit a true then it must be false :)
    });

    obj.check_if_group_disabled = function(group)
    {
        if(obj.exercise_group_types()[obj.labs()[obj.selected_lab()].selected_group()].group == group)
            return true;
        else
            return false;       
    }

    obj.global_objectives_array = ko.observableArray([]);
    obj.map_objectives_to_group = function()
    {
        //console.log("get to objective mapping");
        ////log(obj._data().length);
        for(var i=0; i < obj._data().length; ++i){
            ////log(obj._data()[i].type());
            if(obj._data()[i].type() == "objectives"){
                ////log("has objs");
                for(var j=0;j<obj._data()[i].contents().length;++j){
                    //if(obj._data()[i].contents()[j].type !== "primary"){
                    obj.global_objectives_array.push({"name": obj._data()[i].contents()[j].type(), "group": "", "description":obj._data()[i].contents()[j].content()});
                    //}
                    ////log(obj._data()[i].contents()[j].type());
                }
            }
        }

        //Empty objective arrays in case no objectives exist for these groups
		// don't push any objectives for dr127 anymore
/*         if(obj.number_of_sco_groups()>1){
            obj.global_objectives_array.push({"name": 'welcome', "group": "Welcome", "description": "Welcome"});
            obj.global_objectives_array.push({"name": 'content', "group": "Content", "description": "Content"});
            obj.global_objectives_array.push({"name": 'take_away', "group": "Take Away", "description": "Take Away"});
        }
        else{
            for(var i = 0; i<obj.exercise_group_types().length;++i){
                if(obj.exercise_group_types()[i].count()>0){
                    if(obj.exercise_group_types()[i].group == "Welcome"){
                        obj.global_objectives_array.push({"name": 'welcome', "group": "Welcome", "description": "Welcome"});
                    }
                    else if(obj.exercise_group_types()[i].group == "Content"){
                        obj.global_objectives_array.push({"name": 'content', "group": "Content", "description": "Content"});
                    }
                    else if(obj.exercise_group_types()[i].group == "Take Away"){
                        obj.global_objectives_array.push({"name": 'take_away', "group": "Take Away", "description": "Take Away"});
                    }
                }
            }
        } */
        

        for(var i=0; i<obj.exercise_group_types().length; ++i){
            ////log(obj.exercise_group_types()[i]);
            for(var j=0; j<obj.exercise_group_types()[i].exercises().length; ++j){
                ////log(obj.exercise_group_types()[i].exercises()[j]);
                for(var q=0; q<obj.labs()[obj.selected_lab()].exercises()[obj.exercise_group_types()[i].exercises()[j]].questions().length;++q){
                    ////log(obj.labs()[obj.selected_lab()].exercises()[obj.exercise_group_types()[i].exercises()[j]].questions()[q]);
                    for(var q_d=0; q_d<obj.labs()[obj.selected_lab()].exercises()[obj.exercise_group_types()[i].exercises()[j]].questions()[q]._data().length;++q_d){
                        if(obj.labs()[obj.selected_lab()].exercises()[obj.exercise_group_types()[i].exercises()[j]].questions()[q]._data()[q_d].type() == "objective"){
                            for(var k=0; k<obj.global_objectives_array().length;++k){
                                ////log('name: '+ obj.global_objectives_array()[k].name + ' content: '+ obj.labs()[obj.selected_lab()].exercises()[obj.exercise_group_types()[i].exercises()[j]].questions()[q]._data()[q_d].content() + ' content: '+ obj.exercise_group_types()[i].group);
                                if(obj.global_objectives_array()[k].name == obj.labs()[obj.selected_lab()].exercises()[obj.exercise_group_types()[i].exercises()[j]].questions()[q]._data()[q_d].content()){
                                    obj.global_objectives_array()[k].group = obj.exercise_group_types()[i].group;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }


        //match on regex secondary for calculated scores, else just create observables
        //welcome/content/takeaway no longer has objectives
        for(var i = 0; i<obj.global_objectives_array().length; ++i){
            var name = obj.global_objectives_array()[i].name;
            if(name.match(/secondary_/)){
                
                obj.global_objectives_array()[i].score = ko.computed(function(){
                    var obj= this;
                    var score_total = 0;
                    var score_count = 0;
                    for(var g = 0; g<viewModel.exercise_group_types().length; ++g){
                        if(obj.group == viewModel.exercise_group_types()[g].group){
                            for(var g_e = 0; g_e<viewModel.exercise_group_types()[g].exercises().length;++g_e){
                                if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].feedback_showing_answer()){
                                    score_total = 0;
                                    score_count = 1;
                                }
                                else if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions().length){
                                    for(var q = 0; q<viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions().length;++q){
                                        for(var d = 0; d<viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions()[q]._data().length; ++d){
                                            if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions()[q]._data()[d].type() == "objective"){
                                                if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions()[q]._data()[d].content() == obj.name){
                                                    score_total += viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions()[q].score();
                                                    score_count += 1;
                                                }
                                            }
                                        }
                                    }
                                }
                                else{
                                    //log("I have no questions");
                                    score_total = 100;
                                    score_count = 1;
                                }
                            }
                        }
                    }
                    return (score_total+0.0)/(score_count+0.0);
                }, obj.global_objectives_array()[i]);
                
                obj.global_objectives_array()[i].satisfied = ko.observable("failed");
                
                obj.global_objectives_array()[i].completed = ko.computed(function(){
                    var obj= this;
                    var attemped = 0;
                    var completed = 1;
                    var checked_answer = 1;
                    var feedback_showing_answer = 0;
                    for(var g = 0; g<viewModel.exercise_group_types().length; ++g){
                        if(obj.group == viewModel.exercise_group_types()[g].group){
                            for(var g_e = 0; g_e<viewModel.exercise_group_types()[g].exercises().length;++g_e){
                                if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].feedback_showing_answer()){
                                    feedback_showing_answer = 1;
                                }
                                if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions().length){
                                    for(var q = 0; q<viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions().length;++q){
                                        for(var d = 0; d<viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions()[q]._data().length; ++d){
                                            if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions()[q]._data()[d].type() == "objective"){
                                                if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions()[q]._data()[d].content() == obj.name){
                                                    ////log(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].checked_answer());
                                                    if(!(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].checked_answer() && checked_answer)){
                                                        checked_answer = 0;
                                                    }
                                                    if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions()[q].state()||attemped){
                                                        attemped = 1;
                                                        if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions()[q].state()==1 || viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.exercise_group_types()[g].exercises()[g_e]].questions()[q].state()==0){
                                                            completed = 0;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    ////log(obj.name + ': '+ checked_answer);
                    if(attemped){
                        if(completed || feedback_showing_answer){
                            if(checked_answer || feedback_showing_answer){
								if (obj.group === 'Quiz') {
									if (obj.score() === 100) { // score must be 100 if it is quiz ex to satisfy
										obj.satisfied("passed");
										return "completed";
									}
								} else {
									obj.satisfied("passed");
									return "completed";
								}
                            }
                            return "incomplete";
                        }
                        else if(checked_answer){//Comment this if out if you want them to only pass when they are complete
                            obj.satisfied("passed");
                            //log("in second if");
                        }
                        return "incomplete";
                    }
                    else{
                        return "not attempted";
                    }
                }, obj.global_objectives_array()[i]);

                obj.global_objectives_array()[i].score_scaled = ko.computed(function(){
                    var obj = this;
                    return Math.round((obj.score()/100)*100)/100;
                }, obj.global_objectives_array()[i]);
            }      
            
            else if(obj.global_objectives_array()[i].name != "primary"){
                //log("I'm not secondary, or primary, I'm: " + obj.global_objectives_array()[i].name);
                obj.global_objectives_array()[i].score = ko.observable(0);
                obj.global_objectives_array()[i].satisfied = ko.observable("failed");
                obj.global_objectives_array()[i].completed = ko.observable("not attempted");
                obj.global_objectives_array()[i].score_scaled = ko.computed(function(){
                    var obj = this;
                    return Math.round((obj.score()/100)*100)/100;
                }, obj.global_objectives_array()[i]);
            }
        }

        for(var i = 0; i<obj.global_objectives_array().length; ++i){
            if(obj.global_objectives_array()[i].name == "primary"){
                
                if(obj.has_quiz() || obj._data.test() == 'true'){
                    //log("I have quiz and set score to computed and others to observables");

                    //Returns the score of the quiz if there's a quiz
                    obj.global_objectives_array()[i].score = ko.computed(function(){
                        var ret = obj.labs()[obj.selected_lab()].quiz_score();
                        
                        if (obj._data.test() == 'true')
                            ret = obj.AT_score();
                        
                        return ret;
                    });
                    
                    //Set to passed when submit button for quiz is hit
					obj.global_objectives_array()[i].satisfied = ko.computed(function(){
                        var obj = this;

                        if(obj.score()<80){
                            return "failed";
                        }
                        else{
                            return "passed";
                        }
                    },obj.global_objectives_array()[i]);
					
                    //Set to complete when quiz button is hit
                    obj.global_objectives_array()[i].completed = ko.observable("not attempted");
                }
                else{
                    //log("I have no quiz and everything is computeds");
                    //This takes the average of the secondary scores, which isn't good because it might overlap questions, but I don't know what they want me to do
                    obj.global_objectives_array()[i].score = ko.computed(function(){ 
                        var score = 0;
                        var score_count = 0;
                        for(var i = 0; i<obj.global_objectives_array().length; ++i){
                            if(obj.global_objectives_array()[i].name != "primary"){
                                score += obj.global_objectives_array()[i].score();
                                score_count += 1;
                            }
                        }
                        return (score+0.0)/(score_count+0.0);
                    });
                    
                    //If all sec's are passed then passed, otherwise not passed
                    obj.global_objectives_array()[i].satisfied = ko.computed(function(){
                        for(var i=0; i<viewModel.global_objectives_array().length; ++i){
                            if(viewModel.global_objectives_array()[i].name != "primary"){
                                if(viewModel.global_objectives_array()[i].satisfied() == "failed"){
                                    return "failed";
                                }
                            }
                        }
                        return "passed";
                    });

                    //If all sec's are completed then completed, if all sec's not attempted then not attempted
                    obj.global_objectives_array()[i].completed = ko.computed(function(){
                        var obj= this;
                        var total_obj_count = 0;
                        var no_attempt_count= 0;
                        var completed_count = 0;
                        for(var i=0; i<viewModel.global_objectives_array().length; ++i){
                            if(viewModel.global_objectives_array()[i].name != "primary"){
                                if(viewModel.global_objectives_array()[i].completed() == "not attempted"){
                                    no_attempt_count += 1;
                                }
                                else if(viewModel.global_objectives_array()[i].completed() == "completed"){
                                    completed_count += 1;
                                }
                                total_obj_count += 1;
                            }
                        }
                        if(no_attempt_count == total_obj_count){
                            return "not attempted";
                        }
                        else if(completed_count == total_obj_count){
                            return "completed";
                        }
                        else{
                            return "incomplete";
                        }
                    }, obj.global_objectives_array()[i]);
                }

                //Scaled score is the same whether it has a quiz or not
                obj.global_objectives_array()[i].score_scaled = ko.computed(function(){
                    var obj = this;
                    return Math.round((obj.score()/100)*100)/100;
                }, obj.global_objectives_array()[i]);
            }
            break;
        }
    }

    //Array of question info that needs to be sent to scorm, this info is in a model on the question layer
    obj.scorm_questions = ko.observableArray([]);
    

    obj.background_image = ko.observable();
    obj.selected_target_word = ko.observable("");
    obj.use_slide_transition = ko.observable(false);
    obj.sfx_on = ko.observable(true);

    obj.flash_fallback = ko.observable(false);
    obj.is_in_animation = ko.observable(false);
    obj.flipWelcomePanel = function (wlc_to,progress_restore) { // called when going to/from wlc
        var flipper = $('.flipper');
        var back = $('.flip-back');
        var front = $('.flip-front');
        if(detectIE()) { // IE will not flip. Fade instead.
            if (wlc_to) { // wlc to other
                back.css('opacity', '0');
                front.fadeTo(400, 0, function () {
                    back.addClass('ie-wlc-transit');
                    back.fadeTo(400, 1);
                }); 
            } else { // back to wlc
                back.fadeTo(400, 0, function () {
                    back.removeClass('ie-wlc-transit');
                    front.fadeTo(400, 1);
                });
            }
            if(typeof progress_restore !== 'undefined' && progress_restore == true)
            {
                back.css('opacity', '0');
                front.fadeTo(400, 0, function () {
                    back.addClass('ie-wlc-transit');
                    back.fadeTo(400, 1);
                }); 
                obj.labs()[obj.selected_lab()].change_group(obj.labs()[obj.selected_lab()].selected_group());
            }
            race_condition_ended = true;
        } else {
            flipper.one('transitionend', function () {
                viewModel.use_slide_transition(false);
                if(typeof progress_restore !== 'undefined' && progress_restore == true)
                {
                    obj.labs()[obj.selected_lab()].change_group(obj.labs()[obj.selected_lab()].selected_group());
                }
                viewModel.use_slide_transition(true);
                obj.is_in_animation(false);
                product_helper_fire_resize_events();
                race_condition_ended = true;
            }); 
            if (!obj.is_in_animation()) {
                obj.is_in_animation(true);
                flipper.toggleClass('flip');
            }
        }
        
            viewModel.init_tool_tip(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()]._data(), false);
            if (viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].stimuli_ids().length > 0)
                viewModel.init_tool_tip(viewModel.labs()[viewModel.selected_lab()].stimuli()[viewModel.labs()[viewModel.selected_lab()].selected_stimuli()]._data(), true);
        }

    //edit decoupled here
    if(is_editable)
    {
        product_edit_lesson_model(obj);
        edit_lesson_model(obj);
    }

    obj.planner_completed = ko.computed( function () {//PS
        var ret = true;
        var completed_planner = '';
        if(obj.labs().length > 1 && obj.labs()[2].type() == "oed")//we know were on writing  
        {
            for (var i = 0; i < obj.labs()[2].exercises()[0].questions().length; ++i)
            {
                if(obj.labs()[2].exercises()[0].questions()[i].responses()[0].text() == '')
                {
                    ret = false;
                    break;
                }
                completed_planner += obj.labs()[2].exercises()[0].questions()[i].responses()[0].text();
            }
            if(ret)
            {
                obj.labs()[3].exercises()[0].questions()[1].responses()[0].text(completed_planner);
                obj.labs()[3].disabled(false);                
            }
            else
            {
                obj.labs()[3].disabled(true);
            }
        }
        return ret;
    });
    
    //Returns whether or not to show the exercise controls at the bottom
    obj.show_nav = function()
    {
        var ret = true;
        
        //Return false if it's an achievement test and on the welcome page
        if (obj._data.test() == 'true' && obj.labs()[obj.selected_lab()].selected_exercise() == 0)
            ret = false;
            
        return ret;
    }
    
    //Check for achievement test
    if(obj._data.test() == 'true')
        //Make sure the results page doesn't show up in the exercise counter
        obj.labs()[0].max_exercises(obj.labs()[0].exercises().length - 2);
        
    obj.show_grading_chart = function(id){
        $('#grading_chart_'+id).modal();
    };
    
    obj.hide_grading_chart = function(id){
        $('#grading_chart_'+id).modal('hide');
    };

    obj.has_rec = ko.observable(false);
    for(var l = 0, len = obj.labs().length; l < len; ++l){
        for(var e = 0, een = obj.labs()[l].exercises().length; e < een; ++e){
            for (var k = 0; k < obj.labs()[l].exercises()[e]._data().length; ++k)
            {
                if (obj.labs()[l].exercises()[e]._data()[k].type() == "speech_record" && obj.labs()[l].exercises()[e]._data()[k].content() == true || obj.labs()[l].exercises()[e].get_rec_question() != -1)
                {
                    obj.has_rec(true);
                    break;
                }
            }
        }
    }

    if(obj.has_rec()){
        if(rec_request_mic_connection()){
            obj.flash_fallback(false);
            // //log("chrome/firefox");
            // //log(obj.flash_fallback());
        }
        else if(!isMobileSafari()){
            obj.flash_initialized = ko.observable(false);
            obj.flash_has_mic = ko.observable(true);
            obj.flash_fallback(true);
            // //log("IE/safari");
            // //log(obj.flash_fallback());
        }
    }

    obj.has_background_image = ko.computed(function(){
        var ret = 0;
        for( var i = 0, i_len = obj._data().length; i < i_len; ++i )
        {              
            if(obj._data()[i].type() == "background_image")
            {
                if(obj._data()[i].content() != "")
                {
                    ret = 1;
                }
                else if(obj._data()[i].content() == "")
                {
                    ret = -1;
                }
            }
        }  
        return ret;   
    });

    obj.is_ipad = function () {
        return (isMobileSafari() === null ? false : true)
    }
    
    obj.recording_allowed = ko.computed(function(){
        if(typeof recorder() === 'undefined'){
            return false; 
        } else {
            return true;
        }
    });
        
    //List of the different tss types
    obj.tss_types = ko.observableArray(['tssL', 'tssM', 'tssR']);
    //obj.tss_types = ko.observableArray(['Article', 'Lecture', 'Conversation']);
    obj.load_tss = function() {
        //Loop through the exercises to get the tss stimuli
        for(var l = 0, len = obj.labs().length; l < len; ++l)
        {
            //Make sure the tss array is empty
            obj.labs()[l].tss_stimuli = ko.observableArray([]);
            
            for(var e = 0, t_len = obj.labs()[l].exercises().length; e < t_len; ++e)
            {
                if (obj.labs()[l].exercises()[e].stimuli_ids().length > 1)
                {
                    for (var s = 0; s < obj.labs()[l].exercises()[e].stimuli_ids().length; ++s)
                    {
                        for(var x = 0, x_len = obj.labs()[l].stimuli().length; x<x_len;++x){
                            if(obj.labs()[l].stimuli()[x].id() == obj.labs()[l].exercises()[e].stimuli_ids()[s]){
                                obj.labs()[l].stimuli()[x].local_type(helper_get_local_string('tssI'+ obj.labs()[l].stimuli()[x].title()+'stm'));
                                obj.labs()[l].tss_stimuli.push(obj.labs()[l].stimuli()[x]);
                            }
                        }
                    }
                    break;
                }
            }
        }
        
        //Check to see if user is in edit mode
        if (obj.labs()[0].selected_exercise() > 0)
        {
            //Get the current exercise number
            var t = obj.labs()[0].selected_exercise();
            //Quickly switch to another lab and then return. Required to properly display
            //the tss selectors without having to manually switch labs
            obj.labs()[0].select_exercise(0);
            obj.labs()[0].select_exercise(t);
        }
    }

    obj.is_fullscreen = ko.observable(false)
    obj.make_fullscreen = function(element){
        $('.flipper').toggleClass('no_transition');
        if(!obj.is_fullscreen()){
            if(element == 'body'){
                obj.launch_into_fullscreen(document.documentElement);
                // obj.launch_into_fullscreen(document.getElementsByTagName("html")[0]);
            }
            else{
                obj.launch_into_fullscreen(document.getElementById(element));
            }
        } else{
            obj.exit_fullscreen();
        }
    }

    obj.launch_into_fullscreen = function(element){
        if(element.requestFullscreen) {
            element.requestFullscreen();
        } else if(element.mozRequestFullScreen) {
            element.mozRequestFullScreen();
        } else if(element.webkitRequestFullscreen) {
            element.webkitRequestFullscreen();
        } else if(element.msRequestFullscreen) {
            element.msRequestFullscreen();
        }
        //obj.is_fullscreen(!obj.is_fullscreen());
    }

    obj.exit_fullscreen = function () {
        if(document.exitFullscreen) {
            document.exitFullscreen();
        } else if(document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if(document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        }
       // obj.is_fullscreen(!obj.is_fullscreen());
        product_helper_fire_resize_events();
    }

    function exitHandler()
    {
        if (document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement !== null)
        {
            $('.flipper').toggleClass('no_transition');
            obj.is_fullscreen(!obj.is_fullscreen());
            if(!obj.is_fullscreen()){
                $('#framework_header').css({ "visibility": "visible"});
                $('#main').css({ "padding": "1rem"});
                $('.flipper').removeClass('no_transition');
            }
        }
    }

    if (document.addEventListener)
    {
        document.addEventListener('webkitfullscreenchange', exitHandler, false);
        document.addEventListener('mozfullscreenchange', exitHandler, false);
        document.addEventListener('fullscreenchange', exitHandler, false);
        document.addEventListener('MSFullscreenChange', exitHandler, false);
    }
    
    //Initializes all the tool tips. Called when a new tool tip is being added, and when changing exercises.
    //@_data = The _data array the tool tips are stored in. Either exercise or stimuli _data array.
    //@is_stim = Whether or not the _data array comes from the stimulus or not.
    obj.init_tool_tip = function(_data, is_stim)
    {
        var stimuli_id = obj.labs()[obj.selected_lab()].selected_stimuli();
        
        obj.load_tips(_data, is_stim, stimuli_id);
        //console.log("i call init tool tip with "+_data+" and i am stim: "+ is_stim +" and selected stimuli: "+ obj.labs()[obj.selected_lab()].selected_stimuli());
        for(var k = 0; k < _data.length; ++k)
        {
            if (_data[k].type() == "tips")
            {
                for (var i = 0; i < _data[k].content().length; ++i)
                {
                    //Find all elements with the tip id that are visible and initialize the popover.
                    //Switched to use a jQuery selector becaues the ID of the exercise in a separate DR is always 0, which messes
                    //up the id pairs. Changed in bug_071_tooltip_single_dr.

                    //Can't use the below because then stim tips and exercise tips conflict
                    if(is_stim){
                        $('#stimtip_'+stimuli_id+"_"+_data[k].content()[i].tip_id()).popover({container: 'body', html: true, trigger: 'hover', placement: 'top', content: _data[k].content()[i].content(),
                        template: '<div class="popover tip-popover"><div class="arrow tip-arrow"></div><div class="popover-content tip-content"></div></div>'});
                    }
                    else{
                        $('*[id*=tip_]:visible').each(function(){
                            if ($(this).attr('id').split('_')[0] == 'tip' && $(this).attr('id').split('_')[2] == _data[k].content()[i].tip_id())
                            {
                                $(this).popover({container: 'body', html: true, trigger: 'hover', placement: 'top', content: _data[k].content()[i].content(),
                                    template: '<div class="popover tip-popover"><div class="arrow tip-arrow"></div><div class="popover-content tip-content"></div></div>'});
                            }
                        });
                    }
                    
                    //Initialize the tool tip. Set the html option to true to allow html mark up inside the tool tip.
                    // if (is_stim)
                    //     $('#stimtip_'+stimuli_id+"_"+_data[k].content()[i].tip_id()).popover({container: 'body', html: true, trigger: 'hover', placement: 'top', content: _data[k].content()[i].content(),
                    //     template: '<div class="popover tip-popover"><div class="arrow tip-arrow"></div><div class="popover-content tip-content"></div></div>'});
                    // else
                    // {
                    //     $('#tip_'+viewModel.labs()[viewModel.selected_lab()].selected_exercise()+"_"+_data[k].content()[i].tip_id()).popover({container: 'body', html: true, trigger: 'hover', placement: 'top', content: _data[k].content()[i].content(),
                    //     template: '<div class="popover tip-popover"><div class="arrow tip-arrow"></div><div class="popover-content tip-content"></div></div>'});
                    // }
                }
                break;
            }
        }  
    }
    
    //Called on start up when editing is enabled to find out the highest tool tip ID, so any IDs added after don't over lap.
    //@_data = The _data array the tool tips are stored in. Either from exercise or stimuli.
    obj.load_tips = function(_data, is_stim, stimuli_id) 
    {
        //Set to to lower than 0, so we can find any number higher
        var highest_id = -1;
        
        for(var k = 0; k < _data.length; ++k)
        {
            if (_data[k].type() == "tips")
            {
                for(var i = 0; i < _data[k].content().length; ++i)
                {
                    //If the tip_id is higher than our current highest, update the number
                    if (highest_id < _data[k].content()[i].tip_id())
                        highest_id = _data[k].content()[i].tip_id();
                }
            }
        }

        if (!is_stim)
            obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].tip_count(highest_id + 1);
        else if (typeof stimuli_id !== 'undefined')
            obj.labs()[obj.selected_lab()].stimuli()[stimuli_id].tip_count(highest_id + 1);
    }
    obj.load_tss();    
    
    obj.dr6_complete = ko.computed(function()
    {        
        for (var i = 0, len = obj.labs()[0].exercises().length; i < len; ++i)
        {
            for(var k = 0, k_len = obj.labs()[0].exercises()[i]._data().length; k < k_len; ++k)
            {
                if( obj.labs()[0].exercises()[i]._data()[k].type() == "group" ) 
                {
                    for(var w = 0, w_len = obj.labs()[0].exercises()[i]._data()[k].contents().length; w < w_len; ++w)
                    {
                        if(obj.labs()[0].exercises()[i]._data()[k].contents()[w].type() == "group_name" && obj.labs()[0].exercises()[i]._data()[k].contents()[w].content() == "Quiz")
                        {
                            if(obj.labs()[0].exercises()[i].cur_question() != -1)
                                return false;
                        }
                    }
                }
            }
        }
        return true;
    });
    
    //Checks to see if the learning point has an example or not. This function is 
    //used to check whether or not the learning point needs to display the Example 
    //header in the modal or not.
    //@contents = The content array for the specific learning point.
    obj.check_learning_point_example = function(contents)
    {
        var ret = false;
        
        //Loop through all of the content in the learning point
        for (var i = 0; i < contents().length; ++i)
        {
            //If an example is found set the return to true and leave the loop
            if (contents()[i].type() == "example")
            {
                ret = true;
                break;
            }
        }
        
        return ret;
    }
    
    obj.show_submit_button = ko.computed(function(){
        var ret = true;

        if(obj.disabled_submit_exes().indexOf(obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].type()) != -1)
            ret = false;
        
        return ret;
    });
}

function product_lesson_data_model(obj)   //HRC
{
    obj.lesson_name = ko.observable("");
    obj.unit_name = ko.observable("");
    obj.position = ko.observable("");
    obj.origin = ko.observable("");
    obj.test = ko.observable("");
    obj.lesson = ko.observable("");
    obj.level = ko.observable("");
    obj.background_image = ko.observable("");
    obj.objectives = ko.observableArray();
    for(var i = 0; i < obj().length; ++i)
    {
        if (obj()[i].type() == "background_image")
        {
            obj.background_image(obj()[i].content())
            continue;
        }
        else if (obj()[i].type() == "objectives")
        {
            for (var k = 0; k < obj()[i].contents().length; ++k)
            {
                if(obj()[i].contents()[k].type() != "primary")
                    obj.objectives.push(obj()[i].contents()[k].type());
            }
            obj()[i].contents.subscribe(function(old_value){//keep array up to date with changesa                                
                if((obj.objectives().length+1) > old_value.length)
                {
                    ////log(obj.objectives().length + ' vs ' + old_value.length);
                    for (var k = 0; k < obj.objectives().length; ++k)
                    {
                        var remove = k;
                        for (var w = 0; w < old_value.length; ++w)
                        {                            
                            if(old_value[w].type() == obj.objectives()[k])
                            {
                                remove = -1;
                                break;
                            }
                        }
                        if(remove >= 0)
                        {
                            obj.objectives.splice(remove, 1);
                        }
                    }
                }
                else if ((obj.objectives().length+1) < old_value.length)
                {
                    
                    for (var k = 0; k < old_value.length; ++k)
                    {
                        var add = true;
                        for (var w = 0; w < obj.objectives().length; ++w)
                        {                            
                            if(old_value[k].type() == obj.objectives()[w])
                            {
                                ////log(old_value[k].type());
                                add = false;
                                break;
                            }
                        }
                        if(add && old_value[k].type() != "primary")
                        {
                            obj.objectives.push(old_value[k].type());
                        }
                    }
                }               
            })
        }
        for (var k = 0; k < obj()[i].contents().length; ++k)
        {
            if (obj()[i].contents()[k].type() == "lesson_name")
                obj.lesson_name(obj()[i].contents()[k].content());        
            if (obj()[i].contents()[k].type() == "unit_name")
                obj.unit_name(obj()[i].contents()[k].content());
            if (obj()[i].contents()[k].type() == "position")
                obj.position(obj()[i].contents()[k].content());
            if (obj()[i].contents()[k].type() == "origin")
                obj.origin(obj()[i].contents()[k].content());
            if (obj()[i].contents()[k].type() == "test")
                obj.test(obj()[i].contents()[k].content());
            if (obj()[i].contents()[k].type() == "lesson")
                obj.lesson(obj()[i].contents()[k].content());
            if (obj()[i].contents()[k].type() == "level")
                obj.level(obj()[i].contents()[k].content());
        }
    }
}

function product_lab_data_model(obj)   //HRC
{
    obj.has_nav = ko.observable(false);
    obj.has_exercise_controls = ko.observable(false);    
    for(var i = 0; i < obj().length; ++i)
    {
        if (obj()[i].type() == "lab_options")
        {
            for (var k = 0; k < obj()[i].contents().length; ++k)
            {
                if (obj()[i].contents()[k].type() == "has_nav")
                    obj.has_nav(obj()[i].contents()[k].content());        
                if (obj()[i].contents()[k].type() == "has_exercise_controls")
                    obj.has_exercise_controls(obj()[i].contents()[k].content());
            }
        }
    }
}

//ViewModel level product functions
function product_select_lab(obj, value) //HRC
{
    if(obj.labs()[value].type() == "oed" && value == 3 && !obj.started_writing_task())
    {
        //go to writing task pressed
        //get all responses from planner
        if(obj.planner_completed())
        {
            obj.selected_lab(value);
            obj.started_writing_task(1);
            obj.labs()[2].disabled(true);
        }                    
        product_helper_update_container_height();
    }
    else if (obj.labs()[value].type() == "oed" && value == 3 && obj.started_writing_task())
    {
        obj.selected_lab(value);
    }
    else if (obj.labs()[value].type() == "oed" && value == 2 && obj.started_writing_task())
    {
        //not allowed 
    }        
    else
    {
        obj.selected_lab(value);
        //obj.labs()[obj.selected_lab()].select_exercise(obj.labs()[obj.selected_lab()].selected_exercise());//fix for adding functionality when lab switching
    }
}

function product_get_progress(obj) //HRC
{ 
    var response_str = "";
    var group_selected_exercise = new Array();
    var exercise_attempts = new Array();
    var shown_pre_screen = new Array();
    var items = new Array();
    var restore_states = new Array();
    var feedback_showing_answer = new Array();
    var typ_progress = new Array();
    var kar_progress = new Array();
    var giw_progress = new Array();
    var hng_progress = new Array();
    var gwr_progress = new Array();
    var cwd_progress = new Array();
    var dragdrop_progress = new Array();
    var ttt_progress = new Array();
    var mch_progress = {'attempts' : new Array(), 'responses' : new Array()};
    var oed_progress = '';
    var spk_progress = new Array();
    var last_progress = undefined;
    var scorm_question_info = new Array();
    
    if(initialized){
        if(typeof obj.progress() !== 'undefined'){
            //log("i have scorm progress");
            last_progress == obj.progress();
        }
    }
    else if(typeof obj.progress() !== 'undefined')
    {
        last_progress = JSON.parse(obj.progress());
    }
    for(var i = 0; i<obj.exercise_group_types().length; ++i){
        group_selected_exercise.push('g'+i+'e'+obj.exercise_group_types()[i].group_selected_exercise_idx());
    }
    for (var i = 0; i < obj.labs().length; ++i)
    {
        if(obj.labs()[i].type().match(/scholar/i) || obj.labs()[i].type() == "act" || obj.labs()[i].type() == "oed" )
        {
            for (var w = 0; w < obj.labs()[i].exercises().length; ++w)
            {
                ////log(obj.labs()[i].exercises()[w].feedback());
                exercise_attempts.push('l'+i+'e'+w+'a'+obj.labs()[i].exercises()[w].feedback().attempts());
                shown_pre_screen.push('l'+i+'e'+w+'p'+obj.labs()[i].exercises()[w].shown_pre_screen());
                if ( obj.labs()[i].exercises()[w].type() != "WLC" && obj.labs()[i].exercises()[w].type() != "RSLT")
                {
                    for (var k = 0; k < obj.labs()[i].exercises()[w].questions().length; ++k){
                        
                        //Get scorm question info
                        if(initialized){
                            if(obj.labs()[i].exercises()[w].type() != "STI" && obj.labs()[i].exercises()[w].type() != "DWS" && !obj.labs()[i].exercises()[w].feedback_showing_answer()){ //don't need to send question info for STI
                                product_helper_get_question_scorm_info(obj.labs()[i].exercises()[w], i, w, k);
                            }
                        }
                        
                        for (var t = 0; t < obj.labs()[i].exercises()[w].questions()[k].responses().length; ++t)
                        {
                            ////log(obj.labs()[i].exercises()[w].type()+' question: ' + k + ", response: " + t);
                            if( obj.labs()[i].exercises()[w].type() == "TYP" ) //EXS
                            {
                                if(obj.labs()[i].exercises()[w].questions()[k].responses()[t].selected())
                                {
                                    response_str +='l'+i+'e'+w+'q'+k+'r'+t+',';
                                }
                                else if (typeof obj.labs()[i].exercises()[w].questions()[k].entered_response() !== 'undefined' && obj.labs()[i].exercises()[w].questions()[k].entered_response() != '' && obj.labs()[i].exercises()[w].questions()[k].state())
                                {
                                    
                                    typ_progress.push('l'+i+'e'+w+'q'+k+'r'+obj.labs()[i].exercises()[w].questions()[k].entered_response()+'_typ');
                                    break;//break outer response loop we have what they entered

                                }
                            }
                            if( obj.labs()[i].exercises()[w].type() == "KAR" ) //EXS
                            {
                                if(obj.labs()[i].exercises()[w].questions()[k].responses()[t].selected() && obj.labs()[i].exercises()[w].questions()[k]._data()[0].contents()[0].type() == 'text')
                                {
                                    kar_progress.push('l'+i+'e'+w+'q'+k+'r'+t+'|'+obj.labs()[i].exercises()[w].questions()[k]._data()[0].contents()[0].content().replace(/\n/g, "\\n"));
                                }
                                else if(obj.labs()[i].exercises()[w].questions()[k].responses()[t].selected())
                                {
                                    kar_progress.push('l'+i+'e'+w+'q'+k+'r'+t+'|'+"");
                                }
                            }
                            else if( obj.labs()[i].exercises()[w].type() == "GWR" ) //EXS
                            {
                                if (typeof obj.labs()[i].exercises()[w].questions()[k].responses()[1]._data()[0].content() !== 'undefined' && obj.labs()[i].exercises()[w].questions()[k].responses()[1]._data()[0].content() != '' && k==0)
                                {
                                    gwr_progress.push('l'+i+'e'+w+'|'+obj.labs()[i].exercises()[w].questions()[k].responses()[1]._data()[0].content().replace(/\n/g, "\\n"));
                                    break; //break outer response loop we have what they entered
                                }
                            }
                            else if( obj.labs()[i].exercises()[w].type() == "HNG" ) //EXS
                            {
                                if(obj.labs()[i].exercises()[w].questions()[k].responses()[t].selected())
                                {
                                    response_str +='l'+i+'e'+w+'q'+k+'r'+t+',';
                                }
                                else
                                {
                                    var temp_word= "";
                                    for (var z = 0, z_len = obj.labs()[i].exercises()[w].questions()[k].letter_array().length; z < z_len; z++)
                                    {
                                        if (obj.labs()[i].exercises()[w].questions()[k].letter_array()[z].selected() == 1)
                                        {
                                            temp_word += obj.labs()[i].exercises()[w].questions()[k].letter_array()[z].letter();
                                        }
                                    }
                                    hng_progress.push('l'+i+'e'+w+'q'+k+temp_word);
                                    break;//break outer response loop we have what they entered
                                }
                            }
                            else if( obj.labs()[i].exercises()[w].type() == "CAS") //EXS
                            {
                                for (var z = 0; z < obj.labs()[i].exercises()[w].selected_questions().length; ++z)
                                {
                                    if (obj.labs()[i].exercises()[w].selected_questions()[z].id() == k && obj.labs()[i].exercises()[w].selected_responses()[z] == t)
                                    {
                                        response_str +='l'+i+'e'+w+'q'+k+'r'+t+',';
                                    }
                                }
                            }
                            else if( obj.labs()[i].exercises()[w].type() == "CWD" && k == 0 && t == 0) //EXS
                            {
                                
                                for(var g = 0; g < obj.labs()[i].exercises()[w].questions().length; ++g)
                                {
                                    for (var l = 0; l < obj.labs()[i].exercises()[w].questions()[g].responses().length; ++l)
                                    {
                                        if(obj.labs()[i].exercises()[w].questions()[g].responses()[l].selected())
                                        {
                                            if(response_str.indexOf('l'+i+'e'+w+'q'+g+'r'+l+',') == -1)
                                            {
                                                response_str +='l'+i+'e'+w+'q'+g+'r'+l+',';
                                            }
                                        }
                                    }
                                }
                                
                                var temp_string= "";
                                
                                for (var g = 0; g < obj.labs()[i].exercises()[w].grid().length; ++g)
                                {
                                    for (var l = 0; l < obj.labs()[i].exercises()[w].grid()[g].cols().length; ++l)
                                    {    
                                        if (obj.labs()[i].exercises()[w].grid()[g].cols()[l].letter() != "" && obj.labs()[i].exercises()[w].grid()[g].cols()[l].question().length != 0)
                                        {
                                            temp_string += ("," + g +"|" + l +"|" + obj.labs()[i].exercises()[w].grid()[g].cols()[l].letter());
                                        }
                                    }
                                }

                                cwd_progress.push('l'+i+'e'+w+temp_string);     
                            }
                            else if( obj.labs()[i].exercises()[w].type() == "TTT" ) //EXS
                            {                
                                if(k == 0 && t == 0)     
                                {
                                    var temp_string= "";
                                    var selected_var;
                                    var quest_num;
                                    var resp_select;
                                    
                                    for (var g = 0; g < obj.labs()[i].exercises()[w].ttt_grid().length; ++g)
                                    {
                                        for (var l = 0; l < obj.labs()[i].exercises()[w].ttt_grid()[g].cols().length; ++l)
                                        {    
                                            resp_select = 0;
                                            quest_num = obj.labs()[i].exercises()[w].ttt_grid()[g].cols()[l].question();
                                            if(!obj.labs()[i].exercises()[w].ttt_grid()[g].cols()[l].selected())
                                            { 
                                                selected_var = 0
                                            }
                                            else if(obj.labs()[i].exercises()[w].ttt_grid()[g].cols()[l].correct())
                                            {
                                                selected_var = 1
                                            }
                                            else if(!obj.labs()[i].exercises()[w].ttt_grid()[g].cols()[l].correct())
                                            {
                                                selected_var = 2
                                            }
                                            if(typeof obj.labs()[i].exercises()[w].questions()[quest_num] !== 'undefined')
                                            {
                                                for (var m = 0, m_len = obj.labs()[i].exercises()[w].questions()[quest_num].responses().length; m<m_len; ++m)
                                                {
                                                    if(obj.labs()[i].exercises()[w].questions()[quest_num].responses()[m].selected())
                                                    {
                                                        if(obj.labs()[i].exercises()[w].questions()[quest_num].responses()[m].correct())
                                                        {
                                                            resp_select = 1;
                                                        }
                                                        else
                                                        {
                                                            resp_select = 2;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            ttt_progress.push('l'+i+'e'+w+'x'+g+'y'+l+'q'+quest_num+'s'+selected_var+'r'+resp_select);
                                        }
                                    }
                                }
                            }
                            else if ( obj.labs()[i].exercises()[w].type() == "GIW" && k == 0 && t == 0)
                            {
                                for (var q = 0; q < obj.labs()[i].exercises()[w].word_list().length; ++q)
                                {
                                    if (obj.labs()[i].exercises()[w].word_list()[q].answered() == 1)
                                        giw_progress.push('l'+i+'e'+w+'q'+obj.labs()[i].exercises()[w].word_list()[q].question+'c'+q+obj.labs()[i].exercises()[w].questions()[obj.labs()[i].exercises()[w].word_list()[q].question].entered_response());
                                }
                            }
                            else if( obj.labs()[i].exercises()[w].type() == "MCH" ) //EXS
                            {                
                                if(k == 0 && t == 0)     
                                {           
                                    var temp_string= "";
                                    
                                    for (var g = 0; g < obj.labs()[i].exercises()[w].mch_grid().length; ++g)
                                    {
                                        for (var l = 0; l < obj.labs()[i].exercises()[w].mch_grid()[g].cols().length; ++l)
                                        {    
                                           quest_num = obj.labs()[i].exercises()[w].mch_grid()[g].cols()[l].question();
                                           resp_num = obj.labs()[i].exercises()[w].mch_grid()[g].cols()[l].response();
                                           correct_var = obj.labs()[i].exercises()[w].mch_grid()[g].cols()[l].correct();
                                           mch_progress.responses.push('l'+i+'e'+w+'x'+g+'y'+l+'q'+quest_num+'r'+resp_num+'c'+correct_var);
                                        }
                                    }
                                    mch_progress.attempts.push('l'+i+'e'+w+'a'+obj.labs()[i].exercises()[w].mch_attempts());
                                }
                            }
                            else if( obj.labs()[i].exercises()[w].type() == "oea" && i == 3 && k == 1) //EXS
                            {
                                oed_progress += obj.labs()[i].exercises()[w].questions()[k].responses()[t].text().replace(/\n/g, "\\n");                                  
                            }
                            else //EXS
                            {
                                if(obj.labs()[i].exercises()[w].questions()[k].responses()[t].selected())
                                {
                                    if(response_str.indexOf('l'+i+'e'+w+'q'+k+'r'+t+',') == -1)
                                    {
                                        response_str +='l'+i+'e'+w+'q'+k+'r'+t+',';
                                    }
                                }
                            }
                        }
                    }
                    
                //     if(obj.labs()[i].exercises()[w].historical_progress() == '' || obj.labs()[i].exercises()[w].historical_progress() != '' && obj.labs()[i].exercises()[w].state() > 0 )
                //     {
                //         if(obj.labs()[i].exercises()[w].state() == 2 && obj.labs()[i].exercises()[w].checked_answer())
                //         {
                //             items.push({"status": "failed", "score_raw": 0});
                //             restore_states.push('l'+i+'e'+w);
                //         }else if(obj.labs()[i].exercises()[w].state() == 4 && obj.labs()[i].exercises()[w].checked_answer())
                //         {
                //             items.push({"status": "passed", "score_raw": 100});
                //             restore_states.push('l'+i+'e'+w);
                //         }else if(obj.labs()[i].exercises()[w].state() == 1)
                //         {
                //             if(obj.labs()[i].type() == "act" || obj.labs()[i].type().match(/scholar/i))
                //             {                                              
                //                 items.push({"status": "incomplete", "score_raw": obj.labs()[i].exercises()[w].score()});
                //                 if(obj.labs()[i].exercises()[w].score() > 0 && obj.labs()[i].exercises()[w].checked_answer())
                //                 {
                //                     restore_states.push('l'+i+'e'+w);
                //                 }
                //             }
                //         }else if(obj.labs()[i].exercises()[w].state() == 0)
                //         {
                //             if(obj.labs()[i].type() == "act" || obj.labs()[i].type().match(/scholar/i))
                //             {
                //                 items.push({"status": "not passed", "score_raw": 0});
                //             }
                //         }
                //     }
                //     else
                //     {
                //         items.push(obj.labs()[i].exercises()[w].historical_progress());
                //     }                    
                }
                if(obj.labs()[i].exercises()[w].checked_answer())
                {
                    //items.push({"status": "failed", "score_raw": 0});
                    restore_states.push('l'+i+'e'+w);
                }
                if(obj.labs()[i].exercises()[w].feedback_showing_answer())
                {
                    //items.push({"status": "failed", "score_raw": 0});
                    feedback_showing_answer.push('l'+i+'e'+w);
                }
                if(obj.labs()[i].exercises()[w].type() == "SPK" && obj.labs()[i].exercises()[w].started())
                {
                    for(var k = 0, k_len = obj.labs()[i].exercises()[w].attempt_times().length; k < k_len; ++k)
                    {
                        spk_progress.push('l'+i+'e'+w+'|'+obj.labs()[i].exercises()[w].attempt_times()[k]);
                    }
                }              
            }
        }            
    }
    //Add missing comma for splitting TYP progress
    if(typ_progress.length) //EXS 
    {        
        var typ_length = typ_progress.length;
        var temp_response = typ_progress[typ_length-1]+',';
        typ_progress[typ_length-1] = temp_response;
        for(var i = 0; i<typ_length;++i){
            //get rid of the last few characters that can break TYP and just replace them with spaces
            typ_progress[i] = typ_progress[i].replace(/[\"]/g, " ");
            typ_progress[i] = typ_progress[i].replace(/[\\]/g, " ");
        }
    }
    //get DR scores
    // for (var i = 0, len = obj.exercise_group_types().length; i < len; ++i)
    // {
        // //log(product_core_grade_LO(obj.exercise_group_types()[i].group));
    // }
    dragdrop_progress.push(product_helper_get_drag_drop_progress(obj)); //EXS
    var items_str = JSON.stringify(items);
    //var exercise_num = 0;
    var date = new Date();
    var exit_time = Date.now();
    var time_spent = exit_time - obj.start_time;
    var last_attempt = date.getFullYear() + '-' + (date.getMonth()+1) + '-' + date.getDate();
    if(typeof last_progress !== 'undefined' && last_progress.time_spent > 0)
    {
        var this_time = parseInt(obj.elapsed_seconds);
        var last_time = parseInt(last_progress.time_spent);
        obj.elapsed_seconds = this_time + last_time;
    }
    // if(typeof obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].id === undefined)
    // {
    //     var exercise_num = obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].id();//make the below string slightly shorter        
    // }else
    // {
    //     var exercise_num = obj.labs()[obj.selected_lab()].selected_exercise();//make the below string slightly shorter        
    // }
    var progress = "{\"datamodel\": { \"cmi\" : { \"core\" : { \"student_name\": \""+lms_config.student_name+"\", \"student_id\": \""+lms_config.student_id+"\", \"course_id\": \""+lms_config.course_id+"\", \"lesson_location\": \"l"+obj.selected_lab()+"e"+obj.labs()[obj.selected_lab()].selected_exercise()+"\"}, \"objectives\": { \"count\" : "+items.length+", \"items\" : "+items_str+"} } }, \"group_location\":\""+obj.labs()[obj.selected_lab()].selected_group()+"\", \"group_selected_exercise\":\""+group_selected_exercise+"\", \"exercise_attempts\":\""+exercise_attempts+"\", \"responses\": \""+response_str+"\", \"typ_progress\" : \""+typ_progress+"\", \"kar_progress\" : \""+kar_progress+"\", \"gwr_progress\" : \""+gwr_progress+"\", \"cwd_progress\" : \""+cwd_progress+"\", \"spk_progress\" : \""+spk_progress+"\", \"mch_progress\" : "+JSON.stringify(mch_progress)+", \"ttt_progress\" : \""+ttt_progress+"\", \"giw_progress\" : \""+giw_progress+"\", \"hng_progress\" : \""+hng_progress+"\", \"dragdrop_progress\" : \""+dragdrop_progress+"\", \"oed_progress\" : \""+oed_progress+"\", \"restore_states\" : \""+restore_states+"\", \"last_attempt\" : \""+last_attempt+"\", \"quiz_score\" : \""+obj.labs()[obj.selected_lab()].quiz_score()+"\", \"shown_pre_screen\" : \""+shown_pre_screen+"\", \"feedback_showing_answer\" : \""+feedback_showing_answer+"\", \"time_spent\" : \""+time_spent+"\", \"quiz_score\" : \""+obj.labs()[obj.selected_lab()].quiz_score()+"\", \"at_score\" : \""+(viewModel._data.test() == 'true' ? viewModel.AT_score() : -1)+"\" }";

    obj.progress(progress);
    //log(progress);
    if(!viewModel.restoring_progress()){
        if(initialized)
        {
            // var scorm_progress_str = "{{\"startup\" : "+scorm_config+"},{\"progress\" : "+ progress +"}}";
            // //log(scorm_progress_str);
            ////log(progress);
            doSetValue("cmi.suspend_data", progress);
        }
        else{
            ajax_write_progress(progress);
        }
    } 
}

function product_restore_progress(obj)
{
    //log("i start restoring progress");

    var progress_obj = undefined;
    var current_exercise = undefined;
    var restored_lab = undefined;
    var restored_exercises = new Array();
    if(initialized)
    {
        progress_obj = obj.progress();
        //log(progress_obj);
        //log("progress object empty? " + progress_obj);
        if(!progress_obj){
            //log("empty object");
            return;
        }
    }
    else if(obj.progress() && obj.progress() != '')
    {
        progress_obj = JSON.parse(obj.progress());            
    }
    else
    {
        progress_obj = ajax_get_progress();            
    }
    
    if (viewModel._data.test() != 'true')
    {
        var responses_array = progress_obj.responses.split(',');        
        lesson_location = progress_obj.datamodel.cmi.core.lesson_location.match( /l(\d+)e(\d+)/i);

        for (var i = 0; i < responses_array.length; ++i)
        {
            if(typeof responses_array[i] === 'undefined' || responses_array[i] == ''){continue;}//skip the final null string
            var progress_data = responses_array[i].match( /l(\d+)e(\d+)q(\d+)r(\d+)/i );        
            if(current_exercise != progress_data[2])
            {
                current_exercise = progress_data[2];
                restored_exercises.push(current_exercise)
            }
            if(product_helper_is_drag_drop_type(viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].type()))
            {
                //do nothing now
            }
            else if(viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].type() == "MFL"){ //EXS
                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]].selectbox_response(progress_data[4]);
            }else if(viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].type() == "MMM" || viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].type() == "ELS"){ //EXS
                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]].responses()[progress_data[4]].selected(1);
            }else if(viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].type() == "TAB"){ //EXS
                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]].select_response_toggle(ko.observable(progress_data[4]));
            }else
            {
                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]].select_response(ko.observable(progress_data[4]));         
            }
        }
        //Make sure CAS array gets populated with correct responses
        if(typeof progress_data !== 'undefined' && viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].type() == "CAS"){
            viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].restore_cas_progress();
        }
        //reset typ progress if exists
        if(typeof progress_obj.typ_progress !== 'undefined' && progress_obj.typ_progress != '') //EXS  for TYP only it seems
        {        
            var typ_progress = progress_obj.typ_progress.split('_typ,');
            for (var i = 0; i < typ_progress.length; ++i)
            {
                if(typeof typ_progress[i] === 'undefined' || typ_progress[i] == ''){continue;}//skip the final null string
                var progress_data = typ_progress[i].match( /l(\d+)e(\d+)q(\d+)r(.+)/i );
                // var new_ex = true;
                // for(var w = 0; w < restored_exercises.length; ++w)
                // {
                //     if(progress_data[2] == restored_exercises[w]){
                //         new_ex = false;
                //         break;
                //     }
                // }
                // if(new_ex)
                // {
                //     restored_exercises.push(progress_data[2]);
                // }
                // var safe_question_number = progress_data[3];
                // var safe_entered_response = progress_data[4];
                // if(viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions().length < progress_data[3])
                // {
                //     safe_question_number = progress_data[3].substr(0, Math.ceil((viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions().length / 10)));
                //     safe_entered_response = '' + progress_data[3].substr(Math.ceil((viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions().length / 10))) + progress_data[4];
                // }
                // console.log('l'+progress_data[1]);
                // console.log('e'+progress_data[2]);
                // console.log('q'+progress_data[3]);
                // console.log('r'+progress_data[4]);
                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]].entered_response(progress_data[4]);
                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]].check_entered_response('TYP');
            }
        }
        if(typeof progress_obj.gwr_progress !== 'undefined' && progress_obj.gwr_progress != '') //EXS
        {        
            var gwr_progress = progress_obj.gwr_progress.split(',');
            for (var i = 0; i < gwr_progress.length; ++i)
            {
                if(typeof gwr_progress[i] === 'undefined' || gwr_progress[i] == ''){continue;}//skip the final null string
                var temp_data = gwr_progress[i].split("|");

                var progress_data = gwr_progress[i].match( /l(\d+)e(\d+)(.+)/i );
                var new_ex = true;
                for(var w = 0; w < restored_exercises.length; ++w)
                {
                    if(progress_data[2] == restored_exercises[w]){
                        new_ex = false;
                        break;
                    }
                }
                if(new_ex)
                {
                    restored_exercises.push(progress_data[2]);
                }
                
                var safe_entered_response = temp_data[1];

                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[0].responses()[1]._data()[0].content(safe_entered_response);
                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].set_up_progress();
            }
        }
        if(typeof progress_obj.kar_progress !== 'undefined' && progress_obj.kar_progress != '') //EXS
        {        
            var kar_progress = progress_obj.kar_progress.split(',');
            for (var i = 0; i < kar_progress.length; ++i)
            {
                if(typeof kar_progress[i] === 'undefined' || kar_progress[i] == ''){continue;}//skip the final null string
                var temp_data = kar_progress[i].split("|");

                var progress_data = kar_progress[i].match( /l(\d+)e(\d+)q(\d+)r(\d+)(.+)/i );

                if (temp_data[1] != "")
                {
                    viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]]._data()[0].contents()[0].content(temp_data[1]);
                    viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]].responses()[progress_data[4]].selected(1);
                }

                // if(viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]]._data()[0].contents()[0].type() == 'rec')
                // {
                //     viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]].check_rec_response();
                // }
                // else
                // {
                    viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]].responses()[progress_data[4]].selected(1);
                // }
                   
            }
        }
        //reset hng progress if exists
        if(typeof progress_obj.hng_progress !== 'undefined' && progress_obj.hng_progress != '') //EXS
        {        
            var hng_progress = progress_obj.hng_progress.split(',');
            for (var i = 0; i < hng_progress.length; ++i)
            {
                if(typeof hng_progress[i] === 'undefined' || typeof hng_progress[i] === ''){continue;}
                var progress_data = hng_progress[i].match( /l(\d+)e(\d+)q(\d+)(.+)/i );
                if (progress_data == null){continue;}
                var new_ex = true;
                for(var w = 0; w < restored_exercises.length; ++w)
                {
                    if(progress_data[2] == restored_exercises[w]){
                        new_ex = false;
                        break;
                    }
                }
                if(new_ex)
                {
                    restored_exercises.push(progress_data[2]);
                }
                var safe_question_number = progress_data[3];
                var safe_entered_response = progress_data[4];
                if(viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions().length < progress_data[3])
                {
                    safe_question_number = progress_data[3].substr(0, Math.ceil((viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions().length / 10)));
                    safe_entered_response = '' + progress_data[3].substr(Math.ceil((viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions().length / 10))) + progress_data[4];
                }

                for (var k = 0, k_len = safe_entered_response.length; k <k_len; ++k)
                {
                    for (var w = 0, w_len = viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[safe_question_number].letter_array().length; w <w_len; ++w)
                    {
                        if (viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[safe_question_number].letter_array()[w].letter() == safe_entered_response.charAt(k))
                        {
                            viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].guessing_letter(w,safe_question_number, true);
                        }
                    }
                }
                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].build_word(safe_question_number,viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[safe_question_number].word_to_guess(),false);

            }
        }
        if(typeof progress_obj.spk_progress !== 'undefined' && progress_obj.spk_progress != '') //EXS
        {        
            var spk_progress = progress_obj.spk_progress.split(',');
            var current_lab = 0;
            var current_ex = 0;
            for (var i = 0; i < spk_progress.length; ++i)
            {
                if(typeof spk_progress[i] === 'undefined' || spk_progress[i] == '' || spk_progress[i] == null){continue;}//skip the final null string
                var progress_data = spk_progress[i].match( /l(\d+)e(\d+)\|(.*)/i );
                if (current_lab != progress_data[1] || current_ex != progress_data[2])
                {
                    //loop and select all responses
                    for(var w = 0, w_len = obj.labs()[progress_data[1]].exercises()[progress_data[2]].questions().length; w < w_len; ++w)
                    {
                        for(var k = 0, k_len = obj.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[w].responses().length; k < k_len; ++k)
                        {
                            obj.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[w].responses()[k].selected(1);
                        }
                    }
                }
                
                obj.labs()[progress_data[1]].exercises()[progress_data[2]].attempt_times.push(parseFloat(progress_data[3]));
            }
            if(obj.labs()[progress_data[1]].exercises()[progress_data[2]].attempt_times().length)
                obj.labs()[progress_data[1]].exercises()[progress_data[2]].timer(parseFloat(obj.labs()[progress_data[1]].exercises()[progress_data[2]].attempt_times()[0]));
            obj.labs()[progress_data[1]].exercises()[progress_data[2]].started(true);
        }
        //cwd
        if(typeof progress_obj.cwd_progress !== 'undefined' && progress_obj.cwd_progress != '') //EXS
        {

            var cwd_progress = progress_obj.cwd_progress.split(',');
            var path = cwd_progress[0].match( /l(\d+)e(\d+)/i )
            for (var i = 1; i < cwd_progress.length; ++i)
            {
                var progress_data = cwd_progress[i].split('|');
                viewModel.labs()[path[1]].exercises()[path[2]].grid()[progress_data[0]].cols()[progress_data[1]].letter(progress_data[2]);
                viewModel.labs()[path[1]].exercises()[path[2]].questions()[viewModel.labs()[path[1]].exercises()[path[2]].grid()[progress_data[0]].cols()[progress_data[1]].question()[0].id()].check_entered_response();
            }
            viewModel.labs()[path[1]].exercises()[path[2]].check_cwd_answer();
        }
        if(typeof progress_obj.ttt_progress !== 'undefined' && progress_obj.ttt_progress != '') //EXS
        {
            var ttt_progress = progress_obj.ttt_progress.split(',');
            for (var i = 0; i < ttt_progress.length; ++i) //loop on each cell
            {
                var path = ttt_progress[i].match( /l(\d+)e(\d+)x(\d+)y(\d+)q(\d+)s(\d+)r(\d+)/i );
                
                if(path[5] == 9){continue;}//skip the middle cell

                viewModel.labs()[path[1]].exercises()[path[2]].ttt_grid()[path[3]].cols()[path[4]].question(path[5]);

                if(path[5] <= viewModel.labs()[path[1]].exercises()[path[2]].questions().length-1) //is the question number part of the real questions
                {
                    if(path[6] == 1) // this cell was correctly selected
                    {
                        viewModel.labs()[path[1]].exercises()[path[2]].ttt_grid()[path[3]].cols()[path[4]].selected(1);
                        viewModel.labs()[path[1]].exercises()[path[2]].ttt_grid()[path[3]].cols()[path[4]].correct(1);
                        viewModel.labs()[path[1]].exercises()[path[2]].questions()[path[5]].responses()[1].selected(1);

                    }
                    else if(path[6] == 2)// this cell was incorrectly selected
                    {
                        viewModel.labs()[path[1]].exercises()[path[2]].ttt_grid()[path[3]].cols()[path[4]].selected(1);
                        //viewModel.labs()[path[1]].exercises()[path[2]].questions()[path[5]].responses()[0].selected(1);
                    }
                    //apply the cells question number, content and type
                    viewModel.labs()[path[1]].exercises()[path[2]].ttt_grid()[path[3]].cols()[path[4]].question(path[5]);
                    viewModel.labs()[path[1]].exercises()[path[2]].ttt_grid()[path[3]].cols()[path[4]].content(viewModel.labs()[path[1]].exercises()[path[2]].questions()[path[5]].responses()[1]._data()[0].content());
                    viewModel.labs()[path[1]].exercises()[path[2]].ttt_grid()[path[3]].cols()[path[4]].type(viewModel.labs()[path[1]].exercises()[path[2]].questions()[path[5]].responses()[1]._data()[0].type());
                    
                    //the questions need to know if they have been answered
                    for(var w = 0, w_len = obj.labs()[path[1]].exercises()[path[2]].questions().length; w < w_len; ++w)
                    {
                        if(obj.labs()[path[1]].exercises()[path[2]].questions()[w].id() == path[5])
                        {
                            if(path[7] == 1)//question has been answered correctly
                            {
                                for(var k = 0, k_len = obj.labs()[path[1]].exercises()[path[2]].questions()[w].responses().length; k < k_len; ++k)
                                {
                                    if(obj.labs()[path[1]].exercises()[path[2]].questions()[w].responses()[k].correct())
                                    {
                                        obj.labs()[path[1]].exercises()[path[2]].questions()[w].responses()[k].selected(1);
                                    }
                                }
                            }
                            else if(path[7] == 2)//question has been answered incorrectly
                            {
                                for(var k = 0, k_len = obj.labs()[path[1]].exercises()[path[2]].questions()[w].responses().length; k < k_len; ++k)
                                {
                                    if(!obj.labs()[path[1]].exercises()[path[2]].questions()[w].responses()[k].correct())
                                    {
                                        obj.labs()[path[1]].exercises()[path[2]].questions()[w].responses()[k].selected(1);
                                    }
                                }
                            }
                        }
                    }
                }  
                else //these quesetion numbers are distracters
                {
                    if(path[6] == 2) //distracter has been selected
                    {
                        viewModel.labs()[path[1]].exercises()[path[2]].ttt_grid()[path[3]].cols()[path[4]].selected(1);
                    }
                    for (var w = 0; w < viewModel.labs()[path[1]].exercises()[path[2]]._data().length; ++w)//loop throught data
                    {

                        if(viewModel.labs()[path[1]].exercises()[path[2]]._data()[w].type() == "options")//found the distracter
                        {
                            viewModel.labs()[path[1]].exercises()[path[2]].ttt_grid()[path[3]].cols()[path[4]].question(path[5]);//give it a question number
                            viewModel.labs()[path[1]].exercises()[path[2]].ttt_grid()[path[3]].cols()[path[4]].content(viewModel.labs()[path[1]].exercises()[path[2]]._data()[w].contents()[path[5]-(viewModel.labs()[path[1]].exercises()[path[2]].questions().length)].content());
                            viewModel.labs()[path[1]].exercises()[path[2]].ttt_grid()[path[3]].cols()[path[4]].type(viewModel.labs()[path[1]].exercises()[path[2]]._data()[w].contents()[path[5]-(viewModel.labs()[path[1]].exercises()[path[2]].questions().length)].type());
                        }
                    }
                }
            }
        }
        //reset giw progress if exists
        if(typeof progress_obj.giw_progress !== 'undefined' && progress_obj.giw_progress != '') //EXS
        {        
            var giw_progress = progress_obj.giw_progress.split(',');
            for (var i = 0; i < giw_progress.length; ++i)
            {
                if(typeof giw_progress[i] === 'undefined' || giw_progress[i] == ''){continue;}//skip the final null string
                var progress_data = giw_progress[i].match( /l(\d+)e(\d+)q(\d+)c(\d+)(.+)/i );
                var new_ex = true;
                for(var w = 0; w < restored_exercises.length; ++w)
                {
                    if(progress_data[2] == restored_exercises[w]){
                        new_ex = false;
                        break;
                    }
                }
                if(new_ex)
                {
                    restored_exercises.push(progress_data[2]);
                }
                
                var safe_question_number = progress_data[3];
                var idx_number = progress_data[4]
                var safe_entered_response = progress_data[5];

                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[safe_question_number].entered_response(safe_entered_response);
                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[safe_question_number].check_entered_response();
                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].set_giw_progress(idx_number);
            }
        }
        if(typeof progress_obj.mch_progress !== 'undefined' && progress_obj.mch_progress != '') //EXS
        {
            var mch_progress = progress_obj.mch_progress.responses;
            for (var i = 0; i < mch_progress.length; ++i)
            {
                var path = mch_progress[i].match( /l(\d+)e(\d+)x(\d+)y(\d+)q(\d+)r(\d+)c(\d+)/i );
                viewModel.labs()[path[1]].exercises()[path[2]].mch_grid()[path[3]].cols()[path[4]].question(path[5]);
                viewModel.labs()[path[1]].exercises()[path[2]].mch_grid()[path[3]].cols()[path[4]].response(path[6]);
                viewModel.labs()[path[1]].exercises()[path[2]].mch_grid()[path[3]].cols()[path[4]].correct(path[7]);
                viewModel.labs()[path[1]].exercises()[path[2]].mch_grid()[path[3]].cols()[path[4]].content(viewModel.labs()[path[1]].exercises()[path[2]].questions()[path[5]].responses()[path[6]]._data()[0].content());
                viewModel.labs()[path[1]].exercises()[path[2]].mch_grid()[path[3]].cols()[path[4]].type(viewModel.labs()[path[1]].exercises()[path[2]].questions()[path[5]].responses()[path[6]]._data()[0].type());
                if (viewModel.labs()[path[1]].exercises()[path[2]].mch_grid()[path[3]].cols()[path[4]].correct() == 1)
                {
                    viewModel.labs()[path[1]].exercises()[path[2]].mch_grid()[path[3]].cols()[path[4]].selected(1);
                    viewModel.labs()[path[1]].exercises()[path[2]].questions()[path[5]].responses()[1].selected(1);
                }
            }
            var mch_attempts = progress_obj.mch_progress.attempts;
            for (var i = 0; i < mch_attempts.length; ++i)
            {
                var path = mch_attempts[i].match( /l(\d+)e(\d+)a(\d+)/i );
                viewModel.labs()[path[1]].exercises()[path[2]].mch_attempts(path[3]);
            }
        }
        //reset dragdrop progress if exists
        if(typeof progress_obj.dragdrop_progress !== 'undefined' && progress_obj.dragdrop_progress != '') //EXS for dragdrop
        {
            product_helper_restore_drag_drop_progress(progress_obj.dragdrop_progress, obj);
            var dragdrop_progress = progress_obj.dragdrop_progress.split(',');
            for (var i = 0; i < dragdrop_progress.length; ++i)
            {
                if(typeof dragdrop_progress[i] === 'undefined' || dragdrop_progress[i] == ''){continue;}//skip the final null string
                var progress_data = dragdrop_progress[i].match( /l(\d+)e(\d+)q(\d+)r(\d+)/i );                
                var new_ex = true;
                for(var w = 0; w < restored_exercises.length; ++w)
                {
                    if(progress_data[2] == restored_exercises[w]){
                        new_ex = false;
                        break;
                    }
                }
                if(new_ex)
                {
                    restored_exercises.push(progress_data[2]);
                }
            }
            for (var i = 0; i < responses_array.length; ++i)
            {
                if(typeof responses_array[i] === 'undefined' || responses_array[i] == ''){continue;}//skip the final null string
                var progress_data = responses_array[i].match( /l(\d+)e(\d+)q(\d+)r(\d+)/i );
                
                //Check for any rec questions within dragdrop. Check to make sure the _data array isn't empty before checking for the rec question.
                //Make sure there are questions in the array.
                if (viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]].length > 0)
                {
                    //Loop through object in the _data array
                    for (var q = 0; viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]]._data().length; ++q)
                    {
                        //Make sure it's a question, because rec are only in type question
                        if(viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]]._data()[q].type() == "question")
                        {
                            if (viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]]._data()[q].contents().length > 0 && viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]]._data()[q].contents()[0].type() == "rec")
                                viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].questions()[progress_data[3]].select_response(ko.observable(progress_data[4]));
                        }
                    }
                }
            }
        }

        //reset oed progress if exists
        if(typeof progress_obj.oed_progress !== 'undefined' && progress_obj.oed_progress != '') 
        {
            if(obj.labs().length == 4)//we are either in OED
            {
                if(obj.labs()[3].type() == "oed")
                {
                    //restore writing task
                    obj.labs()[3].exercises()[0].questions()[1].responses()[0].text(progress_obj.oed_progress); 
                    obj.started_writing_task(1);
                    obj.labs()[2].disabled(true);
                    obj.labs()[3].disabled(false);
                }
            }
        }
        //restore exercise states
        if(typeof progress_obj.restore_states !== 'undefined' && progress_obj.restore_states != '')
        {   
            var state_array = progress_obj.restore_states.split(',');
            for(var i = 0; i < state_array.length; ++i)
            {
                var restore_item = state_array[i].match( /l(\d+)e(\d+)/i);
                obj.select_lab(parseInt(restore_item[1]));
                obj.labs()[obj.selected_lab()].select_exercise(parseInt(restore_item[2]));
                //obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].check_answers();
                if ( obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].type() == "TTT" )
                {
                    obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].TTT_restore();
                }
                if ( obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].type() != "GWR" && obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].type() != "TTT")
                {
                    obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].check_answers();
                }
            }            
        }
        
        //do check for historical data here
        var potentially_historical_items = progress_obj.datamodel.cmi.objectives.items;
        for(var i = 0; i < potentially_historical_items.length; ++i)
        {
            if(potentially_historical_items[i].status != 'not passed')
            {
                var new_ex = true;
                for(var w = 0; w < restored_exercises.length; ++w)
                {
                    if((i+1) == parseInt(restored_exercises[w])){
                        new_ex = false;
                        break;                  
                    }              
                }
                if(new_ex)
                {
                    if(obj.labs()[0].type().match(/scholar/i))//progress belongs in lab 0
                    {
                        obj.labs()[0].exercises()[i+1].historical_progress(potentially_historical_items[i]);
                    }
                    else//OED lab so the exercises are on the second lab
                    {
                        //No i+1 because there is no welcome page at the start
                        obj.labs()[1].exercises()[i].historical_progress(potentially_historical_items[i]);
                    }
                }
            }
        }

        var attempts_progress = progress_obj.exercise_attempts.split(',');
        for (var i = 0; i < attempts_progress.length; ++i)
        {
            if(typeof attempts_progress[i] === 'undefined' || typeof attempts_progress[i] === ''){continue;}
            var attempts_progress_data = attempts_progress[i].match(/l(\d+)e(\d+)a(\d+)/i);
            obj.labs()[parseInt(attempts_progress_data[1])].exercises()[parseInt(attempts_progress_data[2])].feedback().attempts(parseInt(attempts_progress_data[3]));           
            if(typeof progress_obj.feedback_showing_answer !== 'undefined' && progress_obj.feedback_showing_answer.indexOf('l'+attempts_progress_data[1]+'e'+attempts_progress_data[2]) != -1)
            {
                obj.labs()[parseInt(attempts_progress_data[1])].exercises()[parseInt(attempts_progress_data[2])].feedback().attempts(0);
            }
        }

        //restore feedback showing answer states
        if(typeof progress_obj.feedback_showing_answer !== 'undefined' && progress_obj.feedback_showing_answer != '')
        {   
            var feedback_showing_answer_array = progress_obj.feedback_showing_answer.split(',');
            for(var i = 0; i < feedback_showing_answer_array.length; ++i)
            {
                var feedback_showing_answer_item = feedback_showing_answer_array[i].match( /l(\d+)e(\d+)/i);
                obj.select_lab(parseInt(feedback_showing_answer_item[1]));
                obj.labs()[obj.selected_lab()].select_exercise(parseInt(feedback_showing_answer_item[2]));
                obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].feedback_showing_answer(true);
                obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].check_answers();
                obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].checked_answer(false);
                if(obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].type() == "TYP")
                {
                    obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].showing_answer(true);
                }

            }            
        }

        var pre_screen_progress = progress_obj.shown_pre_screen.split(',');
        for (var i = 0; i < pre_screen_progress.length; ++i)
        {
            if(typeof pre_screen_progress[i] === 'undefined' || typeof pre_screen_progress[i] === ''){continue;}
            var pre_screen_data = pre_screen_progress[i].match(/l(\d+)e(\d+)p(\d+)/i);
            obj.labs()[parseInt(pre_screen_data[1])].exercises()[parseInt(pre_screen_data[2])].shown_pre_screen(parseInt(pre_screen_data[3]));        
        }        

        var group_selected_exercise_progress = progress_obj.group_selected_exercise.split(',');
        for (var i = 0; i < group_selected_exercise_progress.length; ++i)
        {
            if(typeof group_selected_exercise_progress[i] === 'undefined' || typeof group_selected_exercise_progress[i] === ''){continue;}
            var group_selected_exercise_progress_data = group_selected_exercise_progress[i].match(/g(\d+)e(\d+)/i);
            obj.exercise_group_types()[parseInt(group_selected_exercise_progress_data[1])].group_selected_exercise_idx(parseInt(group_selected_exercise_progress_data[2]));
        }
        obj.labs()[obj.selected_lab()].quiz_score(progress_obj.quiz_score);

        //store group and exercise rather than lab and such
        //obj.select_lab(parseInt(lesson_location[1]));

        obj.select_lab(0);
        obj.labs()[obj.selected_lab()].selected_group(parseInt(progress_obj.group_location));

        //Set the saved exercise number
        //obj.labs()[obj.selected_lab()].restore_exercise_num(parseInt(lesson_location[2]));
    }
    else if (viewModel._data.test() == 'true') //Restoring an Achievement test
    {
        viewModel.AT_score(progress_obj.at_score); //Get the score from the progress
        
        //If the score is not -1, it means the AT was completed
        if(viewModel.AT_score() != -1)
        {
            //Make sure the Results page is showing
            obj.labs()[obj.selected_lab()].change_group(6);
            //Lock all the other exercises
            obj.finished_test(true);
        }
    }

    if(obj.labs()[obj.selected_lab()].selected_group()!= 0 && viewModel.number_of_sco_groups() > 1){
        obj.flipWelcomePanel(false,true);
    }
    else
    {
        obj.labs()[obj.selected_lab()].change_group(obj.labs()[obj.selected_lab()].selected_group());
        race_condition_ended = true;
    }
}

function product_save_scorm_progress(){
    if(!viewModel.restoring_progress()){
        //log("scorm save progress");
        var save_time = Date.now();
        var scorm_save_time = ConvertMilliSecondsIntoSCORM2004Time(save_time - viewModel.start_time);

        //log("time: "+scorm_save_time);
        for(i=0; i<viewModel.global_objectives_array().length; ++i){
            var name = viewModel.global_objectives_array()[i].name;
            var objIndex = FindObjectiveIndex(name);
            if(viewModel.global_objectives_array()[i].group == viewModel.selected_group_name()){
                doSetValue("cmi.objectives."+objIndex+".score.raw", viewModel.global_objectives_array()[i].score());
                doSetValue("cmi.objectives."+objIndex+".score.min", "0");
                doSetValue("cmi.objectives."+objIndex+".score.max", "100");
                doSetValue("cmi.objectives."+objIndex+".score.scaled", viewModel.global_objectives_array()[i].score_scaled());
                doSetValue("cmi.objectives."+objIndex+".progress_measure", viewModel.global_objectives_array()[i].score_scaled());
                doSetValue("cmi.objectives."+objIndex+".completion_status", viewModel.global_objectives_array()[i].completed());
                doSetValue("cmi.objectives."+objIndex+".success_status", viewModel.global_objectives_array()[i].satisfied());
                doSetValue("cmi.objectives."+objIndex+".description", viewModel.global_objectives_array()[i].description);
            }
            if(viewModel.global_objectives_array()[i].name == "primary"){
                if(viewModel.labs()[viewModel.selected_lab()].quiz_score() != -1 || viewModel._data.test() == 'true'){
                    doSetValue("cmi.objectives."+objIndex+".score.raw", viewModel.global_objectives_array()[i].score());
                    
                    doSetValue("cmi.objectives."+objIndex+".score.scaled", viewModel.global_objectives_array()[i].score_scaled());
                    doSetValue("cmi.objectives."+objIndex+".progress_measure", viewModel.global_objectives_array()[i].score_scaled());
                    doSetValue("cmi.score.raw", viewModel.global_objectives_array()[i].score());
                    
                    doSetValue("cmi.score.scaled", viewModel.global_objectives_array()[i].score_scaled());
                    doSetValue("cmi.progress_measure", viewModel.global_objectives_array()[i].score_scaled());
                }
                else{
                    doSetValue("cmi.objectives."+objIndex+".score.raw", "0");
                    
                    doSetValue("cmi.objectives."+objIndex+".score.scaled", "0");
                    doSetValue("cmi.objectives."+objIndex+".progress_measure", "0");
                    doSetValue("cmi.score.raw", "0");
                    
                    doSetValue("cmi.score.scaled", "0");
                    doSetValue("cmi.progress_measure", "0");
                }
                doSetValue("cmi.score.min", "0");
                doSetValue("cmi.score.max", "100");
                doSetValue("cmi.objectives."+objIndex+".score.min", "0");
                doSetValue("cmi.objectives."+objIndex+".score.max", "100");
                doSetValue("cmi.objectives."+objIndex+".completion_status", viewModel.global_objectives_array()[i].completed());
                doSetValue("cmi.objectives."+objIndex+".success_status", viewModel.global_objectives_array()[i].satisfied());
                doSetValue("cmi.completion_status", viewModel.global_objectives_array()[i].completed());
                doSetValue("cmi.success_status", viewModel.global_objectives_array()[i].satisfied());
                doSetValue("cmi.objectives."+objIndex+".description", viewModel.global_objectives_array()[i].description);
            }
            //log("name: "+ name+", score: "+ doGetValue("cmi.objectives."+objIndex+".score.raw")+", completion: "+doGetValue("cmi.objectives."+objIndex+".completion_status") +", satisfied: "+doGetValue("cmi.objectives."+objIndex+".success_status"));
        }
               
        //doSetValue("cmi.lesson_location",  viewModel.labs()[viewModel.selected_lab()].selected_group());
        doSetValue("cmi.session_time", scorm_save_time);
        viewModel.start_time = save_time;
    }
}

function product_save_scorm_interactions(){
    var numInts  = parseInt(doGetValue("cmi.interactions._count"));
    var current_ex_idx = viewModel.labs()[viewModel.selected_lab()].selected_exercise();

    if(viewModel.selected_group_name() == 'Quiz' || viewModel._data.test() == 'true'){ //do this when finishing quiz
        for(var i = 0; i<viewModel.exercise_group_types().length;++i){
            if(viewModel.exercise_group_types()[i].group == 'Quiz' || viewModel._data.test() == 'true'){
                //console.log(viewModel.exercise_group_types()[i].exercises());
                for(var j = 0, j_len = viewModel.exercise_group_types()[i].exercises().length; j<j_len; ++j){
                    var quiz_ex_idx = viewModel.exercise_group_types()[i].exercises()[j];
                    //console.log("in outer quiz loop and set quiz_ex_idx to: "+ quiz_ex_idx+" which references "+ viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].type())
                    //don't send data for RSLT pages
                    if(viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].type()!= 'RSLT'){
                        for(var k= 0; k<viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions().length; ++k){
                            if(viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().result() == "correct" || viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().result() == "incorrect"){
                                doSetValue("cmi.interactions."+numInts+".id", viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().id());
                                doSetValue("cmi.interactions."+numInts+".type", viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().type());
                                doSetValue("cmi.interactions."+numInts+".description", viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().description());
                                doSetValue("cmi.interactions."+numInts+".correct_responses.0.pattern", viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().correct_ans());
                                doSetValue("cmi.interactions."+numInts+".learner_response", viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().user_ans());
                                doSetValue("cmi.interactions."+numInts+".result", viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().result());
                            
                                //console.log("ex:"+viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].type()+", q:"+quiz_ex_idx+", type:"+viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().type()+", desc:"+viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().description()+", correct_ans:"+viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().correct_ans());
                                //console.log("id:"+viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().id()+", user_ans:"+viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().user_ans()+", result:"+viewModel.labs()[viewModel.selected_lab()].exercises()[quiz_ex_idx].questions()[k].scorm_info().result());

                                numInts += 1;                            
                            }
                        }
                    } 
                }
            }
        }
    }
    else{
        if(typeof viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx] !== "undefined"){
            if(viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].type() != "WLC" || viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].type() != "STI" || viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].type() != "RSLT" || viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].type() != "DWS"){
                //console.log("i try to set interations with numInts = "+ numInts);
                for(var i = 0; i<viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions().length; ++i){
                    //console.log("in the loop, whoop!");;
                    if(viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().result() == "correct" || viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().result() == "incorrect"){
                        doSetValue("cmi.interactions."+numInts+".id", viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().id());
                        doSetValue("cmi.interactions."+numInts+".type", viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().type());
                        doSetValue("cmi.interactions."+numInts+".description", viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().description());
                        doSetValue("cmi.interactions."+numInts+".correct_responses.0.pattern", viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().correct_ans());
                        doSetValue("cmi.interactions."+numInts+".learner_response", viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().user_ans());
                        doSetValue("cmi.interactions."+numInts+".result", viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().result());
                        
                        //console.log("ex:"+viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].type()+", q:"+current_ex_idx+", type:"+viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().type()+", desc:"+viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().description()+", correct_ans:"+viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().correct_ans());
                        //console.log("id:"+viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().id()+", user_ans:"+viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().user_ans()+", result:"+viewModel.labs()[viewModel.selected_lab()].exercises()[current_ex_idx].questions()[i].scorm_info().result());

                        numInts += 1;
                    }
                }
            }
        }
    }
}

//This function is only used for testing to print info
function product_print_scorm_data(){
    for(i=0; i<viewModel.global_objectives_array().length; ++i){
        var objIndex = FindObjectiveIndex(viewModel.global_objectives_array()[i].name);
        //log(doGetValue("cmi.objectives."+objIndex+".score.raw"));
        //log(doGetValue("cmi.objectives."+objIndex+".completion_status"));
        //log(doGetValue("cmi.objectives."+objIndex+".success_status"));
    }
}

function product_load_scorm_progress(){
    //log("scorm load progress");
    for(i=0; i<viewModel.global_objectives_array().length; ++i){
        var name = viewModel.global_objectives_array()[i].name;
        if(!(name.match(/secondary_/))){
            var objIndex = FindObjectiveIndex(viewModel.global_objectives_array()[i].name);
            if(!(name.match(/primary/))){
                if(doGetValue("cmi.objectives."+objIndex+".score.raw")){
                    viewModel.global_objectives_array()[i].score(doGetValue("cmi.objectives."+objIndex+".score.raw"));
                }
                if(doGetValue("cmi.objectives."+objIndex+".completion_status")){
                    viewModel.global_objectives_array()[i].completed(doGetValue("cmi.objectives."+objIndex+".completion_status"));
                }
                if(doGetValue("cmi.objectives."+objIndex+".success_status")){
                    viewModel.global_objectives_array()[i].satisfied(doGetValue("cmi.objectives."+objIndex+".success_status"));
                }
            }
            else if(viewModel.has_quiz()){
                viewModel.global_objectives_array()[i].completed(doGetValue("cmi.objectives."+objIndex+".completion_status"));
                //viewModel.global_objectives_array()[i].satisfied(doGetValue("cmi.objectives."+objIndex+".success_status"));
            }
            
            //doSetValue("cmi.objectives."+objIndex+".progress_measure", viewModel.global_objectives_array()[i].score_scaled());
            //viewModel.global_objectives_array()[i].completed(doGetValue("cmi.objectives."+objIndex+".completion_status"));
            //viewModel.global_objectives_array()[i].satisfied(doGetValue("cmi.objectives."+objIndex+".success_status"));
        }
        //log("name: "+ viewModel.global_objectives_array()[i].name+", score: "+ viewModel.global_objectives_array()[i].score()+", completion: "+viewModel.global_objectives_array()[i].completed() +", satisfied: "+viewModel.global_objectives_array()[i].satisfied());      
    }
    //viewModel.labs()[viewModel.selected_lab()].selected_group(doGetValue("cmi.lesson_location"));
}

function product_first_load_scorm_actions(){
    for(i=0; i<viewModel.global_objectives_array().length; ++i){
        var name = viewModel.global_objectives_array()[i].name;
        var objIndex = FindObjectiveIndex(name);
        if(viewModel.global_objectives_array()[i].name == "primary"){
            if(viewModel.labs()[viewModel.selected_lab()].quiz_score() != -1 || viewModel._data.test() == 'true' && viewModel.AT_score() != -1){
                doSetValue("cmi.objectives."+objIndex+".score.raw", viewModel.global_objectives_array()[i].score());
                
                doSetValue("cmi.objectives."+objIndex+".score.scaled", viewModel.global_objectives_array()[i].score_scaled());
                doSetValue("cmi.objectives."+objIndex+".progress_measure", viewModel.global_objectives_array()[i].score_scaled());
                doSetValue("cmi.score.raw", viewModel.global_objectives_array()[i].score());
                
                doSetValue("cmi.score.scaled", viewModel.global_objectives_array()[i].score_scaled());
                doSetValue("cmi.progress_measure", viewModel.global_objectives_array()[i].score_scaled());
            }
            else{
                doSetValue("cmi.objectives."+objIndex+".score.raw", "0");
                
                doSetValue("cmi.objectives."+objIndex+".score.scaled", "0");
                doSetValue("cmi.objectives."+objIndex+".progress_measure", "0");
                doSetValue("cmi.score.raw", "0");
                
                doSetValue("cmi.score.scaled", "0");
                doSetValue("cmi.progress_measure", "0");
            }
            doSetValue("cmi.score.min", "0");
            doSetValue("cmi.score.max", "100");
            doSetValue("cmi.objectives."+objIndex+".score.min", "0");
            doSetValue("cmi.objectives."+objIndex+".score.max", "100");
            doSetValue("cmi.objectives."+objIndex+".completion_status", viewModel.global_objectives_array()[i].completed());
            doSetValue("cmi.objectives."+objIndex+".success_status", viewModel.global_objectives_array()[i].satisfied());
            doSetValue("cmi.completion_status", viewModel.global_objectives_array()[i].completed());
            doSetValue("cmi.success_status", viewModel.global_objectives_array()[i].satisfied());
        }
        else{
            doSetValue("cmi.objectives."+objIndex+".score.raw", viewModel.global_objectives_array()[i].score());
            doSetValue("cmi.objectives."+objIndex+".score.min", "0");
            doSetValue("cmi.objectives."+objIndex+".score.max", "100");
            doSetValue("cmi.objectives."+objIndex+".score.scaled", viewModel.global_objectives_array()[i].score_scaled());
            doSetValue("cmi.objectives."+objIndex+".progress_measure", viewModel.global_objectives_array()[i].score_scaled());
            doSetValue("cmi.objectives."+objIndex+".completion_status", viewModel.global_objectives_array()[i].completed());
            doSetValue("cmi.objectives."+objIndex+".success_status", viewModel.global_objectives_array()[i].satisfied());
        }
        //log("name: "+ name+", score: "+ doGetValue("cmi.objectives."+objIndex+".score.raw")+", completion: "+doGetValue("cmi.objectives."+objIndex+".completion_status") +", satisfied: "+doGetValue("cmi.objectives."+objIndex+".success_status"));
    }
}

function product_lab_model(obj)
{
    //Number of displayed exercises in the nav bar
    // obj.max_exercises = ko.observable(obj.exercises().length - 1);
    obj.max_exercises = ko.observable(obj.exercises().length);
    //Whether or not enough correct questions have been answered to pass the test
    obj.passed = ko.observable(false);
    obj.restore_exercise_num = ko.observable(0);
    obj.exercises_to_delete = ko.observableArray([]);
    //List of tss stimuli
    obj.tss_stimuli = ko.observableArray([]);
    obj.selected_group = ko.observable(0);
    obj.selected_group_current_exercise_idx = ko.observable(0);
    obj.previous_group = ko.observable(0);
    obj.show_group_nav = ko.observable(false);
    obj.first_group_load = ko.observable(false);

    obj.container_height = ko.observable(0);
    obj.quiz_score = ko.observable(-1);
    obj.group_bar_initilized = ko.observable(false);
    obj.is_sliding = ko.observable(false);

    obj.pause_audio = function(lab_id,stimuli_ids)
    {
        //Loop through all the stimuli
        for(var i = 0; i < obj.stimuli().length; ++i)
        {
            //Make sure the stimuli is audio and that the stimuli has changed
            if(obj.stimuli()[i].type() == "audio" && stimuli_ids.indexOf(i) == -1 || obj.stimuli()[i].type() == "video" && stimuli_ids.indexOf(i) == -1)
            {
                if ($('#audio_slideshow_0_'+obj.stimuli()[i].id()).length > 0)
                {
                    //Check to see if the audio is still playing or not
                    if (!$('#audio_slideshow_0_'+obj.stimuli()[i].id())[0].paused)
                    {
                        //pause the audio
                        $('#audio_slideshow_0_'+obj.stimuli()[i].id())[0].player.pause();
                    }
                }
                if ($('#video_scrolltext_0_'+obj.stimuli()[i].id()).length > 0)
                {
                    //Check to see if the audio is still playing or not
                    if (!$('#video_scrolltext_0_'+obj.stimuli()[i].id())[0].paused)
                    {
                        //pause the audio
                        $('#video_scrolltext_0_'+obj.stimuli()[i].id())[0].player.pause();
                    }
                }
            }
        }
    };    
    
    //Sets up the audio container
    obj.adjust_audio_container = function()
    {
        //Loop through all the stimuli on the exercise
        for(var i = 0; i < obj.stimuli().length; ++i)
        {
            //Check to make sure that the stimuli contains an audio source
            //THIS NEEDS TO BE SORTED OUT IN TO THE RIGHT STIMULI OBJECT!!!!!!!!!!!!!!!!!!!!1!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            if (obj.stimuli()[i].type() == "audio")
                obj.stimuli()[i].show_progress("audio_slideshow_0_"+i);    
            if(obj.stimuli()[i].type() == "video")    
                obj.stimuli()[i].show_progress("video_scrolltext_0_"+i);
        }
    };
    
    obj.adjust_video_container = function()
    {
        var videos = $('.video_instruction');
        for (var l = 0; l < videos.length; ++l)
        {        
            if(videos[l].offsetParent !== null && typeof $('#'+videos[l].id)[0].stop === 'undefined' && ('#'+videos[l].id).indexOf('mep') == -1)
            {
                //alert(typeof $('#'+videos[l].id).player);
                if(videos[l].id.indexOf('video')>-1)
                {
                    // //log('init player in sadjust_video_container');
                    $('#'+videos[l].id).mediaelementplayer({
                        audioWidth: '100%',
                        audioHeight: '100%',
                        loop: false,
                        startVolume: 0.8,
                        preLoad: true,
                        features: ['playpause', 'current', 'progress', 'volume', 'fullscreen'],
                        alwaysShowControls: true,
                        alwaysShowHours: false,
                        showTimecodeFrameCount: false,
                        pauseOtherPlayers: true,
                        pluginPath: '/static/framework/media-elements/',
                        flashName: 'flashmediaelement.swf'                    
                    });
                }
            }
            
            else
            {
                if(videos[l].id.indexOf('video')>-1)
                {
                    if (!$('#'+videos[l].id)[0].paused)
                    {
                        play_audio();
                        if(!isMobileSafari())
                            $('#'+videos[l].id)[0].player.pause();
                        else
                            $('#'+videos[l].id)[0].pause();
                    }
                }
            }
        }
        var fullscreen_btn = $('.mejs-fullscreen-button');

        for (var l = 0; l < fullscreen_btn.length; ++l)
        {
            if(fullscreen_btn[l].offsetParent !== null)
            {
                if(!$(fullscreen_btn[l]).hasClass("sena-icon")){
                    $(fullscreen_btn[l]).addClass("sena-icon sena-icon-fullscreen fullscreen-video-button link-cursor");
                    $($(fullscreen_btn[l]).children()[0]).css({ "visibility": "hidden"});
                    //fullscreen_btn.children()[0].remove();
                    $(fullscreen_btn[l]).click(function(ev)
                    {
                        if(!isMobileSafari())
                        {
                            $('#framework_header').css({ "visibility": "hidden"});
                            $('#main').css({ "padding": "0"});  
                        }      
                    });
                }
            }
        }

        
    }
    
    //REEVALUATE Sena doesn't use this at all, not sure if other products do (KT)
    //Gets the current exercise number to display in the nav bar.
    obj.display_current_selected_exercise = function()
    {
        //Get the current selected exercise num
        var ret = obj.selected_exercise()+1;
        
        //If it's 0 that means it's on a welcome page which shouldn't be displayed
        // if (obj.selected_exercise() == 0)
        //     ret = 1;
        
        //If it's past the max then it's on a results page
        if (obj.selected_exercise() > obj.max_exercises())
            ret = obj.max_exercises();
        
        return ret.toString();
    }
    
    //Gets the first exercise of the group that is being selected.
    //group_name = The name of the group that is being selected.
    obj.get_group_exercise = function(group_name) //REEVALUATE now that exercises is in the exercise group types global observable array
    {
        // if(group_name == 'Quiz' && obj.quiz_score() != -1){
        //     for (var i = 0, len = obj.exercises().length; i < len; ++i)
        //     {
        //         if(obj.exercises()[i].type()=="RSLT"){
        //             //Select the correct exercise
        //             product_select_exercise(obj, i);
        //             //Call resize events so the windows doesn't get messed up (nav gets wacky without)
        //             product_helper_fire_resize_events();
        //             break;
        //         }       
        //     }
        // }
        // else{ //if there has been progress on the exercise go to the last exercise selected in the group
            viewModel.set_group_selected_exercise(viewModel.get_group_selected_exercise());
            //Select the correct exercise
            product_select_exercise(obj, viewModel.exercise_group_types()[obj.selected_group()].exercises()[viewModel.get_group_selected_exercise()]);        
            //Call resize events so the windows doesn't get messed up (nav gets wacky without)
            product_helper_fire_resize_events();
            //Exit the function since we have found what we need
        //}
    };
    
    //Gets the number of exercises in each group and adds the correct exercise numbers accordingly.
    //Gets called in product_core_start_lesson() when the product starts.
    obj.get_group_count = function()
    {
        var objectives_duplicate_check = false;
        for (var i = 0, len = obj.exercises().length; i < len; ++i)
        {
            for (var k = 0, k_len = obj.exercises()[i]._data().length; k < k_len; ++k)
            {
                if (obj.exercises()[i]._data()[k].type() == "group")
                {
                    //Loop through all the group types to see if the current group matches any of them
                    for (var l = 0; l < viewModel.exercise_group_types().length; ++l)
                    {
                        if (viewModel.exercise_group_types()[l].group == obj.exercises()[i]._data()[k].contents()[0].content())
                        {
                            obj.show_group_nav(true);
                            //Increase the counter for the current group
                            viewModel.exercise_group_types()[l].count(viewModel.exercise_group_types()[l].count() + 1);
                            //Add the exercise number to the group
                            viewModel.exercise_group_types()[l].exercises.push(i);
                            break;
                        }
                    }
                }
            }
        }
    };
    
    //Sets the correct radio button for group exercises in the edit header on start
    //Called when a radio button is clicked on and sets the correct group to an exercise. Will
    //increase/decrease counters and exercise numbers accordingly.
    obj.set_current_group = function(_data, new_group,exer_id)
    {
        for (var i = 0, i_len = _data().length; i < i_len; ++i)
        {
            if (_data()[i].type() == "group")
            {
                if (typeof new_group === 'undefined')
                    return _data()[i].contents()[0].content();
                else if (new_group != _data()[i].contents()[0].content()) //Make sure we aren't adding the same exercise number to the same group
                {
                    for (var k = 0, k_len = viewModel.exercise_group_types().length; k < k_len; ++k )
                    {
                        //Find the current group before replacing it
                        if (viewModel.exercise_group_types()[k].group == _data()[i].contents()[0].content())
                        {
                            //Decrease the counter since an exercise is being removed
                            viewModel.exercise_group_types()[k].count(viewModel.exercise_group_types()[k].count() - 1);
                            //Remove the exercise number from the old group
                            viewModel.exercise_group_types()[k].exercises.remove(exer_id);
                            break;
                        }
                    }

                    //Use a second loop to make sure that content() has not been overridden before using it to get the old group
                    for (var k = 0, k_len = viewModel.exercise_group_types().length; k < k_len; ++k )
                    {
                        if (new_group == viewModel.exercise_group_types()[k].group)
                        {
                            //Set the current selected group on the lab
                            viewModel.labs()[viewModel.selected_lab()].selected_group(k);
                            //Set the new group name
                            _data()[i].contents()[0].content(new_group);
                            //Increase the counter for the group, to make sure we don't go over the limit
                            viewModel.exercise_group_types()[k].count(viewModel.exercise_group_types()[k].count() + 1);
                            //Add the new exercise number to the list in the group
                            viewModel.exercise_group_types()[k].exercises.push(exer_id);
                            //Sort the array to make sure the exercise numbers are in order when displayed
                            viewModel.exercise_group_types()[k].exercises.sort();
                            
                            break;
                        }
                    }
                }
            }
        }

        //Select the first exercise in the group to make sure an available exercise is selected
        ////log(obj.selected_group());
        ////log(viewModel.exercise_group_types()[obj.selected_group()].exercises()[0]);
        obj.selected_exercise(viewModel.exercise_group_types()[obj.selected_group()].exercises()[0]);

        product_helper_fire_resize_events();
        
        return "";
    };
    
    //Changes the currently selected exercise group.
    //Gets called when an exercise group is clicked on from the group bar at the bottom.
    obj.change_group = function(group_index)
    {
        //log("change group with group index: "+group_index);
        viewModel.get_progress();
        //if no submit button save progress upon changing group
        if(!viewModel.is_group_sans_objs()){
            for(var j = 0; j<viewModel.disabled_submit_exes().length;++j){
                if(obj.exercises()[obj.selected_exercise()].type() == viewModel.disabled_submit_exes()[j] && obj.exercises()[obj.selected_exercise()].type() != "TTT" && obj.exercises()[obj.selected_exercise()].type() != "RSLT"){
                    // called for handling objective satisfaction and completion
                    obj.exercises()[obj.selected_exercise()].check_answers();
                    if(initialized){
                        product_save_scorm_interactions();
                    }
                }
            }
        }
		// console.log(viewModel.number_of_sco_groups());
        if(initialized && viewModel.number_of_sco_groups() > 1){ // don't send objectives for single DR's
            product_save_scorm_progress();
        }
        
        if(group_index !== viewModel.labs()[viewModel.selected_lab()].selected_group() || !obj.first_group_load()){
            obj.first_group_load(true);
            //Only change the selected exercise group if there are exercises in it
            if (viewModel.exercise_group_types()[group_index].count() > 0)
            {
                // record to previous group for transition
                var current_group = viewModel.labs()[viewModel.selected_lab()].selected_group();
                viewModel.labs()[viewModel.selected_lab()].previous_group(current_group);

                //Change the group
                viewModel.labs()[viewModel.selected_lab()].selected_group(group_index);

                //Find and selects the first exercise in the selected group
                obj.get_group_exercise(viewModel.exercise_group_types()[group_index].group);
                
                // unset the prev group so transition doesn't get confused
                viewModel.labs()[viewModel.selected_lab()].previous_group(group_index);

                sfx_player('navigate-main');
            }
        }
        //Objective actions on group navigation if it's a group that requires it and the first exercise isn't a no submit button exercise
        if(viewModel.is_group_sans_objs()){
            obj.handle_objectives_on_group_nav();
        }
        obj.do_progress_actions();
    }

    obj.do_progress_actions = function(){
        viewModel.get_progress(); //get progress has to be first so that the question info is set
        if(initialized && viewModel.number_of_sco_groups() > 1){ // don't send objectives for single DR's
            product_save_scorm_progress();
        }
    }

    obj.handle_objectives_on_group_nav =function(){
        //Checks to see if switching to a welcome, content or take away page and sets them to complete immediately
        //log("handle objectives on load");
/*         for(var i=0; i<viewModel.global_objectives_array().length; ++i){
            //log(viewModel.global_objectives_array()[i].group);
            if(viewModel.global_objectives_array()[i].group == viewModel.selected_group_name()){
                if(viewModel.global_objectives_array()[i].name == "welcome" || viewModel.global_objectives_array()[i].name == "content" || viewModel.global_objectives_array()[i].name == "take_away"){
                    viewModel.global_objectives_array()[i].completed("completed");
                    viewModel.global_objectives_array()[i].satisfied("passed");
                    viewModel.global_objectives_array()[i].score(100);
                }
            }
        } */
    }
 
    
    //Navigation within the group where idx is the index of the desired exercise within the exercises array of the selected group in exercise_group_types array
    obj.change_group_exercise = function(idx)
    {
        //log(idx);
        viewModel.set_group_selected_exercise(idx);
        //log(viewModel.exercise_group_types()[obj.selected_group()].exercises()[viewModel.get_group_selected_exercise()]);
        product_select_exercise(obj, viewModel.exercise_group_types()[obj.selected_group()].exercises()[viewModel.get_group_selected_exercise()]);
        obj.do_progress_actions();
        product_helper_update_container_height();
    }
    
    //Checks all the exercises in the quiz group to see if they have all been answered. This is
    //used to enable / disable the submit button. Submit button will only be enabled in a quiz if
    //all the exercises have been answered.
    obj.show_group_quiz_submit = function()
    {
        ret = true;
        
        if (viewModel.exercise_group_types()[obj.selected_group()].group == "Quiz")
        {
            for (var i = 0; i < viewModel.exercise_group_types()[obj.selected_group()].exercises().length; ++i)
            {
                if(!(obj.exercises()[viewModel.exercise_group_types()[obj.selected_group()].exercises()[i]].type() == "RSLT")){
                    if (!obj.exercises()[viewModel.exercise_group_types()[obj.selected_group()].exercises()[i]].check_answer_enabled())
                        ret = false;
                }   
            }
        }       
        return ret;
    }
    
    //Used to enable/disable the submit button on an exercise.
    obj.enable_submit_button = function()
    {
        var ret = true;

        //If not checking answers, disable
        if (obj.exercises()[obj.selected_exercise()].check_answer_enabled() != true)
            ret = false;
        //If currently in a quiz and not finished, disable
        if (!obj.show_group_quiz_submit())
            ret = false;
        
        //Check to see if current exercise is GWR.
        //If on the final writing planner stage, enable
        if (obj.exercises()[obj.selected_exercise()].type() == "GWR")
        {
            if (typeof obj.exercises()[obj.selected_exercise()].finished_writing_planner !== 'undefined' && obj.exercises()[obj.selected_exercise()].finished_writing_planner() == 1)
                ret = true;
        }
        
        //If it's an achievement test, do it's on enable logic
        if (viewModel._data.test() == 'true' && viewModel.show_achievement_test_submit() == false)
            ret = false;
        
        return ret;
    }
    
    //Calculates all the exercises part of the quiz group.
    obj.calc_group_quiz = function()
    {
        for (var i = 0; i < viewModel.exercise_group_types()[obj.selected_group()].exercises().length; ++i){
           obj.exercises()[viewModel.exercise_group_types()[obj.selected_group()].exercises()[i]].check_answers(); 
        }
        obj.quiz_score(Math.round(product_core_grade_LO('Quiz')));
    }
	
    //Called when the exercise submit button is pressed. 
    obj.submit_button = function()
    {
        if (viewModel._data.test() == 'false')
        {
            //Check to see if the current exercise group is part of a quiz
            if (viewModel.exercise_group_types()[obj.selected_group()].group != "Quiz")
            {
                //Check the answer of the current exercise
                obj.exercises()[obj.selected_exercise()].check_answers();
                //Show the feedback modal
                $('#feedback-modal').modal('show');
            }
            else
            {
                //If currently in a quiz, it will check all the correct exercises
                obj.calc_group_quiz();
                obj.change_group_exercise(viewModel.exercise_group_types()[obj.selected_group()].exercises().length-1);
                for(var i = 0; i<viewModel.global_objectives_array().length; ++i){
                    if(viewModel.global_objectives_array()[i].name == 'primary'){
                        //viewModel.global_objectives_array()[i].satisfied("passed");
                        viewModel.global_objectives_array()[i].completed("completed");
                    }
                }  
            }
        }
        else
        {
            obj.change_group(6);
        }
		
        obj.do_progress_actions();
        if(initialized){
            product_save_scorm_interactions();
        }
    }

    obj.nav_bar_showing = ko.computed( function(){
        var ret = true;
        
        if (obj.show_group_nav() == true && viewModel.exercise_group_types()[viewModel.labs()[viewModel.selected_lab()].selected_group()].count() < 2)
        {
            ret = false;
        }
        if (typeof viewModel !== 'undefined' && viewModel._data.test() == 'true')
            ret = true;
  
        return ret;
    });

    obj.grading_chart_total = ko.computed( function(){
        var total = 0;
        if(obj.type() == "oed" && obj.id() == 3)
        {          
            ko.utils.arrayForEach(obj.grading_chart.body.rows(), function (item) {                
                if(item.selected_cell())
                {
                    total += parseInt(item.cells()[item.selected_cell()].points());
                }
            });
        }
        return total;
    });

    obj.reset_grading_chart = function(){//PS
        ko.utils.arrayForEach(obj.grading_chart.body.rows(), function (item) {                
            if(item.selected_cell())
            {
                item.selected_cell(0);
            }
        });
    };
    
    //Check to see if the lab is a writing planner or writing task
    if(obj.type() == "oed")
        obj.local_type(helper_get_local_string(obj.type()+obj.id())); //Append the lab number to the local type
    else
        obj.local_type(ko.observable(helper_get_local_string(obj.type())));

    // obj.maintain_stimuli_data = ko.computed(function(){
    //     if(obj.stimuli !== undefined){
    //         for (var i = 0, len = obj.stimuli().length; i < len; ++i){
    //             obj.stimuli()[i].id(i);
    //         }
    //     }
    // });

    obj.maintain_exercises_data = ko.computed(function(){
        // console.log('here');
        if(obj.exercises !== undefined){
            for (var i = 0, len = obj.exercises().length; i < len; ++i){
                obj.exercises()[i].id(i);
            }
        }
    });

    // obj.exercises.subscribe(function(){
        // if(obj.exercises !== undefined){
            // for (var i = 0, len = obj.exercises().length; i < len; ++i){
                // obj.exercises()[i].id(i);
            // }
        // }
    // });

    obj.stimuli_nav_showing = ko.computed(function(){
        if(obj.exercises()[obj.selected_exercise()].type() != 'WLC' && obj.exercises()[obj.selected_exercise()].stimuli_ids().length > 1){
            return true;
        }
        return false;
    });

    obj.has_stimuli = ko.computed(function(){
        if(obj.exercises()[obj.selected_exercise()].stimuli_ids().length){
            return true;
        }
        return false;
    });

    obj.get_stimuli_id_from_idx = function(idx){
        return obj.stimuli()[idx].id();
    }

    obj.get_stimuli_idx_from_id = function(id){
        for(var i = 0, i_len = obj.stimuli().length; i<i_len;++i){          
            if(id == obj.stimuli()[i].id()){
                return i;
            }
        }
    }

    obj.select_stimuli = function(id){
        obj.selected_stimuli(obj.get_stimuli_idx_from_id(id));
    }

    obj.stimuli_col_size = ko.computed(function(){
        if(obj.exercises()[obj.selected_exercise()].type() == 'STI'){
            return 'col-xs-12';
        }
        else{
            return 'col-xs-4';
        }
    });

    obj.ex_col_size = ko.computed(function(){
        if(obj.exercises()[obj.selected_exercise()].type() != 'STI' && obj.has_stimuli()){
            return 'col-xs-8';
        }
        else{
            return 'col-xs-12';
        }
    });

    obj.stimuli_checker = function(part)
    {
        var ret = 0;
        if (part == 1)
        {   //check to see if there is a single stimuli and make sure it is not stimuli 0 or that we are on the welcome page
            if (obj.exercises()[obj.selected_exercise()].type() != 'WLC' && obj.exercises()[obj.selected_exercise()].stimuli_ids().length == 1 && obj.exercises()[obj.selected_exercise()].stimuli_ids()[0] != 0)
            {
                ret = 1;
            }
        }
        else if (part == 2)
        {   // make sure we are not on the welcome page, check to see that we have more than one stimuli
            if (obj.exercises()[obj.selected_exercise()].type() != 'WLC' && obj.exercises()[obj.selected_exercise()].stimuli_ids().length > 1)
            {
                ret = 1;
            }
        }
        else if (part == 3)
        {   
            if (obj.exercises()[obj.selected_exercise()].stimuli_ids().length == 1 && obj.exercises()[obj.selected_exercise()].stimuli_ids()[0] != 0 || obj.exercises()[obj.selected_exercise()].stimuli_ids().length > 1)
            {
                ret = 1;
            }
        }
        else if (part == 4)
        {   
            if (obj.exercises()[obj.selected_exercise()].stimuli_ids().length == 1 && obj.exercises()[obj.selected_exercise()].stimuli_ids()[0] == 0 || obj.exercises()[obj.selected_exercise()].stimuli_ids().length == 0)
            {
                ret =  1;
            }
        }
        return ret;
    }

    
    if(is_editable)
    {
        edit_lab_model(obj);
        product_edit_lab_model(obj);
    }
    
    //Returns what learning skills are available in the current lab.
    //Will go through each exercise and group together the learning skills, will not show repeats.
    obj.get_learning_skills = function()
    {
        var ret = [];
        
        //Loop through each exercise in the lab
        for(var i = 0; i < obj.exercises().length; ++i)
        {
            //Loop through each learning skill that is on the exercise
            for (var k = 0; k < obj.exercises()[i]._data.learning_skills().length; ++k)
            {
                //If the current learning skill is not already in the array, then add it
                if (ret.indexOf(obj.exercises()[i]._data.learning_skills()[k]) == -1)
                    ret.push(obj.exercises()[i]._data.learning_skills()[k]);
            }
            //If the array already has all the possible learning skills, then leave the loop
            if (ret.length > 3)
                break;
        }

        //Return the final array of available learning skills
        return ret;
    }
    
    obj.selected_stimuli.subscribe(function() {
        viewModel.init_tool_tip(obj.stimuli()[obj.selected_stimuli()]._data(), true);
    });

    obj.pre_screen_close = function(value)
    {
        //console.log('hello');
        if( typeof obj.exercises()[value].dragdrop !== 'undefined' && !obj.exercises()[value].dragdrop.initiated()) //EXS
        {
            obj.exercises()[value].dragdrop.init();
            adjust_drag_item_positions(obj.exercises()[value].dragdrop);
        }
        
        if(product_helper_is_drag_drop_type(obj.exercises()[value].type())){ //EXS
            product_helper_update_container_height();
            product_helper_adjust_single_drop_positions();
            product_helper_adjust_MF1_response_container(); // fix for mf1 response container width on progress restore
        }
    }
}

//Lab level product functions
function product_select_exercise(obj, value)
{
    //log("select exercise");
    //log("Group id: "+viewModel.labs()[viewModel.selected_lab()].selected_group()+", Group name: "+viewModel.selected_group_name()+', Exercise id: '+ value);
    
   //show pre-screen if available
    if(obj.exercises()[value].type() != "WLC") //EXS
    {
        // adjust ex container here?
        for(var i = 0; i < obj.exercises()[value]._data().length; ++i)
        {
            if (obj.exercises()[value]._data()[i].type() == "pre_screen")
            {
                if(!obj.exercises()[value].shown_pre_screen())
                    obj.hiding_pre_screen(0);
            }
        }
    } 
    
    if(viewModel.use_slide_transition() && obj.selected_group() !== 0) { // is a user switch, show sliding; also disable if going/from wlc
        sena_slide_switch(obj, value);
    } else { // none user switch, fallback to original
        $('#'+obj.type()+'_exercises').stop();
        $('#'+obj.type()+'_exercises').hide();
        if(value >= obj.exercises().length) { value = (obj.exercises().length - 1); }
        else if(value < 0) { value = 0; }  
        $('#'+obj.type()+'_exercises').fadeIn(400);
        product_post_ex_switch(obj, value);
    }

    //will hide pre_screen if an exe doesent have one
    var flag_if_has_pre_screen = 0;
    for(var i = 0; i < obj.exercises()[value]._data().length; ++i)
    {
        if (obj.exercises()[value]._data()[i].type() == "pre_screen")
        {
            flag_if_has_pre_screen = 1;
        }
    }
    if(!flag_if_has_pre_screen)
    {
        obj.hiding_pre_screen(1);
    }
    if(!obj.group_bar_initilized() && obj.exercises()[value].type() != "WLC")
    {
        //Only enable the tooltips if the current device is not a touch device
        if ('ontouchstart' in document.documentElement == false) {    
            $('[data-toggle="tooltip"]').tooltip();
        }
        obj.group_bar_initilized(true);
    }
}

function product_post_ex_switch (obj, value) {
    // This stuff needs to happen only after switching exercise (and it is showing)
    play_audio();
      
    if(obj.exercises()[obj.selected_exercise()].type() == "SPK" && obj.exercises()[obj.selected_exercise()].started() && !obj.exercises()[obj.selected_exercise()].progress_restored())
    {
        obj.exercises()[obj.selected_exercise()].paused_timer(((Date.now() - obj.exercises()[obj.selected_exercise()].timer())/1000)+obj.exercises()[obj.selected_exercise()].paused_timer());
        //obj.exercises()[obj.selected_exercise()].spk_timer_holder(obj.exercises()[obj.selected_exercise()].spk_timer());
    }

    obj.selected_exercise(value);

    //Used for tss stimuli
    if (obj.exercises()[obj.selected_exercise()].stimuli_ids().length){
        obj.selected_stimuli(obj.get_stimuli_idx_from_id(obj.exercises()[obj.selected_exercise()].stimuli_ids()[0])); 
    }

    if(obj.exercises()[value].type() == "SPK")
    {
        product_select_exercise_spk(obj.exercises()[obj.selected_exercise()], obj.container_height());
    }
    else if(obj.exercises()[value].type() == "CWD")
		obj.exercises()[value].product_select_exercise_cwd();

    
    if( typeof obj.exercises()[value].dragdrop !== 'undefined' && !obj.exercises()[value].dragdrop.initiated() && obj.hiding_pre_screen()) //EXS
    {
        obj.exercises()[value].dragdrop.init();
        adjust_drag_item_positions(obj.exercises()[value].dragdrop);
    }
    
    if(product_helper_is_drag_drop_type(obj.exercises()[value].type())){ //EXS
        product_helper_update_container_height();
        product_helper_adjust_single_drop_positions();
        product_helper_adjust_MF1_response_container(); // fix for mf1 response container width on progress restore
    }

    obj.adjust_video_container();

    obj.adjust_audio_container();
    
    viewModel.init_tool_tip(obj.exercises()[obj.selected_exercise()]._data(), false);
    if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].type() != "WLC"){
        if (viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].stimuli_ids().length > 0){
            viewModel.init_tool_tip(obj.stimuli()[obj.selected_stimuli()]._data(), true);
        }
    }
        
    if(obj.exercises()[value].type() == "WSB"){       
        for(var i = 0; i < obj.exercises()[value].questions().length; ++i)
        {
            var content = "";
            var image_content = "";
            var is_an_iamge = false
            for(var k = 0; k < obj.exercises()[value].questions()[i]._data().length; ++k)
            {
                if (obj.exercises()[value].questions()[i]._data()[k].type() == "question")
                {
                    for(var m = 0; m < obj.exercises()[value].questions()[i]._data()[k].contents().length; ++m)
                    {
                        if(obj.exercises()[value].questions()[i]._data()[k].contents()[m].type() == "image")
                        {   
                            var theImage = new Image();
                            theImage.src = 'assets/'+viewModel.lesson_type+'/scos/'+viewModel.sco_number+'/media/image/' +obj.exercises()[value].questions()[i]._data()[k].contents()[m].content();
                            image_content = '<img class="WSB-popover-image" src='+theImage.src+' />' + "</br>";
                            is_an_iamge = true
                        }
                    }
                    for(var m = 0; m < obj.exercises()[value].questions()[i]._data()[k].contents().length; ++m)
                    {
                        if(obj.exercises()[value].questions()[i]._data()[k].contents()[m].type() != "image")
                        {
                            content = content + '<span>'+obj.exercises()[value].questions()[i]._data()[k].contents()[m].content()+'</span>' + "</br>";
                        }
                    }
                }
            }


            // var content = obj.exercises()[value].questions()[i]._data()[0].contents()[0].content();
            if(is_an_iamge)
            {
                content = '<div class="WSB-popover-text">' + content + '</div>';
                $('.WSB-pop-over-'+i).popover({
                    html: true, 
                    placement: 'top',
                    template: '<div class="popover WSB-popover"><div class="arrow WSB-popover-arrow"></div><h3 class="popover-title"></h3><div class="popover-content WSB-popover-content"></div></div>', 
                    content: '<div class="WSB-img-popover-wrapper">'+image_content + content+'</div>' 
                })
            }
            else{
                $('.WSB-pop-over-'+i).popover({
                    html: true, 
                    placement: 'top',
                    template: '<div class="popover WSB-popover"><div class="arrow WSB-popover-arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>',
                    content: content
                })
            }
        }
    }
    obj.is_sliding(false);
    //Do one final update on the container height now that the exercise is visible
    product_helper_fire_resize_events();

    if ('ontouchstart' in document.documentElement == false) {    
        $('[data-toggle="tooltip"]').tooltip();
    }
    
    if(viewModel._data.test() == 'true')
    {
        viewModel.get_exercise_start_question(obj.selected_group());
    }
    
    $(window).trigger('resize'); // to fix video size
    
}

function product_adjust_ex_container () {
    // ???
}

function product_exercise_data_model(obj)
{
    obj.learning_skills = ko.observableArray([]);

    for(var i = 0; i < obj().length; ++i)
    {
        if (obj()[i].type() == "learning_skills")
        {
            for (var k = 0; k < obj()[i].contents().length; ++k)
            {
                if (obj()[i].contents()[k].type() == "skill")
                    obj.learning_skills.push(obj()[i].contents()[k].content());
            }
        }
    }
}

function product_exercise_model(obj)
{
    obj.drag_drop_container_height = ko.observable();//PS
    obj.drag_drop_container_width = ko.observable();//PS
    obj.drag_drop_MT1_started = ko.observable(false);
    obj.slider_toggle = ko.observable(false);//PS //used for OED 3 more less instructions
    obj.drag_drop_responses_randomized = ko.observable(false);//PS
    obj.playing_recording = ko.observable(false);
    obj.is_recording = ko.observable(false);
    obj.historical_progress = ko.observable('');
    obj.playing_audio = ko.observable(false);
    obj.question_playing_flash = ko.observable(0);
    obj.feedback_showing_answer = ko.observable(false);

    //If scorm is being used, set the question scorm info used for scorm interactions
    if(initialized){
        product_helper_set_question_scorm_info(obj);
    }

    //The following was implemented to handle the new requirement that each exercise only has one objective associated with it
    if(!(obj.type() == 'WLC' || obj.type() == 'STI' || obj.type() == 'RSLT' || obj.type() == 'DWS')){
        //Observable that keeps track of what objective is selected for the exercise
        obj.exercise_objective = ko.observable("");
        //A subscribe that watches the exercise objective and whenever it changes it updates all the questions objectives to the new objective
        obj.exercise_objective.subscribe(function(value){
            //Since the select box values on the header edit update exercise_objective, if nothing is selected this makes sure we don't set the question objectives to undefined
            if(typeof value == 'undefined'){
                value = "";
            }
            for(var i = 0, i_len = obj.questions().length; i<i_len;++i){
                for(var d = 0, d_len = obj.questions()[i]._data().length; d<d_len;++d){
                    if(obj.questions()[i]._data()[d].type()=='objective'){
                        obj.questions()[i]._data()[d].content(value);
                    }
                }
            }
        });
        //On load, since the objectives are saved on the question layer, check the first question (if there is a question) and set the exercise objective to be whatever objective the first question has
        if(obj.questions().length){
            for(var d = 0, d_len = obj.questions()[0]._data().length; d<d_len;++d){
                if(obj.questions()[0]._data()[d].type()=='objective'){
                    obj.exercise_objective(obj.questions()[0]._data()[d].content());
                }
            }   
        }
    }

    obj.CWD_WDS_maintain_edit_grid = function()
    {
        //Loop through each question and add a flag for editing. Do it here instead of on the question model
        //so that it doesn't have to do the check on every single question in the lesson. Flag is used so the editing
        //tool doesn't load all the question grids on start up, which is slow.
        for (var i = 0; i < obj.questions().length; ++i)
        {
            if (obj.type() == "WDS")
                obj.questions()[i].edit_wds_grid = ko.observable(false);
            else
                obj.questions()[i].edit_cwd_grid = ko.observable(false);
        }
    }

/*     obj.STI_move_instructions = function () {
        
        
    } */
    if (obj.type() == "WLC") {
        product_helper_wlc(obj);
    }
    
    if (obj.type() == "CWD") //EXS
    {
        product_helper_exercise_cwd(obj); 
        obj.CWD_WDS_maintain_edit_grid();       
    }
    if (obj.type() == "WDS") //EXS
    {
        product_helper_exercise_wds(obj);  
        obj.CWD_WDS_maintain_edit_grid();      
    }
    if (obj.type() == "FLC")
    {
        product_helper_exercise_flc(obj);
    }
    if (obj.type() == "HNG") //EXS
    {
        product_helper_exercise_hng(obj);  
    }
    if (obj.type() == "STI") //EXS
    {
        obj.disable_solution_button(true);
        obj.disable_clear_button(true);
        obj.questions()[0].responses()[1].selected(1);
        product_check_answers(obj); 
    }
    if (obj.type() == "WSB")
    {
        product_helper_exercise_wsb(obj);    
    }
    if (obj.type() == "SPK")
    {
        product_helper_exercise_spk(obj);  
    }
    if (obj.type() == "CAS")
    {
        product_helper_exercise_cas(obj);  
    }
    if (obj.type() == "ATA")
    {
        product_helper_exercise_ata(obj);  
    }
    if (obj.type() == "TTT") //EXS
    {
        product_helper_exercise_ttt(obj);  
    }
    if (obj.type() == "GIW")
    {
       product_helper_exercise_giw(obj);   
    }
    if (obj.type() == "GWR")
    {
        product_helper_exercise_gwr(obj);  
    }
    if (obj.type() == "MCH") //EXS
    {
        product_helper_exercise_mch(obj);  
    }
    if (obj.type() == "KAR") //EXS
    {
        product_helper_exercise_kar(obj);  
    }
    if (obj.type() == "DFL")
    {
        obj.has_background_image(true); // DFL can have bckgrnd img
    }


    //custom feedback options  
    //obj.state.dispose();
    if(lesson_config_json.feedback_type != 'gen')
    {
        obj.user_action = ko.observable(0);
        obj.state = ko.computed(function(){//kinda bad logic : Update. On closer inspection this function is generic and well written          
            var state = 0//0 state for nothing started on question
            var item_states = new Array();
            var state_total = 0;            
            if(obj.check_answer() != 0)
            {                     
                ko.utils.arrayForEach(obj.questions(), function (item) {
                    if(ko.utils.unwrapObservable(item.state)){                    
                        item.check_answer(1);
                    };            
                });
            }else
            {
                obj.checked_answer(false);
            }
            obj.check_answer(0);
            ko.utils.arrayForEach(obj.questions(), function (item) {
                if(ko.utils.unwrapObservable(item.state)){                
                    item_states.push(ko.utils.unwrapObservable(item.state));
                };            
            });
            //check all states
            for (var i = 0; i < item_states.length; ++i)
            {            
                if(item_states[i] == 1 || item_states[i] == 3)
                {
                    state = 1;// at least 1 in progress if any error return 2
                }
                else if(item_states[i] == 2)
                {
                    return 2;//change me
                }
                state_total += item_states[i];
            }
            if (item_states.length && item_states.length != obj.questions().length)
            {
                return 1; //some but not all answered
            }
            else if (!item_states.length)
            {
                return 0;//none selected
            }
            else if(item_states.length == obj.questions().length)
            {            
                if (state_total/item_states.length == 4)//perfect response
                {
                    return 4;
                }            
            }               
            return state;
        });
        
        obj.check_answer_enabled = ko.computed(function(){//RG
            if(obj.state() && !obj.showing_answer() && !obj.checked_answer() && !obj.disable_check_answer() && obj.cur_question() == -1)
            {
                return true;
            }
            else
            {
                return false;
            }
        });
        obj.show_answer_enabled = ko.observable(false);   
        obj.clear_button_enabled = ko.computed(function(){//RG
            if(obj.state() && !obj.disable_clear_button())
            {
                return true;
            }
            else
            {
                return false;
            }
        }); 
        obj.show_feedback = ko.computed(function() {//RG
            if(obj.checked_answer())
            {
                return true;
            }
            return false
        });
    }
    obj.historical_state = ko.computed( function () {
        if(obj.historical_progress() != '')
        {
            if(obj.historical_progress().status == 'passed')
            {
                return 4;
            }
            else if(obj.historical_progress().status == 'failed')
            {
                return 2;
            }
            else
            {
                return 0;
            }
        }        
    });
    //Flag to show whether or not there is a rec question in the exercise
    obj.speech_question = ko.observable(false);
    if(typeof obj._data !== 'undefined')
    {
        //Loop through each question and it's _data to check for a rec question
        for (var i = 0; i < obj.questions().length; ++i)
        {
            for (var k = 0; k < obj.questions()[i]._data().length; ++k)
            {
                //Check to see if it's a question type, to avoid anything else. Check to make sure there is data inside of contents before checking for rec
                if (obj.questions()[i]._data()[k].type() == "question" && obj.questions()[i]._data()[k].contents().length > 0 && obj.questions()[i]._data()[k].contents()[0].type() == "rec")
                {
                    obj.speech_question(true); //Show that there is a rec question
                }
            }
        }
    }

    //Only create a new dragdrop if the current exercise is a drag drop type
    if(product_helper_is_drag_drop_type(obj.type())) //EXS
    {
        obj.dragdrop = new dragdrop_model(obj);
    }
    
    //Initializes the popover functionality for TYP answers.
    //Loops through each question on the exercise and finds the
    //popover objects to initialize.
    obj.init_popover = function()
    {
        for (var i = 0, len = obj.questions().length; i < len; ++i)
        {
            $('#popover_'+obj.id()+'_'+obj.questions()[i].id()).popover({container: 'body', html: true});
        }
    }
    
    obj.select_ELS_response = function(labID, responseID) //EXS
    {
        if ( $('#ELS_'+labID+'_'+responseID).hasClass('selected'))
            $('#ELS_'+labID+'_'+responseID).removeClass('selected');
        else
            $('#ELS_'+labID+'_'+responseID).addClass('selected');
    }

    obj.record_speech = function(id, player_id){
    // var check1 = sendToFlash('flash_player').checkHasMic();
    // var check2 = sendToFlash('flash_player').checkMicSecurity();
    // //log("has mic: "+check1);
    // //log("mic security: "+check2);
        obj.questions()[id].recording(! obj.questions()[id].recording());
        obj.is_recording(true);
        if(!viewModel.flash_fallback()){
            if(obj.questions()[id].recording()){
                rec_start_recording(player_id);
            }
            else{
                rec_stop_recording(player_id);
            }
        }
        else{
            if(obj.questions()[id].recording()){
                sendToFlash('flash_player').startRecording();
            }
            else{
                var wav = sendToFlash('flash_player').stopRecording();
                obj.questions()[id].flash_fallback_data(wav);
            }     
        }
    }

    obj.play_recording = function(id, player_id){
        ////log(id);
        
        if(!viewModel.flash_fallback()){
        //Check to see if the audio is already playing
            if (!obj.questions()[id].playing_recording())
            {
                //Play the audio if there is any
                document.getElementById(player_id).play();

                //Check to see if there is actual audio to be played
                if($('#'+ player_id)[0].currentSrc != "")
                {
                    //Make sure the visual icon changes
                    obj.questions()[id].playing_recording(true);
                    //Set an event to reset the icon once the audio has finished playing
                    $('#'+ player_id).bind('ended', function() {
                        obj.questions()[id].playing_recording(false);
                    });
                }
            }
            else //Stop the audio
            {
                document.getElementById(player_id).pause();
                obj.questions()[id].playing_recording(false);
            }
        }
        else{
            ////log(obj.questions()[id].flash_fallback_data());
            sendToFlash('flash_player').setSoundToPlay(obj.questions()[id].flash_fallback_data());  
            var ready_to_play_flash = sendToFlash('flash_player').checkSoundReady();
            obj.question_playing_flash(id);
            //Make sure the visual icon changes
            obj.questions()[id].playing_recording(true);
            obj.play_flash_delay = setInterval(function(){
                ready_to_play_flash = sendToFlash('flash_player').checkSoundReady();
                // //log(ready_to_play_flash); 
                if(ready_to_play_flash){sendToFlash('flash_player').playSound(); obj.clear_flash_interval();}
                }, 100); //check to see when the appropriate audio is loaded and play it when it's ready
            
        }
    }

    obj.clear_flash_interval = function(){
        clearInterval(obj.play_flash_delay);
    }
    
    obj.get_rec_question = function()
    {
        //Loop through each question and it's _data to check for a rec question
        for (var i = 0; i < obj.questions().length; ++i)
        {
            if (product_helper_check_rec_question(obj.questions()[i]._data()) || obj.type() == "REC")
                return i;

            //Check to see if it's a question type, to avoid anything else. Check to make sure there is data inside of contents before checking for rec
            // if (obj.questions()[i]._data()[k].type() == "question" && obj.questions()[i]._data()[k].contents().length > 0 && obj.questions()[i]._data()[k].contents()[0].type() == "rec" || obj.type() == "REC")
                // return i;
        }
        
        return -1;
    };

    obj.maintain_instructions = function(i){
        if(i.type() == 'table'){
            i.content(new table_model({"rows":0,"columns":0,"cells":[],"styles":""}));
        }
    }
    
    obj.speech_question.subscribe(function()
    {
        if (obj.speech_question() == true)
        {
            obj.add_speech_rec();
        }
        else
        {
            obj.remove_speech_rec();
        }
    });
    
    //Will add a speech question to the exercise.
    obj.add_speech_rec = function() 
    {
        //Add a empty question with a type of REC and some default responses
        var question_obj = {
            "_data": [{
                "type": "question",
                "contents" : [{
                    "type": "rec",
                    "content" : ""
                }]
            }],
            "id": 0,
            "responses": []
        };
        //Add the required responses to the question
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 0,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 1,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
        //Set the correct ID
        if(obj.questions().length){
            question_obj.id = obj.questions()[obj.questions().length-1].id()+1;
        }
        //Add the new question to the questions array
        obj.questions().push(new question_model(question_obj));
    }
    
    //Loops through the questions on the exercise and will remove a speech question
    //if it finds one.
    obj.remove_speech_rec = function()
    {
        //Loop through each question and find the rec question and remove it.
        for(var i = 0; i < obj.questions().length; ++i)
        {
            for (var k = 0; k < obj.questions()[i]._data().length; ++k)
            {
                if (obj.questions()[i]._data()[k].type() == "question")
                {
                    for (var c = 0; c < obj.questions()[i]._data()[k].contents().length; ++c)
                    {
                        if (obj.questions()[i]._data()[k].contents()[c].type() == "rec")
                        {
                            obj.questions().splice(i,1);
                            return; 
                        }
                    }
                }
                //Check to make sure contents exists before trying to check into it.
                // if (typeof obj.questions()[i]._data()[k].contents === "function" && obj.questions()[i]._data()[k].contents()[0].type() == "rec")
                // {
                    // obj.questions().splice(i,1);
                    // return;
                // }
            }
        }
    }
    
    obj.check_speech_question = function()
    {
        //Loop through each question and it's _data to check for a rec question
        for (var i = 0; i < obj.questions().length; ++i)
        {
            for (var k = 0; k < obj.questions()[i]._data().length; ++k)
            {
                if (obj.questions()[i]._data()[k].type() == "question")
                {
                    for (var c = 0; c < obj.questions()[i]._data()[k].contents().length; ++c)
                    {
                        if (obj.questions()[i]._data()[k].contents()[c].type() == "rec")
                            return true;
                    }
                }
                //Check to see if it's a question type, to avoid anything else. Check to make sure there is data inside of contents before checking for rec
                // if (obj.questions()[i]._data()[k].type() == "question" && obj.questions()[i]._data()[k].contents().length > 0 && obj.questions()[i]._data()[k].contents()[0].type() == "rec")
                    // return true;
            }
        }
        
        return false;
    };

    obj.maintain_questions_data = ko.computed(function(){
        if(obj.questions !== undefined){
            for (var i = 0, len = obj.questions().length; i < len; ++i){
                obj.questions()[i].id(i);
            }
        }
    });

    //Set the learning skill for the exercise. Called in the header editor.
    obj.set_learning_skill = function(skill)
    {
        var found = false;

        for (var i = 0; i < obj._data().length; ++i)
        {
            if (obj._data()[i].type() == "learning_skills")
            {
                for (var l = 0; l < obj._data()[i].contents().length; ++l)
                {
                    if (obj._data()[i].contents()[l].content() == skill)
                    {
                        obj._data()[i].contents().splice(l,1);
                        return;
                    }
                }
                found = true;
            }
        }
        
        //Learning Skills is not in the object, so add the entire thing in
        if (found == false)
        {
            obj._data.push({
                "type": ko.observable("learning_skills"),
                "contents" : ko.observableArray([{
                    "type": "skill",
                    "content": ko.observable(skill)
                }])
            })
        }
        else //Learning skills is already in the object, so we just need to add the specific skill
        {
            //Loop through the _data object until we find learning_skills
            for (var i = 0; i < obj._data().length; ++i)
            {
                if (obj._data()[i].type() == "learning_skills")
                {
                    //Push the skill to the end of learning_skills
                    obj._data()[i].contents.push({
                        "type": "skill",
                        "content": ko.observable(skill)
                    });
                }
            }
        }
    };
    
    obj.get_instructions_columns_size = function(content_index,data_index) {
        var ret = 'col-md-12 col-sm-12 col-xs-12';
        if (data_index != undefined)
        {
            if (obj._data()[data_index].contents()[content_index].type() == "image-md")
                ret = 'col-md-8 col-sm-8 col-xs-8';
            else if (obj._data()[data_index].contents()[content_index].type() == "image-sm")
                ret = 'col-lg-3 col-md-4 col-sm-4 col-xs-5';
        }
        else
        {
            for (var i = 0; i < obj._data().length; ++i)
            {
                if (obj._data()[i].type() == "instructions")
                {
                    if (obj._data()[i].contents()[content_index].type() == "image-md")
                        ret = 'col-md-8 col-sm-8 col-xs-8';
                    else if (obj._data()[i].contents()[content_index].type() == "image-sm")
                        ret = 'col-lg-3 col-md-4 col-sm-4 col-xs-5';
                }
            }
        }
        
        return ret;
    }
    
    obj.add_rec_question = function(question_idx) 
    {
        //Check to see if the question is a recording question
        if (product_helper_check_rec_question(obj.questions()[question_idx]._data()))
        {
            //Loop through the _data and check for any post_question. 
            for(var l = 0; l < obj.questions()[question_idx]._data().length; ++l)
            {
                if (obj.questions()[question_idx]._data()[l].type() == "post_question")
                {
                    //Remove post_question as it messes up TYP. And it's not needed in a rec question at all.
                    obj.questions()[question_idx]._data().splice(l,1);
                    //Reload the page to initialize the recording components
                    viewModel.edit.save();
                }
            }
        }
        else
        {
            //Check to see if switching from rec in a TYP. post_question needs to be added back.
            if (obj.type() == "TYP")
            {
                var found = false;
                for(var l = 0; l < obj.questions()[question_idx]._data().length; ++l)
                {
                    if (obj.questions()[question_idx]._data()[l].type() == "post_question")
                        found = true;
                }
                if (!found)
                {
                    obj.questions()[question_idx]._data().push({"type":"post_question", "contents": {"type": "", "content": ""}});
                    //Reload the page to initialize the recording components
                    viewModel.edit.save();
                }
            }
        }
    };
   
    //Number of tool_tips on the exercise
    obj.tip_count = ko.observable(-1);

    //Creates a tool tip for exercise instructions.
    //@content = The string content of the input nox.
    //@idx = The contents index.
    obj.create_instruction_tool_tip = function(content, idx)
    {
        //Get the start of the selected word
        var start = $('#instruction_input_' + viewModel.labs()[viewModel.selected_lab()].selected_exercise() +'_'+idx)[0].selectionStart;
        //Get the end of the selected word
        var end = $('#instruction_input_' + viewModel.labs()[viewModel.selected_lab()].selected_exercise() +'_'+idx)[0].selectionEnd;
        
        viewModel.create_tip(content, start, end, false);
    }

    if(is_editable)
    {
        product_edit_exercises_model(obj);
        edit_exercise_model(obj);
    }     
}

function product_exercise_feedback_mapping(data, exercise_obj)
{
    var self = this;
    ko.mapping.fromJS(data, {}, self);
    self.attempts = ko.observable(0);    
    self.show_feedback = ko.observable(false);
    self.current_feedback = ko.computed(function(){
        var ret = '';
        self.show_feedback(false);
        var trigger = exercise_obj.user_action();
        if(exercise_obj.cur_question() == -1)
        {
            if(exercise_obj.state() == 4)
            {
                ret = self.correct_feedback();
                self.show_feedback(true);
                product_feedback_show_answers(exercise_obj);
            }
            else if(exercise_obj.state() == 2 && exercise_obj.checked_answer() || exercise_obj.state() == 1 && exercise_obj.checked_answer())
            {
                ret = self.incorrect_feedback()[self.attempts()].content();
                self.show_feedback(true);
                if(self.attempts() == 1)
                {
                    if(!exercise_obj.disable_clear_button())
                    {
                        if (exercise_obj.type() != "MT1")
                            exercise_obj.showing_answer(true);
                        if (typeof exercise_obj.dragdrop !== 'undefined')
                        {
                            //Disable all the pep objects on the current exercise
                            for(var k = 0, lenT = exercise_obj.dragdrop.pep_objs().length; k < lenT; ++k)
                                $.pep.peps[exercise_obj.dragdrop.pep_objs()[k].pep_idx].toggle(false);
                        }
                        //exercise_obj.show_answers(0);//sena only has 1 lab HRC
                        exercise_obj.disable_clear_button(true);
                        //flag false
                        
                        exercise_obj.feedback_showing_answer(true); //set this flag when they've gotten it wrong twice
                    }
                    else
                    {                        
                        exercise_obj.showing_answer(false);
                    }                    
                }
                else
                {
                    self.attempts(self.attempts()+1);
                    
                    //Check for SPK so it doesn't increase the attempt before the user has finished playing. 
                    if (exercise_obj.type() == "SPK")
                    {
                        if (exercise_obj.started() == true)
                            self.attempts(0); //Reset the counter if SPK hasn't been finished yet
                    }
                }
            }          
        }
        exercise_obj.user_action(0);
        return ret;
    });    
}

//Called when the feedback is true. Goes through the exercise and makes sure everything is disabled.
//@obj = The exercise object
function product_feedback_show_answers(obj)
{
    var flag = false;
    if (typeof viewModel !== 'undefined')
    {
        for(var i = 0; i < viewModel.disabled_lockout_exes().length; ++i)
        {
            if (obj.type() == viewModel.disabled_lockout_exes()[i])
            {
                flag = true;
                break;
            }
        }
    }
    if (!flag){
        //Check to make sure that the viewModel has been created (Initial startup).
        //Also check to make sure that the exercise has been fully completed correctly before disabling everything.
        if (typeof viewModel !== 'undefined' && viewModel.labs()[0].exercises()[viewModel.labs()[0].selected_exercise()].state() == 4)
        {
            //Added in bug_055_answer_lock, lock all the answers if all the questions are correct
            obj.showing_answer(true);
            
            if (obj.type() == "TYP" || obj.type() == "GIW")
            {
                //Initialize the bootstrap popover functionality
                obj.init_popover();
            }
            if (typeof obj.dragdrop !== 'undefined')
            {
               // console.log('lock');
                //Disable all the pep objects on the current exercise
                for(var k = 0, lenT = obj.dragdrop.pep_objs().length; k < lenT; ++k)
                    $.pep.peps[obj.dragdrop.pep_objs()[k].pep_idx].toggle(false);
            }
        }
    }
}

function product_helper_exercise_ttt(obj) //EXS
{
    obj.disable_solution_button(true);
    obj.disable_check_answer(true);
    //holds the current question being answered
    obj.current_question = ko.observable(0);
    //this is the grid, each cell contains the question number and cell cords
    obj.ttt_grid = ko.observableArray();
    obj.got_it_right = ko.observable(false);

    obj.set_up_grid = function()
    {
        //make the grid
        for (var i = 0, len = 3; i < len; ++i)
        {
            obj.ttt_grid.push({"cols": ko.observableArray()});
            for (var l = 0, l_len = 3; l < l_len; ++l)
            {
                if (i == 1 && l == 1)
                    obj.ttt_grid()[i].cols().push({"content" : ko.observable(" "), "type" : ko.observable("text") ,"question": ko.observable(9), "selected" : ko.observable(1), "correct": ko.observable(1),"x_cord": ko.observable(l),"y_cord": ko.observable(i)});
                else
                    obj.ttt_grid()[i].cols().push({"content" : ko.observable(), "type" : ko.observable() ,"question": ko.observable(), "selected" : ko.observable(0), "correct": ko.observable(0),"x_cord": ko.observable(l),"y_cord": ko.observable(i)});
            }
        }
    }
    //part of the randomizer, ensures that each cell is filled with a unique response/distractor
    obj.used_question_responses = ko.observableArray();

    obj.randomize_game = function()
    {
        obj.used_question_responses([]);
        for (var i = 0, len = obj.ttt_grid().length; i < len; ++i)
        {
            for (var l = 0, l_len = obj.ttt_grid()[i].cols().length; l < l_len; ++l)
            {
                if (i != 1 || l != 1)
                {
                    var randint;
                    while(true)
                    {
                        randint = Math.floor(Math.random()*(8));

                        if (obj.used_question_responses().indexOf(randint) == -1)
                        {
                            obj.used_question_responses.push(randint);
                            break;
                        }
                    }
                    if(randint <= obj.questions().length-1)
                    {
                        obj.ttt_grid()[i].cols()[l].question(randint);
                        obj.ttt_grid()[i].cols()[l].content(obj.questions()[randint].responses()[1]._data()[0].content());
                        obj.ttt_grid()[i].cols()[l].type(obj.questions()[randint].responses()[1]._data()[0].type());
                    }  
                    else
                    {
                        for (var w = 0; w < obj._data().length; ++w)
                        {
                            if(obj._data()[w].type() == "options")
                            {
                                obj.ttt_grid()[i].cols()[l].question(randint);
                                obj.ttt_grid()[i].cols()[l].content(obj._data()[w].contents()[randint-(obj.questions().length)].content());
                                obj.ttt_grid()[i].cols()[l].type(obj._data()[w].contents()[randint-(obj.questions().length)].type());
                            }
                        }
                    }
                }
            }
        }
    }
    obj.TTT_restore = function()
    {
        for (var j = 0, len = 3; j < len; ++j)
        {
            for (var k = 0, k_len = 3; k < k_len; ++k)
            {
                if(obj.ttt_grid()[j].cols()[k].correct())
                {
                    var cell = obj.ttt_grid()[j].cols()[k];
                    //check columns
                    for(var i = 0; i < 3; i++)
                    {
                        if(obj.ttt_grid()[i].cols()[cell.x_cord()].correct()==0)
                        {
                            break;
                        }
                        if(i == 2)
                        {
                            obj.complete_exercise(true);
                        }
                    }
                    //check rows
                    for(var i = 0; i < 3; i++)
                    {
                        if(obj.ttt_grid()[cell.y_cord()].cols()[i].correct()==0)
                        {
                            break;
                        }
                        if(i == 2)
                        {
                            obj.complete_exercise(true);
                        }
                    }
                    //check diag
                    for(var i = 0; i < 3; i++)
                    {
                        if(obj.ttt_grid()[i].cols()[i].correct()==0)
                        {
                            break;
                        }
                        if(i == 2)
                        {
                            obj.complete_exercise(true);
                        }
                    }
                    //check anti diag
                    for(var i = 0; i < 3; i++)
                    {
                        if(obj.ttt_grid()[i].cols()[2-i].correct()==0)
                        {
                            break;
                        }
                        if(i == 2)
                        {
                            obj.complete_exercise(true);
                        }
                    }
                }
            }
        }
        if(!obj.got_it_right() && obj.cur_question() == -1)
        {            
            for (var i = 0; i < obj.questions().length; ++i)
            {
                for (var k = 0, k_len = obj.questions()[i].responses().length; k<k_len; ++k)
                {
                    if(!obj.questions()[i].responses()[k].correct())
                    {
                        obj.questions()[i].responses()[k].selected(1);
                    }
                    else
                    {
                        obj.questions()[i].responses()[k].selected(0);
                    }
                }
            }
            product_check_answers(obj);            
        }
        //viewModel.labs()[viewModel.selected_lab()].submit_button();
    }
    obj.check_click_match = function(cell)
    {
        //dont do anything if you click on a consumed cell or answer a consumed question
        if(obj.questions()[obj.current_question()].responses()[0].selected() || obj.questions()[obj.current_question()].responses()[1].selected() || cell.selected())
        {
            return
        }

        //logic for when they answer a question right
        if(cell.question() == obj.current_question())
        {
            cell.selected(1);
            cell.correct(1);
            for (var k = 0, k_len = obj.questions()[obj.current_question()].responses().length; k<k_len; ++k)
            {
                if(obj.questions()[obj.current_question()].responses()[k].correct())
                {
                    obj.questions()[obj.current_question()].responses()[k].selected(1);
                }
                else
                {
                    obj.questions()[obj.current_question()].responses()[k].selected(0);
                }
            }
            //check for win
            //check colums
            for(var i = 0; i < 3; i++)
            {
                if(obj.ttt_grid()[i].cols()[cell.x_cord()].correct()==0)
                {
                    break;
                }
                if(i == 2)
                {
                    obj.complete_exercise();
                }
            }
            //check rows
            for(var i = 0; i < 3; i++)
            {
                if(obj.ttt_grid()[cell.y_cord()].cols()[i].correct()==0)
                {
                    break;
                }
                if(i == 2)
                {
                    obj.complete_exercise();
                }
            }
            //check diag
            for(var i = 0; i < 3; i++)
            {
                if(obj.ttt_grid()[i].cols()[i].correct()==0)
                {
                    break;
                }
                if(i == 2)
                {
                    obj.complete_exercise();
                }
            }
            //check anti diag
            for(var i = 0; i < 3; i++)
            {
                if(obj.ttt_grid()[i].cols()[2-i].correct()==0)
                {
                    break;
                }
                if(i == 2)
                {
                    obj.complete_exercise();
                }
            }
            obj.change_question(1)
        }
        //logic for when answering a wrong question
        else if(cell.question() != obj.current_question())
        {
            cell.selected(1);
            for (var k = 0, k_len = obj.questions()[obj.current_question()].responses().length; k<k_len; ++k)
            {
                if(!obj.questions()[obj.current_question()].responses()[k].correct())
                {
                    obj.questions()[obj.current_question()].responses()[k].selected(1);
                }
                else
                {
                    obj.questions()[obj.current_question()].responses()[k].selected(0);
                }
            }
            obj.change_question(1)
        }
        if(obj.cur_question() == -1)
        {
            viewModel.labs()[viewModel.selected_lab()].submit_button();
        }
    }
    obj.complete_exercise = function(TTT_restoring_progress)
    {
        for (var i = 0; i < obj.questions().length; ++i)
        {
            for (var k = 0, k_len = obj.questions()[i].responses().length; k<k_len; ++k)
            {
                if(obj.questions()[i].responses()[k].correct())
                {
                    obj.questions()[i].responses()[k].selected(1);
                }
                else
                {
                    obj.questions()[i].responses()[k].selected(0);
                }
            }
        }
        obj.got_it_right(true);

        if(typeof TTT_restoring_progress !== 'undefined' && TTT_restoring_progress == true)
        {
            product_check_answers(obj);
        }
        else
        {
            viewModel.labs()[viewModel.selected_lab()].submit_button();
        }
    }

    //change the question they are currently answering
    obj.change_question = function(value)
    {
        if (value == 1)
        {
            if (obj.current_question() == (obj.questions().length-1))
                obj.current_question(0);
            else
                obj.current_question(obj.current_question()+1)
        }
        else
        {
            if (obj.current_question() == 0)
                obj.current_question(obj.questions().length-1);
            else
                obj.current_question(obj.current_question()-1)
        }
        viewModel.labs()[viewModel.selected_lab()].adjust_video_container();
    }

    //resets the game to let them try again
    obj.reset_ttt = function () {
        if(!obj.feedback_showing_answer())
        {
            for (var i = 0; i < obj.ttt_grid().length; ++i)
            {
                for (var l = 0; l <  obj.ttt_grid()[i].cols().length; ++l)
                {
                    if (i == 1 && l == 1)
                        continue;                
                    obj.ttt_grid()[i].cols()[l].selected(0);
                    obj.ttt_grid()[i].cols()[l].correct(0);
                }
            }
            for (var i = 0; i < obj.questions().length; ++i)
            {
                obj.questions()[i].responses()[0].selected(0);
                obj.questions()[i].responses()[1].selected(0);
            }
            obj.randomize_game();
            obj.got_it_right(false);
        }
    }
    
    obj.set_up_grid();        
    obj.randomize_game();

    //edditing functions from here on down
    obj.question_adder_remover = function(value,question_data)
    {
        //we will add a question and remove a distracter
        if (value == 1)
        {
            obj.add_question();
            for (var i = 0; i < obj._data().length; ++i)
            {
                if(obj._data()[i].type() == "options")
                {
                    obj._data()[i].contents.splice(obj._data()[i].contents().length-1,1);
                }
            }
        }
        //remove question, add distract
        if(value == 0)
        {
            obj.remove_question(question_data);
            for (var i = 0; i < obj._data().length; ++i)
            {
                if(obj._data()[i].type() == "options")
                {
                    obj._data()[i].contents.push({"type": ko.observable("text"), "content": ko.observable("")});
                }
            }
        }
    }

    //This function was created to make sure all the objectives are the same across an exercise but this happens in a subscribe now, so it isn't really needed
    obj.change_objectives = function(new_content)
    {
        for (var i = 0; i < obj.questions().length; ++i)
        {
            for (var k = 0, k_len = obj.questions()[i]._data().length; k<k_len; ++k)
            {
                if(obj.questions()[i]._data()[k].type() == "objective")
                {
                    obj.questions()[i]._data()[k].content(new_content)
                }
            }
        }
    }
}

function product_helper_exercise_kar(obj)
{
    for (var i = 0; i < obj.questions().length; ++i)
    {
        for (var k = 0, k_len = obj.questions()[i]._data().length; k<k_len; ++k)
        {
            //Check to make sure contents exists in the data array before trying to loop on it
            if (typeof obj.questions()[i]._data()[k].contents !== 'undefined')
            {
                for (var j = 0, j_len = obj.questions()[i]._data()[k].contents().length; j<j_len; ++j)
                {
                    if(obj.questions()[i]._data()[k].contents()[j].type() == "video" || obj.questions()[i]._data()[k].contents()[j].type() == "rec")
                    {
                        for (var r = 0, r_len = obj.questions()[i].responses().length; r<r_len; ++r)
                        {
                            if(obj.questions()[i].responses()[r].correct())
                            {
                                obj.questions()[i].responses()[r].selected(1);
                            }
                        }
                    }
                }
            }
        }
    }

    obj.complete_question = function(i)
    {
        // //log(i);
        for (var k = 0, k_len = obj.questions()[i].responses().length; k<k_len; ++k)
        {
            if(obj.questions()[i].responses()[k].correct())
            {
                obj.questions()[i].responses()[k].selected(1);
            }
            else
            {
                obj.questions()[i].responses()[k].selected(0);
            }
        }
    }
}

function product_helper_exercise_mch(obj) //EXS
{
    obj.mch_table_aspect = ko.observable();
    obj.used_question_responses = ko.observableArray();
    obj.click = ko.observable(0);
    obj.first_cell = ko.observable();
    obj.mch_grid = ko.observableArray();
    obj.grid_change = ko.observable(0);
    obj.cell_heights = ko.observable(0);
    obj.cell_width = ko.observable(0);
    obj.question_pairs = ko.observable(0);
    obj.mch_attempts = ko.observable(0);

    for (var w = 0, len = obj._data().length; w < len; ++w)
    {
        if(obj._data()[w].type() == "options")
        {
            var calc_height,calc_width;
            for (var g = 0, len = obj._data()[w].contents().length; g < len; ++g)
            {
                if(obj._data()[w].contents()[g].type() == "pairs")
                {
                    obj.question_pairs(obj._data()[w].contents()[g].content());
                }
                if(obj._data()[w].contents()[g].type() == "height")
                {
                    calc_height = obj._data()[w].contents()[g].content();
                }
                if(obj._data()[w].contents()[g].type() == "width")
                {
                    calc_width = obj._data()[w].contents()[g].content();
                }
            }
            obj.mch_table_aspect(calc_height/calc_width);
        }
    }

    obj.resize_cells = function()
    {
        var mch_cell;

        if($('#mch-cell-'+obj.id())[0].offsetParent !== null)
        {
            mch_cell = $('#mch-cell-'+obj.id())[0];
        }

        if (obj.mch_table_aspect() < 1)
        {
            obj.cell_heights((obj.mch_table_aspect()*mch_cell.clientWidth)+15);
        }
        else
        {
            obj.cell_heights((obj.mch_table_aspect()*mch_cell.clientWidth)-20);
        }
    }

    obj.cell_sizing = function(pairs)
    {
        if (obj.mch_table_aspect() < 1)
        {
            if(pairs == 2)
            {
                obj.cell_width(350);
            }
            else if(pairs == 3 || pairs == 6)
            {
                obj.cell_width(300);
            }
            else if(pairs == 8)
            {
                obj.cell_width(200);
            }
            obj.cell_heights((obj.mch_table_aspect()*obj.cell_width())+15);
        }
        else
        {
            if(pairs == 3 || pairs == 2)
            {
                obj.cell_width(200);
            }
            else if(pairs == 6)
            {
                obj.cell_width(150);
            }
            else if(pairs == 8)
            {
                obj.cell_width(100);
            }
            obj.cell_heights((obj.mch_table_aspect()*obj.cell_width())-20);
        }
    }
    

    obj.set_up_grid = function()
    {
        var grid_x,grid_y;

        if(obj.question_pairs() == 2)
        {
            grid_x = 2
            grid_y = 2
            obj.cell_sizing(obj.question_pairs())

        }
        else if(obj.question_pairs() == 3)
        {
            if (obj.mch_table_aspect() < 1)
            {
                grid_x = 2
                grid_y = 3
            }
            else
            {
                grid_x = 3
                grid_y = 2
            }
            
            obj.cell_sizing(obj.question_pairs())
        }
        else if(obj.question_pairs() == 6)
        {
            grid_x = 4
            grid_y = 3
            obj.cell_sizing(obj.question_pairs())
        }
        else if(obj.question_pairs() == 8)
        {
            grid_x = 4
            grid_y = 4
            obj.cell_sizing(obj.question_pairs())
        }

        for (var i = 0, len = grid_y; i < len; ++i)
        {
            obj.mch_grid.push({"cols": ko.observableArray()});
            for (var l = 0, l_len = grid_x; l < l_len; ++l)
            {
                obj.mch_grid()[i].cols().push({"content" : ko.observable(), "type" : ko.observable() ,"question": ko.observable(), "response": ko.observable(), "selected" : ko.observable(0), "correct": ko.observable(0)});
            }
        }
    }   

    obj.randomize_game = function()
    {
        obj.used_question_responses([]);
        for (var i = 0, len = obj.mch_grid().length; i < len; ++i)
        {
            for (var l = 0, l_len = obj.mch_grid()[i].cols().length; l < l_len; ++l)
            {
                var quest_num,resp_num;
                while(true)
                {
                    var randint = Math.floor(Math.random()*(obj.question_pairs()*2));

                    if (obj.used_question_responses().indexOf(randint/2) == -1)
                    {
                        obj.used_question_responses.push(randint/2);
                        quest_num = Math.floor(randint/2);
                        resp_num = randint%2;
                        break;
                    }
                }
                obj.mch_grid()[i].cols()[l].question(quest_num);
                obj.mch_grid()[i].cols()[l].response(resp_num);
                obj.mch_grid()[i].cols()[l].content(obj.questions()[quest_num].responses()[resp_num]._data()[0].content());
                obj.mch_grid()[i].cols()[l].type(obj.questions()[quest_num].responses()[resp_num]._data()[0].type());
            }
        }
    }

    //on click this function will check if it was the first click or second, 
    //then it will show that cell and check if you got a question right
    obj.check_click_match = function(cell)
    {
        if(cell.correct() == 1 || (cell.selected() && obj.click() == 1))
        {
            return;
        }

        if (obj.click() == 0 )
        {
            for (var i = 0, len = obj.mch_grid().length; i < len; ++i)
            {
                for (var l = 0, l_len = obj.mch_grid()[i].cols().length; l < l_len; ++l)
                {
                    if(obj.mch_grid()[i].cols()[l].correct() == 0)
                    {
                        obj.mch_grid()[i].cols()[l].selected(0);
                    }
                }
            }
            obj.first_cell(cell);
        }

        cell.selected(1);

        if (obj.click() == 1)
        {
            //if they got a much show it and mark it
            if(obj.first_cell().question() == cell.question())
            {
                obj.first_cell().correct(1);
                cell.correct(1);
                obj.questions()[cell.question()].responses()[1].selected(1);
            }

            //check to see if they won
            var breaker = 0;
            for (var i = 0, len = obj.mch_grid().length; i < len; ++i)
            {
                for (var l = 0, l_len = obj.mch_grid()[i].cols().length; l < l_len; ++l)
                {
                    if(obj.mch_grid()[i].cols()[l].correct() == 0)
                    {
                        breaker = 1;
                        break;
                    }
                }
                if(breaker == 1)
                {
                    break;
                }
            }
            if (breaker == 0)
            {
                viewModel.labs()[viewModel.selected_lab()].submit_button();
            }
        }


        if (obj.click() == 0)
            obj.click(1) 
        else
            obj.click(0)
    }

    //adds or removes questions depending on the amount of pairs selected
    obj.change_questions = function(amount)
    {
        if (amount == obj.questions().length)
        {
            return;
        }
        else if (amount > obj.questions().length)
        {
            while (amount > obj.questions().length)
                obj.add_question();
            obj.grid_change(1);
        }
        else if(amount < obj.questions().length)
        {
            while (amount < obj.questions().length)
                obj.remove_question(obj.questions()[obj.questions().length-1]);
            obj.grid_change(1);
        }
    }

    obj.reset_mch = function()
    {
        if(obj.mch_attempts() <1)
        {
            obj.mch_attempts(1);
            for (var i = 0; i < obj.mch_grid().length; ++i)
            {
                for (var l = 0; l <  obj.mch_grid()[i].cols().length; ++l)
                {
                    obj.mch_grid()[i].cols()[l].selected(0);
                    obj.mch_grid()[i].cols()[l].correct(0);
                }
            }
            for (var i = 0; i < obj.questions().length; ++i)
            {
                obj.questions()[i].responses()[0].selected(0);
                obj.questions()[i].responses()[1].selected(0);
            }
            obj.randomize_game();
        }
    }

    obj.set_up_grid();
    obj.randomize_game();
}

function product_helper_exercise_gwr(obj) //EXS
{
    obj.disable_solution_button(1);
    obj.disable_clear_button(1);
    obj.finished_writing_planner = ko.observable(0);

    obj.enable_writing_button = ko.computed( function(){
        for (var i = 1; i < obj.questions().length; ++i)
        {
            //Only check the response content if the question in not for recording
            if (product_helper_check_rec_question(obj.questions()[i]._data()) == false)
            {
                if(obj.questions()[i].responses()[1]._data()[0].content() == "" || obj.questions()[i].responses()[1]._data()[0].content() == " ")
                    return 0;
            }
            //Check to see if the current question is for recording
            if (product_helper_check_rec_question(obj.questions()[i]._data()))
            {
                //If the user has not used the recording, then don't enable the button
                if (obj.questions()[i].selected_response() == -1)
                    return 0;
            }
        }
        return 1;
    });

    obj.final_writing_string_maker = function()
    {
        //Change the UI
        obj.set_up_final_writing();
    }

    obj.set_up_progress = function()
    {
        obj.finished_writing_planner(1);
    }

    obj.set_up_final_writing = function()
    {
        obj.finished_writing_planner(1);
        
        //Clear the string before using it
        obj.questions()[0].responses()[1]._data()[0].content("");
        
        //Build the final string
        for (var i = 1; i < obj.questions().length; ++i)
            obj.questions()[0].responses()[1]._data()[0].content(obj.questions()[0].responses()[1]._data()[0].content()+ obj.questions()[i].responses()[1]._data()[0].content() + '\n\n');
        
        //Go through all the questions and set the correct response. Makes sure that the exercise is always set to correct.
        for (var i = 0; i < obj.questions().length; ++i)
        {     
            for (var k = 0, k_len = obj.questions()[i].responses().length; k<k_len; ++k)
            {
                if(obj.questions()[i].responses()[k].correct())
                    obj.questions()[i].responses()[k].selected(1);
            }
        }
        //Check answer on the exercise, setting the exercise to complete
        product_check_answers(obj);
    }
}

function product_helper_exercise_ata(obj) //EXS
{
    obj.disable_solution_button(true);
    obj.disable_clear_button(true);

    for (var i = 0; i < obj.questions().length; ++i)
    {     
        for (var k = 0, k_len = obj.questions()[i].responses().length; k<k_len; ++k)
        {
            if(obj.questions()[i].responses()[k].correct() && obj.questions()[i].responses()[k].selected())
            {
                obj.questions()[i].para_selector = ko.observable(1); 
            }
            else
            {
                obj.questions()[i].para_selector = ko.observable(0);
            }
        }   
    }

    obj.change_anotation = function(quest)
    {
        if (obj.questions()[quest].para_selector() == 0)
            obj.questions()[quest].para_selector(1);
        else
            obj.questions()[quest].para_selector(0);

        for (var k = 0, k_len = obj.questions()[quest].responses().length; k<k_len; ++k)
        {
            if(obj.questions()[quest].responses()[k].correct())
            {
                obj.questions()[quest].responses()[k].selected(1);
            }
        }
        var counter = 0;

        for (var i = 0; i < obj.questions().length; ++i)
        {     
            for (var k = 0, k_len = obj.questions()[i].responses().length; k<k_len; ++k)
            {
                if(obj.questions()[i].responses()[k].correct() && obj.questions()[i].responses()[k].selected())
                {
                    counter++;
                    if (counter == obj.questions().length)
                    {
                        product_check_answers(obj);
                    }
                }
            }
        }
    }
}

function product_helper_exercise_wds(obj) //EXS
{
    //colors for disinguishing questions
    obj.colors = ["#F03C62","#147AFF","#63C709","#A832FA","#FA9121","#FEA8CF",];
    obj.board_colors = ["#CC002B","#0A4DA6","#50A107","#7900CC","#DA751D","#FE7EB7",];
    //a function that will return which colour to use
    obj.color_number = function(number)
    {
        // //log(number);
        while (number > 5){
            number = number - 6;
        }
        // //log(number);
        return number;
    }

    //this array keeps trak of what questions have been answered and in what order
    obj.answerd_questions = ko.observableArray();

    obj.cell_state_check = function(questions,cell)
    {
        var ret = 0;
        for (var i = 0, len = questions.length; i < len; ++i)
        {
            for (var w = 0, w_len = obj.questions().length; w < w_len; ++w)
            {
                if (obj.questions()[w].id() == questions[i].id())
                {
                    if (obj.questions()[w].state() >= 1)
                    {
                        ret = 1;
                    }
                }
            }
        }
        return ret;
    }

    //this function overlaps cells that have two or more questions on it with the most recently answerd question
    obj.questiond_id_finder = function(question)
    {
        // //log(question);
        var ret = null;
        var cell_question_ids = [];
        for (var l = 0, l_len = question.length; l < l_len; ++l)
        {
            //determines which questions are contained in a cell
            cell_question_ids.push(question[l].id());
        }
        for (var l = 0, l_len = question.length; l < l_len; ++l)
        {
            if(question[l].state() >= 1)
            {
                ret = question[l].id();

                //this if statment adds questions to the question tracking array
                if(obj.answerd_questions().indexOf(question[l].id())<0)
                {
                    obj.answerd_questions.push(question[l].id());
                }
                //this cluster of ifs and fors is what allows the grid to apply the colour of the most recently answerd question to a cell
                if (question.length>1 && cell_question_ids.indexOf(question[l].id())>-1)
                {
                    for (var k = 1, k_len = obj.answerd_questions().length+1; k < k_len; ++k)
                    {
                        //find the most recent answerd question for a cell
                        if (cell_question_ids.indexOf(obj.answerd_questions()[obj.answerd_questions().length-k])>-1)
                        {
                            ret = obj.answerd_questions()[obj.answerd_questions().length-k];
                            break;
                        }
                    }   
                }
            }
            if(obj.showing_answer()){
                ret = question[l].id();
            }
        }
        cell_question_ids = [];
        return ret;
    }
    //Character array used to generate the word search grid
    var alphaArray = "abcdefghijklmnopqrstuvwxyz".split("");
    //The grid containing all the information needed for the word search
    obj.wds_grid = ko.observableArray();
    //Flag used to alert the user editing that they need to save to see the grid changes
    obj.grid_changed = ko.observable(false);
    
    //Creates and generates a new word search grid.
    //Will generate a new grid with all new values on first run and if being called another
    //time it will just generate only the values needed. It gets called again in the editing tool.
    obj.create_wds_grid = function()
    {
        for (var i = 0, len = obj._data().length; i < len; ++i)
        {
            //Get all the options that define the grid
            if (obj._data()[i].type() == "options")
            {
                for (var l = 0, l_len = obj._data()[i].contents().length; l < l_len; ++l)
                {
                    //Get the grid sizing
                    if (obj._data()[i].contents()[l].type() == "grid_x")
                        obj.grid_x = ko.observable(obj._data()[i].contents()[l].content());
                    if (obj._data()[i].contents()[l].type() == "grid_y")
                        obj.grid_y = ko.observable(obj._data()[i].contents()[l].content());
                }
            }
        }

        //Create an empty grid if it's the first time creating it.
        //Used so when the user is using the editing tool it doesn't create an empty grid every time.
        if (obj.wds_grid().length == 0)
        {
            for (var i = 0, len = obj.grid_y(); i < len; ++i)
            {
                obj.wds_grid.push({"cols": ko.observableArray()});
                for (var l = 0, l_len = obj.grid_x(); l < l_len; ++l)
                    obj.wds_grid()[i].cols().push({"letter": ko.observable(alphaArray[Math.floor(Math.random()*alphaArray.length)].toUpperCase()), "question": ko.observableArray(), "selected" : ko.observable(false), "correct": ko.observable(false)});
            }
        }
        else //The grid is being re-created through the editing tool. So it doesn't need all new values.
        {
            for (var i = 0, len = obj.wds_grid().length; i < len; ++i)
            {
                for (var l = 0, l_len = obj.wds_grid()[i].cols().length; l < l_len; ++l)
                {
                    //Reset all the questions and letter incase anything moved
                    obj.wds_grid()[i].cols()[l].question.removeAll();
                    obj.wds_grid()[i].cols()[l].letter(alphaArray[Math.floor(Math.random()*alphaArray.length)].toUpperCase());
                }
            }
        }

        //Find the responses and check where the words need to be
        for (var i = 0, i_len = obj.questions().length; i < i_len; ++i)
        {
            for (var l = 1, t_len = obj.questions()[i].responses().length; l < t_len; ++l)
            {
                if ( get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") != -1)
                {
                    //Get all the current response information needed to put the word on the grid
                    var word = get_response_data(obj.questions()[i].responses()[l]._data(), "text").toUpperCase();
                    var dir = get_response_data(obj.questions()[i].responses()[l]._data(), "direction");
                    var reverse = get_response_data(obj.questions()[i].responses()[l]._data(), "reverse");
                    
                    //Loop through each character in the word
                    for (var k = 0, l_len = word.length; k < l_len; ++k)
                    {
                        //The word is being displayed vertically
                        if (dir == 0)
                        {
                            //Error check to make sure the index is not out of bounds. Will go out of bounds in the editing tool if the word extends past the grid bounds
                            if (get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") + k < obj.wds_grid().length)
                            {
                                //Put the question in grid cell so we know what question the cell is on
                                obj.wds_grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") + k].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].question.push(obj.questions()[i]);
                                if (get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") + (reverse ? word.length - k : k) < obj.wds_grid().length)
                                {
                                    //Set the letter to the current word character
                                    obj.wds_grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") + (reverse ? word.length - k - 1: k)].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].letter(word[k]);
                                    //Make sure the last letter gets placed. (Was a problem with the letter not showing the in the last row)
                                    if (get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") + (word.length - k) >= obj.wds_grid().length - 1)
                                    {
                                        if (typeof word[k - 1] !== "undefined")
                                            obj.wds_grid()[obj.wds_grid().length - 1].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].letter(word[k - 1]);    
                                    }
                                }
                            }
                        }
                        else //The word is being displayed horizontally
                        {
                            //Error check to make sure the index is not out of bounds. Will go out of bounds in the editing tool if the word extends past the grid bounds
                            if (get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")+k < obj.wds_grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols().length)
                            {
                                obj.wds_grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")+k].question.push(obj.questions()[i]);
                                
                                if(get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")+(reverse ? (word.length - k - 1) : k) < obj.wds_grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols().length)
                                    obj.wds_grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")+(reverse ? (word.length - k - 1) : k)].letter(word[k]);
                            }
                        }
                    }
                }
            }
        } 
    } //End of create_wds_grid
    
    //Holds the values of the cell that's been clicked on to compare to the next click
    obj.clicked_cell = ko.observable({"x":-1, "y": -1});
    
    //Clears all the mouse bindings.
    obj.clear_cell_bindings = function()
    {
        var table = $("#wds-table-"+obj.id()+" tbody");
        for (var i = 0; i < table[0].children.length; ++i)
        {
            for (var w = 0; w < table[0].children[i].children.length; ++w)
            {
                $(table[0].children[i].children[w]).unbind("mouseover");
                obj.wds_grid()[i].cols()[w].selected(false);
            }
        }
    }
    
    //Clears the mouse hover on either the rows or columns.
    //0 = rows
    //1 = columns
    obj.clear_selected = function(dir)
    {
        if (dir == 0)
        {
            for (var k = 0; k < obj.wds_grid()[obj.clicked_cell().y].cols().length; ++k)
                obj.wds_grid()[obj.clicked_cell().y].cols()[k].selected(false);
        }
        else
        {
            for (var k = 0; k < obj.wds_grid().length; ++k)
                obj.wds_grid()[k].cols()[obj.clicked_cell().x].selected(false);
        }
    }
    
    //Checks to see where the user has clicked on.
    //Will check to see if a correct word has been entirely selected.
    obj.click_cell = function(x,y)
    {
        if (obj.showing_answer()){return;}
        var found = true;
        var counter = 0;
        var table = $("#wds-table-"+obj.id()+" tbody");
        
        //Check for first click, set the first positions. Added because if the starting position was 0,00
        //it would select a word if it was placed at 0,0.
        // -- bug_006_WDS_vertical_words
        if (obj.clicked_cell().x == -1)
        {
            //Set the values to the clicked cell
            obj.clicked_cell().y = y;
            obj.clicked_cell().x = x;
        }
        
        //Function that binds the mouesover event to the proper cells according to a mouse click.
        //Binds the event to the proper row and column making sure that only those cells will get 
        //the selected class applied to it on mouse over.
        function bind_cells()
        {
            //Loop through each row on the table
            for (var i = 0; i < table[0].children.length; ++i)
            {
                //Loop through each column on the row
                for (var w = 0; w < table[0].children[i].children.length; ++w)
                {
                    //Set a mouse over binding on each <td> on the current row
                    $(table[0].children[y].children[w]).bind("mouseover", function(e)
                    {
                        obj.clear_selected(1);
                        //Mouse moving right of the selected cell
                        for (var q = obj.clicked_cell().x; q < obj.grid_x(); ++q)
                        {
                            if (q <= $(this).index())
                                obj.wds_grid()[obj.clicked_cell().y].cols()[q].selected(true);
                            else
                                obj.wds_grid()[obj.clicked_cell().y].cols()[q].selected(false);
                        }
                        //Mouse moving left of the selected cell
                        for (var q = 0; q <= obj.clicked_cell().x; ++q)
                        {
                            if (q >= $(this).index())
                                obj.wds_grid()[obj.clicked_cell().y].cols()[q].selected(true);
                            else
                                obj.wds_grid()[obj.clicked_cell().y].cols()[q].selected(false);
                        }
                        //Make sure the initial cell doesn't lose it's selected class
                        obj.wds_grid()[obj.clicked_cell().y].cols()[obj.clicked_cell().x].selected(true);
                    });
                    //Set a mouse over binding on each <td> on the current column
                    $(table[0].children[i].children[x]).bind("mouseover", function(e)
                    {
                        obj.clear_selected(0);
                        //Mouse moving down from the selected cell
                        for (var q = obj.clicked_cell().y ; q < obj.grid_y(); ++q)
                        {
                            if (q <= $(this).parent().index())
                                obj.wds_grid()[q].cols()[obj.clicked_cell().x].selected(true);
                            else
                                obj.wds_grid()[q].cols()[obj.clicked_cell().x].selected(false);
                        }
                        //Mouse moving up from the selected cell
                        for (var q = 0; q <= obj.clicked_cell().y; ++q)
                        {
                            if (q >= $(this).parent().index())
                                obj.wds_grid()[q].cols()[obj.clicked_cell().x].selected(true);
                            else
                                obj.wds_grid()[q].cols()[obj.clicked_cell().x].selected(false);
                        }
                        //Make sure the initial cell doesn't lose it's selected class
                        obj.wds_grid()[obj.clicked_cell().y].cols()[obj.clicked_cell().x].selected(true);
                    });
                }
            }
        }
        
        //A new click
        if (obj.clicked_cell().x != x && obj.clicked_cell().y != y)
        {
            //Clear all previous bindings
            obj.clear_cell_bindings();
            //Un-select the last cell that was clicked on
            obj.wds_grid()[ obj.clicked_cell().y].cols()[ obj.clicked_cell().x].selected(false);
            //Select the current cell that was clicked on
            obj.wds_grid()[y].cols()[x].selected(true);
            obj.clicked_cell().x = x;
            obj.clicked_cell().y = y;
            
            bind_cells();
        }
        else
        {
            bind_cells();
            //Horizontal line check
            if(obj.clicked_cell().y == y)
            {
                //Check the direction the user clicked in
                if (x > obj.clicked_cell().x)
                {
                    for(var i = obj.clicked_cell().x; i <= x; ++i)
                    {
                        obj.wds_grid()[y].cols()[i].selected(true);
                        counter +=1;
                    }
                }
                else
                {
                    for(var i = x; i <= obj.clicked_cell().x; ++i)
                    {
                        obj.wds_grid()[y].cols()[i].selected(true);
                        counter +=1;
                    }
                }
            }
            //Vertical line check
            else if(obj.clicked_cell().x == x)
            {
                if (y > obj.clicked_cell().y)
                {
                    //Check the direction the user clicked in
                    for(var i = obj.clicked_cell().y; i <= y; ++i)
                    {
                        obj.wds_grid()[i].cols()[x].selected(true);
                        counter += 1;
                    }
                }
                else
                {
                    //Check the direction the user clicked in
                    for(var i = y; i <= obj.clicked_cell().y; ++i)
                    {
                        obj.wds_grid()[i].cols()[x].selected(true);
                        counter += 1;
                    }
                }
            }
            
            for (var i = 0; i < obj.questions().length; ++i)
            {
                for (var l = 1; l < obj.questions()[i].responses().length; ++l)
                {
                    found = true;
                    
                    var word = get_response_data(obj.questions()[i].responses()[l]._data(), "text");
                    var dir = get_response_data(obj.questions()[i].responses()[l]._data(), "direction");

                    for (var k = 0, l_len = word.length; k < l_len; ++k)
                    {
                        //0 = vertical, 1 = horizontal
                        if (dir == 0)
                        {
                            if (!obj.wds_grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") + k].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].selected())
                                found = false;
                        }
                        else
                        {
                            if (!obj.wds_grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x") + k].selected())
                                found = false;
                        }
                    }
                    
                    if (found && counter == word.length)
                    {
                        for (var k = 0, l_len = word.length; k < l_len; ++k)
                        {
                            //0 = vertical, 1 = horizontal
                            if (dir == 0)
                                obj.wds_grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") + k].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].correct(true);
                            else
                                obj.wds_grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")+k].correct(true);
                                
                        }
                        obj.questions()[i].select_response(ko.observable(1));
                        obj.clear_cell_bindings();
                    }
                }
            }

            for (var q = 0, len = obj.wds_grid().length; q < len; ++q)
            {
                for (var w = 0, l_len = obj.wds_grid()[q].cols().length; w < l_len; ++w)
                    obj.wds_grid()[q].cols()[w].selected(false);
            }
            obj.wds_grid()[y].cols()[x].selected(true);
            obj.clicked_cell().x = x;
            obj.clicked_cell().y = y; 
        }
    }
    
    obj.set_word_position = function(_data, attrib_name, new_value, x_val) //EXS
    {
        var word;
        var error = false;
        var dir;
        
        for (var q = 0, q_len = _data.length; q < q_len; ++q)
        {   
            //Get the word, so we know the length
            if (_data[q].type() == "text")
                word = _data[q].content();
            //Get the direction the word is placed in
            if (_data[q].type() == "direction")
                dir = _data[q].content();
        }

        if (attrib_name == "position_y")
        {
            //Check the direction of the word and then check to make sure it isn't going out of bounds
            if (dir == 0)
            {
                if (new_value + word.length > obj.wds_grid().length)
                    error = true;
            }
            else
            {
                if (x_val + word.length > obj.wds_grid()[0].cols().length)
                    error = true;
            }
        }
        
        //If the word is not out of bounds, then set the new location
        if (error == false)
        {
            for (var q = 0, q_len = _data.length; q < q_len; ++q)
            {
                if (_data[q].type() == attrib_name)
                    _data[q].content(new_value);
                if (_data[q].type() == "position_x")
                    _data[q].content(x_val);
            }
            //Recreate the grid with the new positions
            obj.create_wds_grid();
        }
    };
    
    obj.create_wds_grid();
}

function product_helper_exercise_wsb(obj)
{
    obj.set_up_game = function()
    {
        for (var quest = 0, q_len = obj.questions().length; quest < q_len; ++quest)
        {
            var response_string = "";
            var is_a_sentance = 0;
            obj.questions()[quest].is_a_sentance = ko.observable(false);
            //check to see if any of the resopnses have a length greater than 1
            //this means that the response is a word and therefor the question is a sentance
            for (var k = 1, k_len = obj.questions()[quest].responses().length; k<k_len; ++k)
            {
                if (obj.questions()[quest].responses()[k]._data()[0].content().length > 1)
                {
                    is_a_sentance = 1;
                    obj.questions()[quest].is_a_sentance(true);
                }
            }

            //build a string from the responses that will be seen in the editer
            if (is_a_sentance)
            {
                for (var k = 1, k_len = obj.questions()[quest].responses().length; k<k_len; ++k)
                {
                    response_string += obj.questions()[quest].responses()[k]._data()[0].content();
                    response_string += ' ';
                }
            }
            else if (!is_a_sentance)
            {
                for (var k = 1, k_len = obj.questions()[quest].responses().length; k<k_len; ++k)
                {
                    response_string += obj.questions()[quest].responses()[k]._data()[0].content();
                }
            }
            obj.questions()[quest].responses()[0]._data()[0].content(response_string.replace(/^\s+|\s+$/gm,'')); //word
        }
    }
            
    obj.reset_response_wsb = function(quest)
    {
        var ans, is_a_sentance;
        var flag = 0;

        //is there a space in the response txt box?
        //if yes then that means its a sentance, therefor we will flag it and make an array out of the whole words splitting on spaces
        if (obj.questions()[quest].responses()[0]._data()[0].content().indexOf(" ") > -1) //word
        {
            is_a_sentance = 1;
            ans = obj.questions()[quest].responses()[0]._data()[0].content().split(" "); //word
        }
        //if no then that means its a word, therefor we will not flag it and make an array out of the word splitting the letters
        else
        {
            is_a_sentance = 0;
            ans = obj.questions()[quest].responses()[0]._data()[0].content().split(""); //word
        }

        //now, we need to clear all the responses out of the question and add the new letters/words as the new responses
        obj.questions()[quest].responses().splice(1,obj.questions()[quest].responses().length);
        
        var response_obj;
        
        //now add all the words/letters to the response array
        for (var k = 0, k_len = ans.length; k < k_len; ++k)
        {
            //if for some reson the CE left a space after a word it wont be added to the responses
            if (ans[k] == "")
                continue;
            //Reset the response_obj to the previous response object
            response_obj = JSON.parse(ko.mapping.toJSON(obj.questions()[quest].responses()[obj.questions()[quest].responses().length-1]));
            
            //Add the word/letter
            response_obj.selected = 0;
            response_obj.id = k+1;
            response_obj.correct = 1;
            response_obj._data = [{
                    "type": "text",
                    "content" : ans[k]
            }];
            
            //Push the new response to the response array.
            obj.questions()[quest].responses.push(new response_model(response_obj));
        }
    }

    obj.clear_WSB_question = function(quest)
    {
        for (var i = 0; i< obj.dragdrop.pep_objs().length; ++i)
        {
            if(obj.dragdrop.pep_objs()[i].drop_region().hasClass("WSB-droper_"+quest))
            {
                var tmp_item = $.pep.peps[obj.dragdrop.pep_objs()[i].pep_idx].$el.detach();
                ////log(tmp_item);

                obj.dragdrop.pep_objs()[i].dropped(false);
                obj.dragdrop.pep_objs()[i].pep().removeClass('dropped');

                obj.dragdrop.pep_objs()[i].drop_region(obj.dragdrop.pep_objs()[i].previous_drop_region());
                ////log($(obj.dragdrop.pep_objs()[i].previous_drop_region()));
                $(obj.dragdrop.pep_objs()[i].previous_drop_region()).append(tmp_item);
                obj.dragdrop.adjust_drag_item_positions();
            }
        }
        obj.questions()[quest].select_response(ko.observable(-1));
    }
    obj.set_up_game();
}

function product_helper_exercise_hng(obj)
{
    var alphaArray = "abcdefghijklmnopqrstuvwxyz";

    obj.set_up_game = function()
    {
        for (var i = 0, q_len = obj.questions().length; i < q_len; ++i)
        {
            obj.questions()[i].error_images = ko.observableArray()
            for (var r = 0, r_len = obj.questions()[i].responses().length; r < r_len; ++r)
            {
                if(obj.questions()[i].responses()[r].correct())
                {
                    for (var d = 0, d_len = obj.questions()[i].responses()[r]._data().length; d < d_len; ++d)
                    {
                        if(obj.questions()[i].responses()[r]._data()[d].type() == "text")
                        {
                            obj.questions()[i].word = ko.observable(obj.questions()[i].responses()[r]._data()[d].content().toLowerCase());
                            obj.questions()[i].word_to_guess = ko.observable(obj.questions()[i].responses()[r]._data()[d].content().toLowerCase());
                        }
                        else if(obj.questions()[i].responses()[r]._data()[d].type() == "hng_default_settings")
                        {
                            obj.questions()[i].hng_default_settings = ko.observable(obj.questions()[i].responses()[r]._data()[d].content());
                        }
                        else if(obj.questions()[i].responses()[r]._data()[d].type() == "max_hints")
                        {
                            obj.questions()[i].hintcounter = ko.observable(obj.questions()[i].responses()[r]._data()[d].content());
                        }
                        else if(obj.questions()[i].responses()[r]._data()[d].type() == "max_mistakes")
                        {
                            obj.questions()[i].max_mistakes = ko.observable(obj.questions()[i].responses()[r]._data()[d].content());
                        }
                        else if(obj.questions()[i].responses()[r]._data()[d].type() == "error_array")
                        {
                            obj.questions()[i].error_images(obj.questions()[i].responses()[r]._data()[d].content());
                        }
                    }
                }
            }
            obj.questions()[i].letter_array = ko.observableArray();
            
            // sets the hint counter to hint amount entered, defaulted to 3
            obj.questions()[i].incorrect_count = ko.observable(0);
            
            for (var k = 0; k < alphaArray.length; k++)
            {
                obj.questions()[i].letter_array.push({"letter": ko.observable(alphaArray[k]), "selected": ko.observable(0), "right": ko.observable(obj.is_the_letter_there(alphaArray[k],i,obj.questions()[i].word_to_guess()))});
            }
            obj.build_word(i,obj.questions()[i].word_to_guess(),false);
        }
    }

    obj.is_the_letter_there = function(let,quest,realWord) 
    //checks if a letter from the letter_array is in the word that is being guessed, returns 1 for true.
    //this also counts how many correct letters are in the word
    {  
        if(realWord.indexOf(let) != -1)
        {
            return 1;
        } else
        {
            return 0;
        }
    }

    obj.build_word = function(quest,word_to_guess,rebuild)
    //builds the word to show on screen
    {
        word_to_guess = word_to_guess.toLowerCase();
        if (rebuild)
        {
            obj.questions()[quest].word_to_guess(word_to_guess.toLowerCase());
            for (var k = 0; k < alphaArray.length; k++)
            {
                obj.questions()[quest].letter_array()[k].selected(0);
                obj.questions()[quest].letter_array()[k].right(obj.is_the_letter_there(alphaArray[k],quest,word_to_guess))             
            }
        }
        var guessed_word = ""

        for (var k = 0, word_len = word_to_guess.length; k< word_len; k++)
        {
            if (word_to_guess.charAt(k) == " ")
            {
                guessed_word += "&nbsp&nbsp&nbsp";
                continue;
            }
            for (var w = 0, w_len =obj.questions()[quest].letter_array().length; w < w_len; w++)
            {
                // selected and right
                if (obj.questions()[quest].letter_array()[w].letter() == word_to_guess.charAt(k) && obj.questions()[quest].letter_array()[w].selected() == 1 && obj.questions()[quest].letter_array()[w].right() ==1)
                {
                    guessed_word += word_to_guess.charAt(k);
                }
                
                // not selected and right
                else if (obj.questions()[quest].letter_array()[w].letter() == word_to_guess.charAt(k) && obj.questions()[quest].letter_array()[w].selected() == 0 && obj.questions()[quest].letter_array()[w].right() ==1)
                {
                    guessed_word += " _"
                }
            }
        }
        obj.questions()[quest].word(guessed_word);
    }


    //@let: letter index
    //@quest: question id (always 0)
    //@is_progress_restore: true if called from progress restore, else false
    obj.guessing_letter = function(let,quest, is_progress_restore)
    {
        if (obj.questions()[quest].state() != 2 && obj.questions()[quest].state() != 4 && obj.questions()[quest].word() != obj.questions()[quest].word_to_guess())
        {
            obj.questions()[quest].letter_array()[let].selected(1); 

            if (obj.questions()[quest].letter_array()[let].right() == 1) // clicked letter is part of actual word
            {
                obj.build_word(quest,obj.questions()[quest].word_to_guess(),false); // updates the displayed letters

                if (obj.questions()[quest].word().replace(/&nbsp+/g, '') == obj.questions()[quest].word_to_guess().toLowerCase().replace(/\s+/g, '')) // checks if the word is done
                {
                    for (var r = 0, r_len = obj.questions()[quest].responses().length; r < r_len; ++r)
                    {
                        if(obj.questions()[quest].responses()[r].correct())
                        {
                            obj.questions()[quest].responses()[r].selected(1); // marks the question correct
                        }
                        else
                        {
                            obj.questions()[quest].responses()[r].selected(0);
                        }
                    }
                    product_check_answers(obj);
                    
                    if (!is_progress_restore)
                        $('#feedback-modal').modal('show');
                }
            }
            else
            {
                obj.questions()[quest].incorrect_count(obj.questions()[quest].incorrect_count()+1);

                if (obj.questions()[quest].incorrect_count() >= obj.questions()[quest].max_mistakes())
                {
                    for (var r = 0, r_len = obj.questions()[quest].responses().length; r < r_len; ++r)
                    {
                        if(obj.questions()[quest].responses()[r].correct()) // marks the question incorrect
                        {
                            obj.questions()[quest].responses()[r].selected(0); 
                        }
                        else
                        {
                            obj.questions()[quest].responses()[r].selected(1);
                        }
                    }
                    product_check_answers(obj);
                    
                    if (!is_progress_restore)
                        $('#feedback-modal').modal('show');
                }
            }
            
        }
    }

    obj.hintname = function(quest)
    {
        return "hints: " + obj.questions()[quest].hintcounter();
    }

    obj.hint = function(quest)
    {   
    if (obj.questions()[quest].word().replace(/&nbsp+/g, '') != obj.questions()[quest].word_to_guess().toLowerCase().replace(/\s+/g, ''))
        {
            obj.questions()[quest].hintcounter(obj.questions()[quest].hintcounter()-1);
            var flag = 0;

            while(true)
            {
                var realWord = obj.questions()[quest].word_to_guess().toLowerCase();
                var randint = Math.floor(Math.random()*(realWord.length));
                var wordchar = realWord.charAt(randint);

                for(var i = 0, i_len = obj.questions()[quest].letter_array().length; i< i_len; i++)
                {

                    if (wordchar == obj.questions()[quest].letter_array()[i].letter())
                    {
                        if (obj.questions()[quest].letter_array()[i].selected()==1)
                        {
                            break;
                        }
                        else
                        {
                            obj.guessing_letter(i,quest, false);
                            flag = 1;
                        }
                    }
                }
                if (flag ==1)
                {
                    break
                }
            }
        }
    }    
    obj.set_up_game();
}

function get_response_data(_data, attrib_name) //EXS
{
    for (var q = 0, q_len = _data.length; q < q_len; ++q)
    {
        if (_data[q].type() == attrib_name)
            return _data[q].content();
    }
    
    return "";
}

function set_word_position(_data, attrib_name, new_value) //EXS
{
    for (var q = 0, q_len = _data.length; q < q_len; ++q)
    {
        if (_data[q].type() == attrib_name)
            _data[q].content(new_value);
    }
}

function product_helper_exercise_cwd(obj) //EXS
{
    //Flag for when to show the input box
    obj.word_attempt = ko.observable(false);
    obj.grid_changed = ko.observable(false);
    
    obj.grid = ko.observableArray();
    obj.crossword_grid_x = ko.observable(0);
    obj.crossword_grid_y = ko.observable(0);
    
    obj.edit_cwd_grid = ko.observable(false);

    for(var i=0; i<obj.questions().length; ++i){
        obj.questions()[i].cwd_entered_response = ko.observable(""); //observable to store the current entered response
    }
    
    obj.create_cwd_grid = function()
    {
        for (var i = 0, len = obj._data().length; i < len; ++i)
        {
            //Find the size of the grid
            if (obj._data()[i].type() == "options")
            {
                for (var l = 0, t_len = obj._data()[i].contents().length; l < t_len; ++l)
                {
                    if (obj._data()[i].contents()[l].type() == "grid_x")
                        (obj._data()[i].contents()[l].content() <= 20) ? obj.crossword_grid_x(obj._data()[i].contents()[l].content()) : obj.crossword_grid_x(20);
                    if (obj._data()[i].contents()[l].type() == "grid_y")
                        (obj._data()[i].contents()[l].content() <= 20) ? obj.crossword_grid_y(obj._data()[i].contents()[l].content()) : obj.crossword_grid_y(20);
                }
            }
        }
        
        //Create an empty grid if it's the first time creating it.
        //Used so when the user is using the editing tool it doesn't create an empty grid every time.
        if (obj.grid().length == 0)
        {   
            for (var i = 0, len = obj.crossword_grid_y(); i < len; ++i)
            {
                obj.grid().push({"cols": ko.observableArray()});
                for (var l = 0, t_len = obj.crossword_grid_x(); l <  t_len; ++l) {
                    //console.log('pushing stuff');
                    obj.grid()[i].cols().push({"letter": ko.observable(""), "question": ko.observableArray(), "typing": ko.observable(false), "position": ko.observable({"first":ko.observable(false), "index":ko.observable(0), "label":ko.observable(false)})
                    });
                }
            }
        }
        else //Grid is being re-created through the editing tool, doesn't need all new empty values
        {
            for (var i = 0; i < obj.grid().length; ++i)
                for (var l = 0; l < obj.grid()[i].cols().length; ++l)
                {
                    obj.grid()[i].cols()[l].question.removeAll();
                    obj.grid()[i].cols()[l].letter("");
                    obj.grid()[i].cols()[l].position().first(false);
                    obj.grid()[i].cols()[l].position().index(0);                    
                }
        }
        
        //Find the responses and check where the words need to be
        for (var i = 0, len = obj.questions().length; i < len; ++i)
        {
            for (var l = 1, t_len = obj.questions()[i].responses().length; l < t_len; ++l)
            {
                if (get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") != -1)
                {
                    //Set the grid position to a number that's not -1 to show there is a letter there
                    obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].question.push(obj.questions()[i]);

                    var dir = get_response_data(obj.questions()[i].responses()[l]._data(), "direction");
                    var word = get_response_data(obj.questions()[i].responses()[l]._data(), "text");

                    if (dir == 0) {// sets the word numberings on the grid
                        obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") - 1].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].letter(i+1);
                        obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") - 1].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].position().label(true);
                    } else {
                        obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x") - 1].letter(i+1);
                        obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x") - 1].position().label(true);

                    }
                    //Show that this is the first letter in the word
                    obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].position({"first": ko.observable(true), "index": ko.observable(obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].question().length - 1), "label" : ko.observable(false) });
                    
                    for (var k = 1, l_len = word.length; k < l_len; ++k)
                    {
                        //0 = vertical, 1 = horizontal
                        if (dir == 0)
                        {
                            //Error check to make sure the index exists before trying to put a question into it
                            if (get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") + k < obj.grid().length)
                                obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") + k].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].question.push(obj.questions()[i]);
                        }
                        else
                        {
                            if (get_response_data(obj.questions()[i].responses()[l]._data(), "position_x") + k <  obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols().length)
                                obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")+k].question.push(obj.questions()[i]);
                        }
                    }
                }
            }
        }
    }
    
    obj.new_attempted_word = ko.observable({"word": ko.observable(""), "question": ko.observable(),"questions": ko.observableArray(), "x": ko.observable(), "y":ko.observable(), "id": ko.observable(-1)  });
    obj.hover_id = ko.observable({"id": ko.observable(-1), "x": ko.observable(-1), "y": ko.observable(-1) });
    
    var counter = 0;
    var start_location = -1;

    obj.input_blur = function()
    {
        $(".cwd-typing").removeClass("cwd-typing");
    }
    
    obj.type_letter = function(val) 
    {
        if(!obj.showing_answer() && obj.state() != 4)
        {
            //Clicked on a question from the side
            if (val != -1)
            {
                obj.new_attempted_word().question(obj.questions()[val]);
                obj.new_attempted_word().x(get_response_data(obj.questions()[obj.new_attempted_word().question().id()].responses()[1]._data(), "position_x"));
                obj.new_attempted_word().y(get_response_data(obj.questions()[obj.new_attempted_word().question().id()].responses()[1]._data(), "position_y"));
            }
            //Loop through the grid and clean any previous typing cells
            for (var i = 0, len = obj.crossword_grid_y(); i < len; ++i)
                for (var l = 0, t_len = obj.crossword_grid_x(); l <  t_len; ++l)
                    obj.grid()[i].cols()[l].typing(false);
                
            obj.grid()[obj.new_attempted_word().y()].cols()[obj.new_attempted_word().x()].typing(true);
            start_location = val;
            counter = 0;
            
            $(".cwd_input").focus();
        }
    }
    
    obj.cwd_input_response = ko.observable("");

    obj.cwd_input_response.subscribe( function(){
        obj.type_letter_new();
    })
    
    obj.type_letter_new = function() // gets called everytime you type a letter
    {
        if(!obj.showing_answer() && obj.state() != 4)
        {
            //Get the last letter from the string (Newest letter)
            var new_letter = obj.cwd_input_response()[obj.cwd_input_response().length-1];
            var word = get_response_data(obj.questions()[obj.new_attempted_word().question().id()].responses()[1]._data(), "text");
            var dir = get_response_data(obj.questions()[obj.new_attempted_word().question().id()].responses()[1]._data(), "direction");
            var start = get_response_data(obj.questions()[obj.new_attempted_word().question().id()].responses()[1]._data(), (dir == 0) ? "position_y" : "position_x");

            if (typeof new_letter === 'undefined')
                new_letter = "";
            
            if(!/^[0-9a-zA-Z\-]+$/.test(new_letter))
                return true;

            var entered_letter = new_letter;
            
            if (/^[a-z]+$/.test(entered_letter))
                entered_letter = entered_letter.toUpperCase();
            
            for(var i = 0, len = obj.grid()[obj.new_attempted_word().y()].cols()[obj.new_attempted_word().x()].question().length; i < len; ++i)
            {
                obj.questions()[obj.grid()[obj.new_attempted_word().y()].cols()[obj.new_attempted_word().x()].question()[i].id()].select_response(ko.observable(-1));
            } 
            
            //Loop through each question incase there are words intersecting on this letter
            for(var i = 0, len = obj.grid()[obj.new_attempted_word().y()].cols()[obj.new_attempted_word().x()].question().length; i < len; ++i)
            {
                obj.questions()[obj.grid()[obj.new_attempted_word().y()].cols()[obj.new_attempted_word().x()].question()[i].id()].select_response(ko.observable(0));
            }
                
            //Set the current grid letter to key press
            if (dir == 0)
            {
                obj.grid()[obj.new_attempted_word().y() + counter].cols()[obj.new_attempted_word().x()].letter(entered_letter);
                obj.grid()[obj.new_attempted_word().y() + counter].cols()[obj.new_attempted_word().x()].typing(false);
            }
            else
            {
                obj.grid()[obj.new_attempted_word().y()].cols()[obj.new_attempted_word().x() + counter].letter(entered_letter);
                obj.grid()[obj.new_attempted_word().y()].cols()[obj.new_attempted_word().x() + counter].typing(false);
            }
        
            //Increase counter to get the next letter
            if(start_location != -1)
            {
                counter += 1;
                
                //Counter is at the end of the word
                if ( counter >= word.length)
                {
                    //Take the focus away from the input box so the user can't type anymore
                    $(".cwd_input").blur();
                    obj.cwd_input_response("");
                }
                
                if (dir == 0)
                {                
                    obj.grid()[obj.new_attempted_word().y() + ( counter - 1)].cols()[obj.new_attempted_word().x()].typing(false);
                    if (obj.new_attempted_word().y() +  counter < obj.grid().length)
                        obj.grid()[obj.new_attempted_word().y() +  counter].cols()[obj.new_attempted_word().x()].typing(true);
                }
                else
                {
                    obj.grid()[obj.new_attempted_word().y()].cols()[obj.new_attempted_word().x() + ( counter - 1)].typing(false);
                    if (obj.new_attempted_word().x() +  counter < obj.grid()[obj.new_attempted_word().y()].cols().length)
                        obj.grid()[obj.new_attempted_word().y()].cols()[obj.new_attempted_word().x() +  counter].typing(true);
                }
            }
            
            obj.check_cwd_answer(); 

            return true;
        }
    }
    
    //Checks to see if any correct answers have been put in.
    obj.check_cwd_answer = function()
    {
        for (var i = 0, len = obj.questions().length; i < len; ++i) // 1
        {
            var cur_question = obj.questions()[i];
            
            if(cur_question.selected_response() !== 1) { // don't loop again on questions (words) that are already complete
                
                for (var l = 1, t_len = cur_question.responses().length; l < t_len; ++l) // 2
                {
                    var cur_response = cur_question.responses()[l];
                    //Get the direction the word is  in
                    var dir = get_response_data(cur_response._data(), "direction"); // 3
                    //Get the correct word
                    var word = get_response_data(cur_response._data(), "text");
                    //Will hold the letters the user has entered
                    var entered_word = "";
                    //Check to see if the word has been placed in editor yet
                    var pos_y = get_response_data(cur_response._data(), "position_y");
                    var pos_x = get_response_data(cur_response._data(), "position_x");
                    
                    //-1 means the question was just added and doesn't have a position yet. Will error when trying to check a position that doesn't exist
                    if (pos_y != -1)
                    {
                        for (var k = 0, l_len = word.length; k < l_len; ++k) // 4
                        {
                            //0 = vertical, 1 = horizontal
                            //Get the entered letters and append it to the string
                            if (dir == 0)
                                entered_word += obj.grid()[pos_y + k].cols()[pos_x].letter(); // 5
                            else
                                entered_word += obj.grid()[pos_y].cols()[pos_x + k].letter();
                            
                            if(k==l_len-1)
                            {
                                if (dir == 0)
                                {
                                    if(obj.grid()[pos_y + k].cols()[pos_x].letter() != "") //6 
                                        if(typeof obj.grid()[pos_y + k + 1] !== 'undefined') {
                                            obj.grid()[pos_y + k + 1].cols()[pos_x].letter("");
                                            break;
                                        }
                                }
                                else{
                                    if(obj.grid()[pos_y].cols()[pos_x + k].letter() != "")
                                        if(typeof obj.grid()[pos_y].cols()[pos_x + k + 1] !== 'undefined') {
                                            obj.grid()[pos_y].cols()[pos_x + k + 1].letter("");

                                            break;
                                        }
                                }
                            }
                        }

                        //Reset the question number labels on the grid, as everything was just cleared
                        if (dir == 0)
                            obj.grid()[pos_y - 1].cols()[pos_x].letter(i + 1);
                        else                    
                            obj.grid()[pos_y].cols()[pos_x - 1].letter(i + 1);
                        obj.product_select_exercise_cwd();
                    }
                    
                    //See if the entered word and the correct word match up
                    if (entered_word.toLowerCase() == word.toLowerCase()) {
                        cur_question.select_response(ko.observable(1));
                        break;
                    }
                }
            }
        }
    };
	
	/*
		Gets called when the exercise gets changed and it is CWD. 
		Will generate the question number labels on the grid to make sure
		they are the correct number when it is an AT
	*/
	obj.product_select_exercise_cwd = function()
	{
		if(viewModel._data.test() == 'true')
		{
			viewModel.get_exercise_start_question(viewModel.labs()[viewModel.selected_lab()].selected_group());
			for (var i = 0, len = obj.questions().length; i < len; ++i)
			{
				for (var l = 1, t_len = obj.questions()[i].responses().length; l < t_len; ++l)
				{
					if (get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") != -1)
					{
						var dir = get_response_data(obj.questions()[i].responses()[l]._data(), "direction");

						if (dir == 0) // sets the word numberings on the grid
							obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y") - 1].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x")].letter(i+viewModel.min_AT_question());
						else
							obj.grid()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_y")].cols()[get_response_data(obj.questions()[i].responses()[l]._data(), "position_x") - 1].letter(i+viewModel.min_AT_question());
					}
				}
			}
		}
	}
    
    obj.create_cwd_grid();
}


function product_helper_exercise_flc(obj){
    obj.selected_card = ko.observable(-1);
    obj.front_card = ko.observable(true);
    obj.view_list = ko.observable(true);
    obj.double_view = ko.observable(false);
    obj.auto_play = ko.observable(false);
    obj.audio = ko.observable(true);
    obj.showing_answer(false);

    //clear_flc_timeouts and play_audio() must be called BEFORE the selected_card gets changed!
    /*     obj.change_selected = function(id)
    {
        if(id < obj.questions().length && id >= 0)//make sure the card exists, otherwise don't do anything
        {
            obj.clear_flc_timeouts();
            play_audio(); //stop audio of previous card before switching to next card
            obj.selected_card(id);
            obj.front_card(true); //used to show image side of card first every time a card is flipped
            obj.check_task_completion();  
        }
    } */

    obj.on_click_card = function(id)
    {
        if(id < obj.questions().length && id >= 0)//make sure the card exists, otherwise don't do anything
        {
            obj.clear_flc_timeouts();
            play_audio(); //stop audio of previous card before switching to next card
            obj.selected_card(id);
            obj.check_task_completion();  
        }
    }

    obj.toggle_card = function(id)
    {
        var tar = $('.card-'+id);
        $('.flc-front').removeClass('no_transition');
        $('.flc-back').removeClass('no_transition');
        tar.toggleClass('flc-flip');
        $('.flc-click').one('transitionend', function () {
            $('.flc-front').addClass('no_transition');
            $('.flc-back').addClass('no_transition');
        })

        obj.front_card(!obj.front_card());
    }

    obj.check_task_completion = function()
    {
        obj.questions()[obj.selected_card()].select_response(ko.observable(0));
        // obj.check_answers(); //why is this needed?
    }

    obj.clear_flc_timeouts = function()
    {
        clearTimeout(obj.audio_timeout);
        clearTimeout(obj.auto_play_timeout);
    }

    obj.reset_flc = function(){
        obj.clear_flc_timeouts();
        play_audio();
        obj.selected_card(0);
        obj.front_card(true);
        obj.double_view(false);
        obj.auto_play(false);
        // obj.showing_answer(true);    
    }
}

function product_select_exercise_spk(obj, lab_height)
{    
    obj.drag_area_height_offset($('.SPK-exercise-'+obj.id())[0].offsetTop);  
    obj.drag_area_x($('.SPK-exercise-'+obj.id())[0].clientWidth);
    obj.drag_area_y($('.SPK-exercise-'+obj.id())[0].clientHeight - obj.drag_area_height_offset());
    if (obj.started() && obj.current_question() != -3 && !obj.progress_restored())
    {
        obj.timer(Date.now());
        obj.myTimer_update();
    }
}

function product_helper_exercise_spk(obj)
{
    //set some editing values
    obj.drag_pair_types = ko.observableArray(["text", "image"]);
    //get size offset
    obj.started = ko.observable(false);    
    obj.timer = ko.observable(0);
    obj.drag_area_height_offset = ko.observable();
    obj.drag_area_x = ko.observable(0);
    obj.drag_area_y = ko.observable(0);
    obj.attempt_times = ko.observableArray();
    obj.paused_timer = ko.observable(0);
    obj.progress_restored = ko.observable(true);
    obj.drag_area_ratio = ko.computed(function(){
        var ret = obj.drag_area_x() / obj.drag_area_y()
        if(isNaN(ret))
        {
            return 0;
        }
        return ret;
    });
    obj.current_question = ko.computed(function(){
        if(typeof obj.dragdrop === 'undefined' || !obj.dragdrop.initiated())
        {
            return -1;//peps need to be visible to init DND
        }
        else if(obj.started() == false)
        {
            //product_helper_adjust_single_drop_positions();
            return -2;//peps must hide after being shown until started
        }
        for( var i = 0, i_len = obj.questions().length; i < i_len; ++i )
        {
            for( var w = 0, w_len = obj.questions()[i].responses().length; w < w_len; ++w )
            {      
                if(!obj.questions()[i].responses()[w].selected())
                {
                    return i;
                }
            }
        }
        obj.check_answers();
        obj.showing_answer(true);
        return -3;
    });

    obj.current_question.subscribe( function(value){
        if(value >= 0 && value < obj.questions().length)
        {         
            product_helper_adjust_single_drop_positions();
        }        
        else if(value == -3)
        {
            if(!obj.progress_restored())
            {
                obj.timer(((Date.now() - obj.timer())/1000)+obj.paused_timer());            
                if(obj.attempt_times().length < 3)
                {
                    obj.attempt_times.push(obj.timer());
                }
                else
                {
                    var score_to_replace = -1;
                    for( var i = 0, len = obj.attempt_times().length; i < len; ++i )
                    {
                        if(obj.attempt_times()[i] > obj.timer())
                        {
                            score_to_replace = i;                        
                        }                
                    }
                    if(score_to_replace != -1)
                    {
                        obj.attempt_times()[score_to_replace] = obj.timer();                
                    }
                    //sort scores                
                }
            }            
            obj.attempt_times.sort(sortNumber);            
        }
        product_helper_calculate_spk_drag_area(obj);
    });
    
    obj.start_spk = function (){
        obj.started(true);
        product_helper_adjust_single_drop_positions();
        obj.timer(Date.now());
        obj.start_spk_timer()
        obj.progress_restored(false);
    }
    
    obj.reset_spk = function (){
        product_helper_adjust_single_drop_positions();
        for(var i = 0, len = obj.dragdrop.pep_objs().length; i < len; ++i)
        {
            obj.dragdrop.pep_objs()[i].dropped(false);            
            obj.dragdrop.pep_objs()[i].pep().removeClass('pep-dpa');
            $.pep.peps[obj.dragdrop.pep_objs()[i].pep_idx].activeDropRegions = [];
        }
        obj.started(false);
        obj.paused_timer(0);   
        obj.timer(0);
    }
    //subscribe to type change


    //Time displayed in the page header
    obj.spk_timer = ko.observable('00:00');
    //obj.spk_timer_holder = ko.observable('00:00');
    obj.spk_time = ko.observable(0);
    
    //Start the timer when doing an achievement test
    obj.start_spk_timer = function()
    {
        //Reset timer
        obj.spk_timer('00:00');        
        
        var newTimer = setInterval(function () {

            obj.myTimer_update();
        }, 1000);
        
        obj.myTimer_update = function (){
           
            if (obj.current_question() != -3 && obj.started())
            {
                var time_str = '' + Math.round((((Date.now() - obj.timer())/1000)+obj.paused_timer()));                
                obj.spk_timer(time_str);
            }
            else
                clearInterval(newTimer);          
        }
    }
}

function product_helper_calculate_spk_drag_area(obj)
{
    if($('.SPK-exercise-'+obj.id()).length)
    {
        obj.drag_area_x($('.SPK-exercise-'+obj.id())[0].clientWidth);
        obj.drag_area_y($('.SPK-exercise-'+obj.id())[0].clientHeight);
        if($('.SPK-instructions')[0].offsetParent !== null)
            obj.drag_area_height_offset($('.SPK-instructions')[0].clientHeight + $('.exercise-bar')[0].clientHeight);
        //obj.drag_area_height_offset($('.SPK-exercise-'+obj.id())[0].offsetTop);
        ////log(obj.drag_area_height_offset());
        ////log(obj.drag_area_x() + ' and the y is ' + obj.drag_area_y() + ' and the computed ratio is ' + obj.drag_area_ratio());
    }
}

function product_helper_exercise_giw(obj)
{
    //The question # that is selected
    obj.selected_question = ko.observable(-1);
    //The index # of the word in the word array
    obj.selected_word = ko.observable(-1);
    //Which part of the sentence the word is contained in. 0 = pre-text, 1 = wrong word, 2 = post_text
    obj.selected_area = ko.observable(-1);

    obj.word_list = ko.observableArray([]);
    
    //Returns an array of all the words within a string.
    obj.get_word_list_from_string = function(content)
    {
        return content.split(" ");
    }
    
    //Change state on the question that is being worked on.
    obj.check_giw_response = function(idx)
    {
        obj.questions()[obj.selected_question()].select_response(ko.observable(0));

        if (obj.questions()[obj.selected_question()].entered_response() != "")
        {
            obj.word_list()[idx].answered(1);
        }
    }
    
    //Reset the exercise to the default state.
    obj.clear_giw = function()
    {
        obj.selected_question(-1);
        
        for( var i = 0; i < obj.word_list().length; ++i)
        {
            obj.word_list()[i].selected(0);
            obj.word_list()[i].answered(0);
        }
    }
    
    //Clear all selections.
    obj.clear_selected = function()
    {
        for(var i = 0; i < obj.word_list().length; ++i)
        {
            if (obj.word_list()[i].question == obj.selected_question())
            {
                obj.word_list()[i].selected(0);
                obj.word_list()[i].answered(0);
            }
        }
        obj.questions()[obj.selected_question()].select_response(ko.observable(0));
    }
    
    obj.create_words_array = function()
    {
        //Make sure everything is cleared properly
        obj.word_list.removeAll();
        
        for(var i = 0; i < obj.questions().length; ++i)
        {
            var temp = [];
            var incorrect_word;
            for (var l = 0; l < obj.questions()[i]._data().length; ++l)
            {
                if (obj.questions()[i]._data()[l].type() == "question")
                {
                    if (product_helper_check_rec_question(obj.questions()[i]._data()) == false)
                    {
                        for (var c = 0; c < obj.questions()[i]._data()[l].contents().length; ++c)
                        {
                            temp = []
                            if (obj.questions()[i]._data()[l].contents()[c].type() == "text")
                                temp = obj.questions()[i]._data()[l].contents()[c].content().split(" ");
                            
                            for(var k = 0; k < temp.length; ++k)
                                obj.word_list.push({"word": temp[k], "question": i, "response": 0 , "selected": ko.observable(0), "answered": ko.observable(0), "rec": 0 });
                        }

                    }
                }
                if (obj.questions()[i]._data()[l].type() == "incorrect")
                    incorrect_word = obj.questions()[i]._data()[l].contents()[0].content();
            }
            if (!product_helper_check_rec_question(obj.questions()[i]._data()))
            {
                //Get incorrect word
                obj.word_list.push({"word": incorrect_word, "question": i, "response": 1, "selected": ko.observable(0), "answered": ko.observable(0), "rec": 0  });
                
                for (var l = 0; l < obj.questions()[i]._data().length; ++l)
                {
                    if (obj.questions()[i]._data()[l].type() == "post_question")
                    {
                        temp = obj.questions()[i]._data()[l].contents.content().split(" ");
                        for(var k = 0; k < temp.length; ++k)
                            obj.word_list.push({"word": temp[k], "question": i, "response": 0, "selected": ko.observable(0), "answered": ko.observable(0), "rec": 0  });
                    }
                }
            }
        }
    }
    
    //Gets all the answers for a question and returns them as a string.
    //@idx = The question ID.
    obj.get_answers = function(idx)
    {
        var ret = "";
        
        //Remove any selected words
        obj.clear_giw();

        //Loop through all the responses and append all the answers to a string
        for (var l = 0; l < obj.questions()[idx].responses().length; ++l)
        {
            for (var k = 0; k < obj.questions()[idx].responses()[l]._data().length; ++k)
            {
                //If it's not empty, then add a slash to separate the next word
                if (ret != "")
                    ret += "/";
                ret += obj.questions()[idx].responses()[l]._data()[k].content();
            }
        }
        
        //Return the finished string
        return ret;
    }
    
    //Restores the loaded progress.
    obj.set_giw_progress = function(word_idx)
    {
        obj.word_list()[word_idx].answered(1);
        obj.word_list()[word_idx].selected(1);
    }
    
    obj.create_words_array();
}

function product_helper_exercise_cas(obj)
{
    obj.selected_questions = ko.observableArray([obj.questions()[0]]);
    obj.selected_responses = ko.observableArray([]);
    obj.question_nums = ko.observableArray([]);
    obj.conclusion_summary = ko.observable("");
    obj.current_index = ko.observable(0);
    
    //Selects the next question node from the response that was clicked.
    //@question_idx = The current question ID 
    //@idx = The current response ID
    obj.select_cas_question = function(question_idx, idx)
    {
        //Flag for whether or not the question is the last in the list
        var last_node = false;
        obj.selected_responses.push(idx);
        obj.questions()[question_idx].select_response(ko.observable(idx));
        for (var i = 0; i < obj.questions()[question_idx].responses()[idx]._data().length; ++i)
        {
            //Find the next question id
            if (obj.questions()[question_idx].responses()[idx]._data()[i].type() == "question_link")
            {
                //If the question id is END, it is the last question in the list and the exercise is over
                if (obj.questions()[question_idx].responses()[idx]._data()[i].content() == "END")
                    last_node = true;
                else //Add the new question to the list to display
                    obj.selected_questions.push(obj.questions()[obj.questions()[question_idx].responses()[idx]._data()[i].content() - 1]);
                
                //Increase index so we know what question we are and we can disable previous questions
                obj.current_index(obj.current_index() + 1);
            }
        }
        
        //The last question was found, display the conclusion summary.
        if (last_node)
            obj.cas_show_answer();
    }
    
    //Clears and resets the exercise. Called when the user clicks on the Clear button.
    obj.clear_cas_exercise = function()
    {
        //Remove all the questions from the selected questions
        obj.selected_questions.removeAll();
        obj.selected_questions.push(obj.questions()[0]);
        //Clear the summary text
        obj.conclusion_summary("");
        //Reset index counter
        obj.current_index(0);
    }
    
    //Shows the summary at the end of the exercise
    obj.cas_show_answer = function()
    {
        //Summary text is stored on the first questions _data array
        for (var i = 0; i <obj._data().length; ++i)
        {
            //Find the summary text
            if (obj._data()[i].type() == "summary")
            {
                //Set the text to display on the template
                obj.conclusion_summary(obj._data()[i].contents()[0].content());
                break;
            }
        }
        viewModel.labs()[viewModel.selected_lab()].adjust_video_container();
        //Make sure everything is correct when at the end
        for (var i = 0; i < obj.questions().length; ++i)
        {
            if(obj.questions()[i].selected_response() == -1)
                obj.questions()[i].select_response(ko.observable(0));
        }
    }
    
    //Create the options list for the editor.
    obj.get_question_nums = function()
    {
        //Loop through each question and get the ID number
        for( var i = 0; i < obj.questions().length; ++i)
            obj.question_nums.push(obj.questions()[i].id() + 1);
        
        //At the END option at the end of the list, to allow the exercise to have a ending question
        obj.question_nums.push('END');
    }
    
    //Called when questions are added or removed, to keep the question number list in sync.
    obj.questions.subscribe(function() {
        //If a question was added
        if (obj.questions().length > obj.question_nums().length - 1)
            obj.question_nums.push(obj.questions()[obj.questions().length - 1].id() + 1);
        else if (obj.questions().length < obj.question_nums().length - 1) //If a question was removed
            obj.question_nums.splice(obj.question_nums().length - 2,1);
            
    });
    
    //Gets the question numbers that the current question can link to.
    //Removes the current index from the list so a question can't link to itself.
    obj.get_available_question_nums = function(idx)
    {
        //Empty array to hold the  modified question number array
        var ret = [];
        
        //Loop through each question
        for( var i = 0; i < obj.question_nums().length; ++i)
        {
            //If the current question number doesn't equal the index, then add it into the array
            if ( obj.question_nums()[i] != (idx + 1))
                ret.push(obj.question_nums()[i]);
        }
        
        //Return the finalized array
        return ret;
    }
    
    obj.linking_to_end = function(idx)
    {
        var ret = false;
        
        for (var i = 0; i < obj.questions()[idx].responses().length; ++i)
        {
            for (var k = 0; k < obj.questions()[idx].responses()[i]._data().length; ++k)
            {
                //Find the next question id
                if (obj.questions()[idx].responses()[i]._data()[k].type() == "question_link" && obj.questions()[idx].responses()[i]._data()[k].content() == "END")
                    ret = true;
            }
        }
        
        return ret;
    }
    
    obj.restore_cas_progress = function()
    {
        for (var i = 0; i < obj.questions().length; ++i)
        {
            if(obj.questions()[i].selected_response() != -1)
                obj.select_cas_question(i, obj.questions()[i].selected_response());
        }
    }
    
    obj.get_question_nums();
}

function product_helper_get_random_percent(max)
{
    return Math.floor(Math.random() * max) + 1;
}

function product_helper_get_random_percent_range(min,max)
{
    return Math.floor(Math.random() * (max - min) + min);
}

function dragdrop_model(obj)  //EXS
{
    var self = this;    
    self.drag_drop_config = ko.observable(product_helper_build_drag_drop_config(obj.type()));
    self.response_container = ko.observable(new response_container_obj());
    self.progress_restore = ko.observable(false);
    self.pep_objs = ko.observableArray();
    self.initiated = ko.observable(false);
    self.drop_regions = ko.observableArray();
    self.response_container_count = ko.observable(obj.questions().length);
    self.init = function(){
        if(typeof self.pep_objs() !== 'undefined' && !self.pep_objs().length)
        {
            var current_correct_drop = 0;
            var prev_question_num = 0;
            var response_num = (self.drag_drop_config().state_calc_type() == 5 ? 0 : 1);
            var spk_pair_counter = 0;
            var current_question_id = 0;

            for (var i = 0, len = $('.pep').length; i < len; ++i)
            {   
                var pep_obj = $('.pep')[i];
                if(pep_obj.offsetParent !== null)//is visible
                {
                    if(self.drag_drop_config().state_calc_type() == 1)
                    {
                        if (self.drag_drop_config().response_container_type() == 9)
                            self.pep_objs.push(new dragable_item_model(self, pep_obj, '.SFL-drop'));
                        else
                            self.pep_objs.push(new dragable_item_model(self, pep_obj));
                        
                        self.pep_objs()[self.pep_objs().length-1].correct_drop_region(self.pep_objs()[self.pep_objs().length-1].pep()[0].id);
                        self.pep_objs()[self.pep_objs().length-1].response_num(response_num); 
                        if(obj.type() == "SFL")
                        { 
                            for (var w = 0; w < obj.questions().length; ++w)
                            {
                                if (self.pep_objs()[self.pep_objs().length-1].pep()[0].id == w)
                                {
                                    for (var r = 0; r < obj.questions()[w].responses().length; ++r)
                                    {
                                        if (obj.questions()[w].responses()[r]._data()[0].content() == pep_obj.children[0].innerHTML)
                                        {
                                            self.pep_objs()[self.pep_objs().length-1].response_num(r);
                                        }
                                    }                                
                                }
                            }
                        }
                    }
                    else if (self.drag_drop_config().state_calc_type() == 2)
                    {
                        if (self.drag_drop_config().response_container_type() == 9)
                        {
                            self.pep_objs.push(new dragable_item_model(self, pep_obj, '.DFL-drop'));
                        }
                        else
                        {
                            self.pep_objs.push(new dragable_item_model(self, pep_obj));
                        }

                        self.pep_objs()[self.pep_objs().length-1].correct_drop_region(self.pep_objs()[self.pep_objs().length-1].pep()[0].id);
                        if(current_correct_drop != self.pep_objs()[self.pep_objs().length-1].pep()[0].id)
                        {
                            current_correct_drop = self.pep_objs()[self.pep_objs().length-1].pep()[0].id;
                            response_num = 1;
                        }
                        self.pep_objs()[self.pep_objs().length-1].response_num(response_num);
                        ++response_num;
                    }
                    else if (self.drag_drop_config().state_calc_type() == 3)
                    {

                    }
                    else if (self.drag_drop_config().state_calc_type() == 5)
                    {
                        self.pep_objs.push(new dragable_item_model(self, pep_obj, '.MF1-group-' + pep_obj.id));
                        
                        if (prev_question_num != parseInt(pep_obj.id))
                        {
                            prev_question_num = pep_obj.id;
                            response_num = 0;
                        }
                        self.pep_objs()[self.pep_objs().length-1].response_num(response_num);
                        
                        if(obj.questions()[pep_obj.id].responses()[response_num].correct())
                        {
                            self.pep_objs()[self.pep_objs().length-1].correct_drop_region(pep_obj.id);
                        }
                        else
                        {
                            self.pep_objs()[self.pep_objs().length-1].correct_drop_region(-1);
                        }
                       
                        ++response_num;                        
                    }
                    else if (self.drag_drop_config().state_calc_type() == 6)
                    {
                        if(current_question_id != pep_obj.id)
                        {
                            current_question_id = pep_obj.id;
                            spk_pair_counter = 0;
                        }                        
                        self.pep_objs.push(new dragable_item_model(self, pep_obj , '.SPK-pair-' + pep_obj.id +'-'+ Math.floor(spk_pair_counter/2)));                                             
                        self.pep_objs()[self.pep_objs().length-1].response_num(Math.floor(spk_pair_counter/2));
                        ++spk_pair_counter;
                    }    
                    else if(self.drag_drop_config().state_calc_type() == 7)
                    {
                        self.pep_objs.push(new dragable_item_model(self, pep_obj, '.WSB-droper_'+pep_obj.id));
                        self.pep_objs()[self.pep_objs().length-1].correct_drop_region(self.pep_objs().length-1);
                        self.pep_objs()[self.pep_objs().length-1].response_num(response_num);  
                        ++response_num;
                    }
                }
            }
            for (var i = 0, len = $('.drop-target').length; i < len; ++i)
            {   
                var drop_target = $('.drop-target')[i];
                if(drop_target.offsetParent !== null)//is visible
                {                    
                    self.drop_regions.push(drop_target);
                }
            }
            //shuffle a few times
            if(self.drag_drop_config().state_calc_type() == 7)
            {
                for(var i = 0, len = 10; i < len; ++i)
                {
                    var temp_array = [];
                    var response_totals = 0;
                    var quest_array = [];
                    
                    for (q = 0, q_len = obj.questions().length; q < q_len; ++q)
                    {
                        quest_array = [];
                        
                        //Skip any rec questions, since we don't want to create any pep objects for it
                        if (product_helper_check_rec_question(obj.questions()[q]._data()) == false)
                        {
                            for (r = 0, r_len = obj.questions()[q].responses().length-1; r < r_len; ++r)
                                quest_array.push(self.pep_objs()[r + response_totals]);

                            response_totals += obj.questions()[q].responses().length-1;
                            product_helper_array_shuffle(quest_array);
                            
                            for (r = 0, r_len = quest_array.length; r < r_len; ++r)
                                temp_array.push(quest_array[r]);
                        }
                    }
                    self.pep_objs(temp_array);
                }
                initiate_response_container(self);
            }
            else
            {
                for(var i = 0, len = 10; i < len; ++i)
                {
                    product_helper_array_shuffle(self.pep_objs());
                }
                initiate_response_container(self);
            }
        }
        self.initiated(true);
        adjust_response_container(self);
        adjust_drag_item_positions(self);
        if(obj.type() == "MT1" && !obj.checked_answer())
        {
            calculate_drag_drop_state(self, obj);
        }
    }
    self.handle_start = function(pep_obj, ev, drag_obj)
    {
        handle_drag_start(self, pep_obj, ev, drag_obj);
    }
    self.handle_drag = function(pep_obj, ev, drag_obj)
    {
        handle_drag_event(self, pep_obj, ev, drag_obj);

        //WSB so that it only highlights the active drop region
        if(obj.type() == "WSB")
        {
            $('.WSB-active-drop').removeClass('WSB-active-drop');
            if(drag_obj.activeDropRegions[0].hasClass('WSB-drop-hover') && drag_obj.activeDropRegions[0].hasClass('pep-dpa'))
            {
                drag_obj.activeDropRegions[0].addClass('WSB-active-drop');
            }
        }
        if(self.drag_drop_config().state_calc_type() == 1)
        {
            $('.MT1-active-drop').removeClass('MT1-active-drop');
            if(drag_obj.activeDropRegions.length)
            {
                if(drag_obj.activeDropRegions[0].hasClass('MT1-drop-hover') && drag_obj.activeDropRegions[0].hasClass('pep-dpa'))
                    $('#MT1'+obj.id()+'_'+drag_obj.activeDropRegions[0].attr('id')).addClass('MT1-active-drop');
            }
        }
        if(obj.type() == "DFL")
        {
            $('.DFL-question-container').removeClass('DFL-question-container-active');
            if(drag_obj.activeDropRegions.length)
            {
                if(drag_obj.activeDropRegions[0].hasClass('pep-dpa'))
                {
                    drag_obj.activeDropRegions[0].parent().addClass('DFL-question-container-active');
                }
            }
        }
        else if(obj.type() == "SFL")
        {
            $('.SFL-active-drop').removeClass('SFL-active-drop');
            if(drag_obj.activeDropRegions.length)
            {
                if(drag_obj.activeDropRegions[0].hasClass('SFL-drop-hover') && drag_obj.activeDropRegions[0].hasClass('pep-dpa'))
                    drag_obj.activeDropRegions[0].addClass('SFL-active-drop');
            }
        }

    }
    self.revert_drag_item = function(pep_idx)
    {
        revert_drag_item(self, pep_idx, obj);
        adjust_response_container(self);
    }
    self.handle_drop = function(pep_obj, drag_obj)
    {
        handle_drop(self, pep_obj, drag_obj);  

        if(obj.type() == "DFL")
        {
            $('.DFL-question-container').removeClass('DFL-question-container-active');
        }      
    }
    self.adjust_response_container = function()
    {        
        adjust_response_container(self);
    }
    self.adjust_drag_item_positions = function()
    {
        adjust_drag_item_positions(self);
    }
    self.update_state = function()
    {
        calculate_drag_drop_state(self, obj);
    }
    self.restore_progress = function(progress_str)
    {
        ////log(progress_str);
        //split str into array
        var dragdrop_progress = progress_str.split(',');
        //loop array 
        self.progress_restore(true);
        for (var p = 0, len = dragdrop_progress.length; p < len; ++p)
        {   
            ////log(dragdrop_progress[p]+ ' loop p ' + p);
            if(typeof dragdrop_progress[p] === 'undefined' || dragdrop_progress[p] == ''){continue;}
            var progress_data = dragdrop_progress[p].match( /l(\d+)e(\d+)q(\d+)r(\d+)\|q(\d+)/i );
            //loop pep objs match data 3 with correct drop region.            
            var drop_container = undefined;
            if(parseInt(progress_data[4]) > 0 || obj.type() == "WSB")
            {         
                var drop_containers = $('.drop-target');
                if (obj.type() == "MF1")
                    drop_containers = $('.MF1-drop');
                if (obj.type() == "WSB")
                    drop_containers = $('.WSB-drop');

                var tmp_count = 0;
                for(var i = 0, tmp_len = drop_containers.length; i < tmp_len; ++i)
                {   
                    if(drop_containers[i].offsetParent !== null)//is visible
                    {     
                        if(drop_containers[i].id == progress_data[5])
                        {
                            if(drop_containers[i].className.match(/SFG-group/))
                            {   
                                if(!drop_containers[i].children.length)
                                    drop_container = drop_containers[i];
                            }
                            else if(obj.type() == "MF1")
                                drop_container = $('.MF1-group-'+i);
                            else if(obj.type() == "WSB")
                            {
                                var quest_num = drop_containers[i].className.match(/.WSB-droper_(\d+)/);
                                if (quest_num[1] == progress_data[3])
                                {
                                    drop_container = drop_containers[i];
                                    ////log("progress_data[5]: " + progress_data[5] + ", drop_containers[i].id: " + drop_containers[i].id + ", quest_num[1]: " + quest_num[1] + ", progress_data[3]: " + progress_data[3] + ", progress_data: " + progress_data);
                                }
                            }
                            else
                                drop_container = drop_containers[i]; 
                        }
                    }
                }
                
                for(var i = 0, tmp_len = self.pep_objs().length; i < tmp_len; ++i)
                {           
                    if (obj.type() == "MF1")
                    {
                        if(self.pep_objs()[i].response_num() == progress_data[4] && self.pep_objs()[i].pep()[0].id == progress_data[5])
                        {
                            restore_pep_object(i, drop_container);       
                        }
                    }
                    else if (obj.type() == "WSB")
                    {
                        if(self.pep_objs()[i].response_num() == progress_data[4])
                        {
                            restore_pep_object(i, drop_container);       
                        }
                    }
                    else
                    {
                        if(self.pep_objs()[i].response_num() == progress_data[4] && self.pep_objs()[i].correct_drop_region() == progress_data[3])
                        {
                            restore_pep_object(i, drop_container);                 
                        }
                    }
                }                
            }
            else
            {
                var drop_containers = $('.drop-target');
                if (obj.type() == "MF1")
                    drop_containers = $('.MF1-drop');

                for(var i = 0, tmp_len = drop_containers.length; i < tmp_len; ++i)
                {                        
                    if(drop_containers[i].offsetParent !== null)//is visible
                    {     
                        if(drop_containers[i].id == progress_data[5])
                        {
                            if(obj.type() == "SFG")
                            {
                                if(drop_container[i].className.match(/SFG-group/))
                                {
                                    //Check to see if there is a item already in the drop container
                                    if (!drop_container[i].children.length)
                                    {
                                        drop_container = drop_containers[i]; 
                                    }
                                }
                            }
                            else
                                drop_container = drop_containers[i]; 
                        }
                    }
                }
                
                if(self.drag_drop_config().state_calc_type() == 1)
                {
                    for(var i = 0, tmp_len = self.pep_objs().length; i < tmp_len; ++i)
                    {                              
                        if(self.pep_objs()[i].correct_drop_region() == progress_data[3])
                        {
                            restore_pep_object(i, drop_container);  
                        }                   
                    }
                }
                else if(self.drag_drop_config().state_calc_type() == 5)
                {
                    for(var i = 0, tmp_len = self.pep_objs().length; i < tmp_len; ++i)
                    {           
                        if(self.pep_objs()[i].response_num() == progress_data[4] && self.pep_objs()[i].pep()[0].id == progress_data[5])
                        {
                            restore_pep_object(i, drop_container);            
                        }
                    }
                }                
            }            
        }
        
        function restore_pep_object(index_num, drop_container)
        {
            self.pep_objs()[index_num].previous_drop_region(self.pep_objs()[index_num].drop_region());
            self.pep_objs()[index_num].drop_region($(drop_container));
            self.pep_objs()[index_num].dropped(true);
            handle_drop(self, self.pep_objs()[index_num]);
            handle_double_drop(self, self.pep_objs()[index_num]);
            adjust_drag_item_positions(self);    
        }
        
        self.progress_restore(false);
        self.update_state();   
    }
    self.get_progress_str = function(lab_num, ex_num)
    {
        var ret = '';
        for(var i = 0, len = self.pep_objs().length; i < len; ++i)
        {
            if(self.pep_objs()[i].dropped())
            {
                if(self.pep_objs()[i].drop_region()[0].id == self.pep_objs()[i].correct_drop_region() && self.drag_drop_config().state_calc_type() != 7 && self.drag_drop_config().state_calc_type() != 1 )
                {
                    ret += ',l'+lab_num+'e'+ex_num+'q'+self.pep_objs()[i].correct_drop_region()+'r'+self.pep_objs()[i].response_num()+'|q'+self.pep_objs()[i].correct_drop_region();
                    //I don't know what I wrote this line for, next time write what exs it's for (KT)
                    //viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].questions()[self.pep_objs()[i].correct_drop_region()].scorm_info().user_ans(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].questions()[self.pep_objs()[i].correct_drop_region()].responses()[self.pep_objs()[i].response_num()]._data()[0].content());
                }
                else
                {
                    if(self.drag_drop_config().state_calc_type() == 2)
                    {
                        ret += ',l'+lab_num+'e'+ex_num+'q'+self.pep_objs()[i].correct_drop_region()+'r'+self.pep_objs()[i].response_num()+'|q'+self.pep_objs()[i].drop_region()[0].id;
                    }
                    else if(self.drag_drop_config().state_calc_type() == 5 || self.drag_drop_config().state_calc_type() == 7)
                    {
                        ret += ',l'+lab_num+'e'+ex_num+'q'+self.pep_objs()[i].pep()[0].id+'r'+self.pep_objs()[i].response_num()+'|q'+self.pep_objs()[i].drop_region()[0].id;
                    }
                    else
                    {
                        if(self.drag_drop_config().revert_type() == 9) //SFL
                        {
                            ret += ',l'+lab_num+'e'+ex_num+'q'+self.pep_objs()[i].correct_drop_region()+'r'+self.pep_objs()[i].response_num()+'|q'+self.pep_objs()[i].drop_region()[0].id;
                        }
                        else //MT1 and SPK
                        {
                            ret += ',l'+lab_num+'e'+ex_num+'q'+self.pep_objs()[i].correct_drop_region()+'r0|q'+self.pep_objs()[i].drop_region()[0].id;
                        }
                        
                        ////log(self.pep_objs()[i].pep_idx);
                    }
                }
            }
        }
        return ret;
    }
}



function dragable_item_model(obj, pep_obj, drop_group)
{
    var self = this;    
    self.dropped = ko.observable(false);
    self.drop_region = ko.observable(-1);
    var drop_region_group = '.drop-target';
    if (typeof drop_group !== 'undefined')
        drop_region_group = drop_group;
    self.previous_drop_region = ko.observable(-1);
    self.correct_drop_region = ko.observable();    
    self.response_num = ko.observable();
    self.offset_x = ko.observable();
    self.offset_y = ko.observable();
    self.position = ko.observable(0);
    self.pep = ko.observable($(pep_obj).pep({
        callIfNotStarted: ['stop'],
        droppable: drop_region_group,   
        overlapFunction: false,
        useCSSTranslation: false,
        shouldEase: false,
        start: function(ev, drag_obj){
            obj.handle_start(self, ev, drag_obj);
        },
        drag: function(ev, drag_obj){
            obj.handle_drag(self, ev, drag_obj);
        },
        stop: function(ev, drag_obj){            
            if(obj.drag_drop_config().drop_type() == 6)
            {
                if(typeof drag_obj.activeDropRegions !== 'undefined' && drag_obj.activeDropRegions.length > 1 )
                {
                    //success                              
                    ////log(product_helper_get_next_question());
                    obj.update_state();                  
                }
                else
                {
                    //revert
                    handle_revert(obj, self, drag_obj);
                }
            }
            else if(typeof drag_obj.activeDropRegions !== 'undefined' && drag_obj.activeDropRegions.length)
            {            
                if(self.dropped())
                {
                    if( drag_obj.activeDropRegions[0][0].id != self.drop_region()[0].id )//unstyle the old region
                    {
                        if (obj.drag_drop_config().double_drop_type() != 7)
                        {
                            if (obj.drag_drop_config().response_container_type() != 9)
                            {
                                self.previous_drop_region(self.drop_region());
                            }
                        }
                        self.drop_region().attr('style','');
                    } 
                }
                
                self.offset_x(drag_obj.$el[0].offsetLeft);
                self.offset_y(drag_obj.$el[0].offsetTop);
                self.drop_region(drag_obj.activeDropRegions[0]);                
                self.dropped(true);
                obj.handle_drop(self, drag_obj);
                //attach_drag_item_to_drop_container(self, drag_obj);
                //console.log('item '+ self.pep_idx +' dropped in ' + self.drop_region()[0].id + ' expecting container ' + self.correct_drop_region() + ' response_num '+ self.response_num() + ' ');
                //handle double drop
                handle_double_drop(obj, self);
                if (obj.drag_drop_config().double_drop_type() != 7)
                {
                    if (obj.drag_drop_config().response_container_type() != 9)
                    {
                        self.previous_drop_region(self.drop_region());
                    }
                }
                //state calc  
                obj.update_state();
                obj.adjust_response_container();
                obj.adjust_drag_item_positions();
            }
            else
            {
                handle_revert(obj, self, drag_obj);                
                obj.update_state();                                     
                obj.adjust_response_container();
                obj.adjust_drag_item_positions();
            }           
        }
    }));    
    self.pep_idx = ($.pep.peps.length-1);  
}

//Exercise level product functions
function product_clear_questions(obj, lab_id)
{    
    obj.showing_answer(false);
    obj.checked_answer(false);
    obj.check_answer_count(0);
    
    if(obj.type() == "SPK")
    {
        obj.reset_spk();
    }
    
    if(product_helper_is_drag_drop_type(obj.type()))
    {           
        clear_drag_drop_exercise(obj);       
    }
    
    ko.utils.arrayForEach(obj.questions(), function (item) {
        item.clear();
        item.score(0);
    });

    if(obj.type() == "FLC")
    {
        obj.reset_flc();
    }

    if(obj.type() == "HNG")
    {
        for(var i = 0; i < obj.questions().length; ++i)
        {            
            for(var k = 0; k < obj.questions()[i].letter_array().length; ++k)
            {
                obj.questions()[i].letter_array()[k].selected(0);
            }
            obj.questions()[i].hintcounter(3)
            obj.questions()[i].incorrect_count(0)
            obj.build_word(i,obj.questions()[i].word_to_guess(),false);
        }
    }

    if(obj.type() == "CWD")
    {
        obj.create_cwd_grid();
    }
    
    if(obj.type() == "WDS")
    {
        obj.clear_cell_bindings();
        obj.clicked_cell({"x":0, "y": 0});
        for(var i = 0, len = obj.wds_grid().length; i < len; ++i)
        {
            for(var k = 0, k_len = obj.wds_grid()[i].cols().length; k < k_len; ++k)
            {
                obj.wds_grid()[i].cols()[k].selected(false);
                obj.wds_grid()[i].cols()[k].correct(false);
            }
        }
    }    
    if (obj.type() == "TTT")
    {
        for (var i = 0; i < obj.ttt_grid().length; ++i)
        {
            for (var l = 0; l <  obj.ttt_grid()[i].cols().length; ++l)
            {
                if (i == 1 && l == 1)
                    continue;                
                obj.ttt_grid()[i].cols()[l].selected(0);
                obj.ttt_grid()[i].cols()[l].correct(0);
            }
        }
        obj.randomize_game();
    }

    if (obj.type() == "MCH")
    {
        for (var i = 0; i < obj.mch_grid().length; ++i)
        {
            for (var l = 0; l <  obj.mch_grid()[i].cols().length; ++l)
            {
                obj.mch_grid()[i].cols()[l].selected(0);
                obj.mch_grid()[i].cols()[l].correct(0);
            }
        }
        obj.randomize_game();
    }
    if(obj.type() == "GIW")
    {
        obj.clear_giw();
    }
    if (obj.type() == "CAS")
    {
        obj.clear_cas_exercise();
    }

    play_audio();
    
}

function product_check_answers(obj)
{
    if(typeof obj.user_action !== 'undefined')
    {        
        obj.user_action(1);
    }
    obj.check_answer(1);
    obj.check_answer_count(obj.check_answer_count()+1)
    obj.checked_answer(true);
    obj.historical_progress('');    
}

function product_show_answers(obj)
{
    obj.showing_answer(true);
    if(obj.type() == 'WSB')
    {
        show_drag_drop_answer(obj);
    }

    ko.utils.arrayForEach(obj.questions(), function (item) {            
       if(obj.type() != 'WSB' && product_helper_is_drag_drop_type(obj.type()))
        {
            show_drag_drop_answer(obj);
        }
        else if (obj.type() == "TYP" || obj.type() == "GIW")
        {
            item.show_answer(obj.type(), obj.id(), 0);
            //Initialize the bootstrap popover functionality
            obj.init_popover();
        }
        else if (obj.type() == "HNG")
        {
            for(var i = 0; i < obj.questions().length; ++i)
            {
                for (var w = 0; w < obj.questions()[i].letter_array().length; w++)
                {
                    if (obj.questions()[i].letter_array()[w].right() == 1)
                    {
                        obj.questions()[i].letter_array()[w].selected(1);
                        obj.build_word(i,obj.questions()[i].word_to_guess(),false);
                    }
                   
                }
            }
        }
        else if (obj.type() == "CWD")
        {
            for(var i = 0; i < obj.questions().length; ++i)
            { 
                var word,x,y,dir;
                for(var l = 0; l < obj.questions()[i].responses()[1]._data().length; ++l)
                {
                    if (obj.questions()[i].responses()[1]._data()[l].type() == "text")
                        word = obj.questions()[i].responses()[1]._data()[l].content();
                    if (obj.questions()[i].responses()[1]._data()[l].type() == "direction")
                        dir = obj.questions()[i].responses()[1]._data()[l].content();
                    if (obj.questions()[i].responses()[1]._data()[l].type() == "position_x")
                        x = obj.questions()[i].responses()[1]._data()[l].content();
                    if (obj.questions()[i].responses()[1]._data()[l].type() == "position_y")
                        y = obj.questions()[i].responses()[1]._data()[l].content();
                }

                for (var n = 0; n < word.length; ++ n)
                {
                    if (dir == 0)
                        obj.grid()[y+n].cols()[x].letter(word[n]);
                    else
                        obj.grid()[y].cols()[x+n].letter(word[n]);
                }
            }  
            $(".cwd-typing").removeClass("cwd-typing");
        }
        else if (obj.type() == "WDS")
        {
            for (var i = 0; i < obj.grid_y(); ++i)
            {
                for (var l = 0; l <  obj.grid_x(); ++l)
                {
                    //Check to see if there is a question in the cell, and then highlight it
                    if (obj.wds_grid()[i].cols()[l].question().length > 0)
                        obj.wds_grid()[i].cols()[l].correct(true);
                }
            }
        }
        else if (obj.type() == "CAS")
        {
            obj.cas_show_answer();
        }
        else if (obj.type() == "MCH")
        {
            for (var i = 0; i < obj.mch_grid().length; ++i)
            {
                for (var l = 0; l <  obj.mch_grid()[i].cols().length; ++l)
                {
                    obj.mch_grid()[i].cols()[l].selected(true);
                }
            }
        }
        else if (obj.type() == "TTT"){}
        else
        {
            item.show_answer(obj.type(), obj.id(), 0);
        }      
    });        
}

function product_stimuli_model(obj)
{
    if(obj.type() == "audio" || obj.type() == "video")
    {
        obj.selected_audio_text = ko.observable(0);
        obj.player_pos = ko.observable();
        obj.player = undefined;
        obj.slideshow_image_position = ko.observable(0);
        obj.offset_top_scroll = ko.observable(0);

        obj.scroll_setter = function() 
        {
            var selected_audio_text = $('.audio-text.selected');
            // var stim_section = $('.stimulus');
            var stim_section = $('.video_text_wrapper');
            var stim_section_selector = $('.stimulus-selector');

            for(var i = 0, i_len = selected_audio_text.length; i < i_len; ++i)
            {
                if(selected_audio_text[i].offsetParent != null)
                {
                    if (stim_section_selector[0] == undefined)
                        obj.offset_top_scroll((selected_audio_text[i].offsetTop + selected_audio_text[i].offsetHeight + 35)-stim_section[0].clientHeight);
                    else
                        obj.offset_top_scroll((selected_audio_text[i].offsetTop + selected_audio_text[i].offsetHeight + 35 + stim_section_selector[0].offsetHeight + stim_section_selector[0].offsetTop)-stim_section[0].clientHeight);

                }
            }
        };
        
        obj.maintain_image_data = ko.computed(function(){
            for (var i = 0, len = obj.contents().length; i < len; ++i){
                if(obj.contents()[i].type() == 'slideshow' || obj.contents()[i].type() == 'video'){
                    if(!obj.contents()[i].value.images().length){
                        img_obj = {
                            "text": "",
                            "image": "",
                            "id": 0,
                            "time": "0"
                        }
                        obj.contents()[i].value.images.push(ko.mapping.fromJS(img_obj));
                    }
                    for (var j = 0, jen = obj.contents()[i].value.images().length; j < jen; ++j){
                        obj.contents()[i].value.images()[j].id(j)
                    }
                }
            }
        });
        
        obj.show_progress = function(player)
        {
            var media = $('#'+player);
            for (var l = 0; l < media.length; ++l)
            {        
                if(media[l].offsetParent !== null && typeof $('#'+media[l].id)[0].stop === 'undefined' && ('#'+media[l].id).indexOf('mep') == -1)
                {
                    if(media[l].id.indexOf('audio')>-1)
                    {
                        $('#'+media[l].id).mediaelementplayer({
                            audioWidth: '100%',
                            audioHeight: '100%',
                            loop: false,
                            startVolume: 0.8,
                            preLoad: true,
                            features: ['playpause', 'current', 'progress', 'volume'],
                            alwaysShowControls: true,
                            alwaysShowHours: false,
                            showTimecodeFrameCount: false,
                            pauseOtherPlayers: true,
                            pluginPath: '/static/framework/media-elements/',
                            flashName: 'flashmediaelement.swf'                    
                        });

						
						if (isMobileSafari()) {
							document.getElementById(media[l].id).addEventListener('timeupdate', function() {
								product_helper_av_text_events(obj, this);
							})
						} else {
							$(media[l]).bind('timeupdate', function() {
								product_helper_av_text_events(obj, this);
							});
						}
                        
                        //Called once the slide show has finished playing
                        $(media[l]).bind('ended', function() {
                            //Reset the selected text to the first paragraph
                            obj.selected_audio_text(0);
                            obj.scroll_setter();
                            $('.stimulus').animate({scrollTop: (obj.offset_top_scroll())+"px"});
                            play_audio();
                        }); 
                    }
                    if(media[l].id.indexOf('video')>-1)
                    {
                        $('#'+media[l].id).mediaelementplayer({
                            audioWidth: '100%',
                            audioHeight: '100%',
                            loop: false,
                            startVolume: 0.8,
                            preLoad: true,
                            features: ['playpause', 'current', 'progress', 'volume', 'fullscreen'],
                            alwaysShowControls: true,
                            alwaysShowHours: false,
                            showTimecodeFrameCount: false,
                            pauseOtherPlayers: true,
                            pluginPath: '/static/framework/media-elements/',
                            flashName: 'flashmediaelement.swf'                    
                        });

                        //Called when the time is changed on a playing mediaplayer
                        $(media[l]).bind('timeupdate', function() {
                            product_helper_av_text_events(obj, this);
                        });
                        
                        //Called once the slide show has finished playing
                        $(media[l]).bind('ended', function() {
                            //Reset the selected text to the first paragraph
                            obj.selected_audio_text(0);
                            obj.scroll_setter();
                            $('.stimulus').animate({scrollTop: (obj.offset_top_scroll())+"px"});
                            play_audio();
                        }); 
                    }

                    //Loop through each content object to find the images of the slideshow
                    for (var i = 0; i < obj.contents().length; ++i)
                    {
                        //If images is not undefined, then we found them
                        if (typeof obj.contents()[i].value.images !== 'undefined')
                            obj.slideshow_image_position(i); //Set the index position of the images
                    }

                    //Pause any exercise audio when playing stimuli audio
                    $(media[l]).bind('play', function() {
                        play_audio();
                    });
                }
                
                else
                {
                    if(media[l].id.indexOf('video')>-1 || media[l].id.indexOf('audio')>-1)
                    {
                        if (!$('#'+media[l].id)[0].paused)
                        {
                            play_audio();
                            if(!isMobileSafari())
                                $('#'+media[l].id)[0].player.pause();
                            else
                                $('#'+media[l].id)[0].pause();
                        }
                    }
                }
            }
            var fullscreen_btn = $('.mejs-fullscreen-button');

            for (var l = 0; l < fullscreen_btn.length; ++l)
            {
                if(fullscreen_btn[l].offsetParent !== null)
                {
                    if(!$(fullscreen_btn[l]).hasClass("sena-icon")){
                        $(fullscreen_btn[l]).addClass("sena-icon sena-icon-fullscreen fullscreen-video-button link-cursor");
                        $($(fullscreen_btn[l]).children()[0]).css({ "visibility": "hidden"});
                        //fullscreen_btn.children()[0].remove();
                        $(fullscreen_btn[l]).click(function(ev)
                        {
                            if(!isMobileSafari())
                            {
                                $('#framework_header').css({ "visibility": "hidden"});
                                $('#main').css({ "padding": "0"});  
                            }      
                        });
                    }
                }
            }
        };
        
        //Called when the user has clicked on text in the audio stimuli.
        obj.set_selected_audio_text = function(text_id,time,exercise_num) {
            //log(text_id);
            //Set the current text paragraph that is selected
            obj.selected_audio_text(text_id);
            if ($('#audio_slideshow_0_'+exercise_num).length > 0)
            {
                //Set the time matched with the text and then start playing the audio
                $('#audio_slideshow_0_'+exercise_num)[0].setCurrentTime(time / 1000);
                $('#audio_slideshow_0_'+exercise_num)[0].play();
            }
            if ($('#video_scrolltext_0_'+exercise_num).length > 0)
            {
                //Set the time matched with the text and then start playing the audio
                $('#video_scrolltext_0_'+exercise_num)[0].setCurrentTime(time / 1000);
                $('#video_scrolltext_0_'+exercise_num)[0].play();
            }
        };

        obj.current_image = ko.computed(function(){
            var id = 0;

            for ( var i = 0; i < obj.contents().length; ++i)
            {            
                if(obj.contents()[i].type() == "slideshow")
                {
                    for ( var w = 1; w < obj.contents()[i].value.images().length; ++w)
                    {
                        if(obj.contents()[i].value.images()[w].time() < obj.player_pos())
                        {
                            id++;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
            return id;
        });
    }
    
    //Number of tool_tips on the stimuli
    obj.tip_count = ko.observable(-1);
    
    //Creates a tool tip for stimuli types that allow text functionality.
    //@content = The string content of the input box.
    //@exercise_id = The exercise ID.
    //@contents_id = The contents ID.
    //@value_id = The value ID. Only used for ol and ul types.
    obj.create_stimuli_tool_tip = function(content, exercise_id,contents_id,value_id)
    {
        //console.log("i try to make a tool tip with stim id: " + exercise_id + " and contents id: " + contents_id+ " and value id: "+ value_id);
        //Get the starting index. If value_idx is undefined, don't add it to the name
        var start = $('#stimuli_input_' + exercise_id +'_'+contents_id+(value_id == -1 ? '' : "_"+value_id))[0].selectionStart;
        //Get the end of the selected word. If value_idx is undefined, don't add it to the name
        var end = $('#stimuli_input_' + exercise_id +'_'+contents_id+(value_id == -1 ? '' : "_"+value_id))[0].selectionEnd;
        
        viewModel.create_tip(content, start, end, true);
    }

    if(is_editable)
    {
        product_edit_stimuli_model(obj);
        edit_stimuli_model(obj);
    }
}

function product_stimuli_contents_model(obj)
{
    obj.type.subscribe(function(){
        if(obj.type() == 'slideshow' || obj.type() == 'picture'){
            obj.value = ko.mapping.fromJS({"audiosrc": "", "images": [], "coverimg": ""});
        }
        else if(obj.type() == 'video'){
            obj.value = ko.mapping.fromJS({"video_src": "", "images": []});
        }
        else if(obj.type() == 'ol' || obj.type() == 'ul'){
            obj.value = ko.observableArray([new value_model("")]);
        }
    });
    
    if(is_editable)
    {
        edit_stimuli_contents_model(obj);
    }
}

function product_question_model(obj)
{
    obj.selectbox_response = ko.observable();
    obj.playing_audio = ko.observable(false);
    obj.recording = ko.observable(false);
    obj.playing_recording = ko.observable(false);
    obj.flash_fallback_data = ko.observable("");
    if(initialized){
        obj.scorm_info = ko.observable({"id": ko.observable(""), "type": ko.observable(""), "description": ko.observable(""), "correct_ans": ko.observable(""), "user_ans": ko.observable(""), "result": ko.observable("")});
    }
    
    /*
        Gets all of the TYP responses and formats them on to a single
        string. Will add a '/' to separate each response. Used when
        showing answer is called.
    */
    obj.TYP_get_answer = function()
    {
        var ret = "";
        
        //Loop through all the responses
        for(var i = 0, len = obj.responses().length; i < len; ++i)
        {
            for(var k = 0, lenK = obj.responses()[i]._data().length; k < lenK; ++k)
            {
                //If it's not empty (first word), then add a slash to separate the next word
                if (ret != "")
                    ret += " / \n";
                
                //Add on the response    
                ret += obj.responses()[i]._data()[k].content();  
            }
        }
        
        //Return the final string
        return ret;
    }
    
    obj.selectbox_response.subscribe(function(newValue){//RS : reevaluate
        if(newValue.id)
        {
            if(newValue.id() || newValue._data()[0].content() == "Select..."){//hacky nasty bad robert
                obj.selected_response(newValue.id());
            }
        }
        else if (newValue > 0)//used for progress restoring
        {
            obj.selectbox_response(obj.responses()[newValue]);
        }
    });
    
    obj.maintain_responses_data = ko.computed(function(){
        if(obj.responses !== undefined){
            for (var i = 0, len = obj.responses().length; i < len; ++i){
                obj.responses()[i].id(i);
            }
        }
    });

    obj.get_template_columns = function(content_index) {
        var ret = 'col-md-12 col-sm-12 col-xs-12';
        if (typeof content_index === 'undefined')
            content_index = 0;
        if(obj._data()[0].contents()[content_index].type() == "image-md")
        {
            ret = 'col-md-8 col-sm-8 col-xs-8';
        }
        else if(obj._data()[0].contents()[content_index].type() == "image-sm")
        {
            ret = 'col-lg-3 col-md-4 col-sm-4 col-xs-5';
        }
        
        return ret;
    }
    obj.get_response_columns = function() {
        var col_width = 12/obj.responses().length;
        if (col_width < 3 && col_width > 2)
        {
            col_width = 3;
        }
        else if (col_width < 2)
        {
            col_width = 2;
        }
        var ret = 'col-md-'+col_width+' col-sm-'+col_width+' col-xs-'+col_width;        
        return ret;
    }

    obj.get_question_columns = function(element) {
        var col_width = 12/element.questions().length;
        var ret = 'col-md-'+col_width+' col-sm-'+col_width+' col-xs-'+col_width;        
        return ret;
    }
    
    if(is_editable)
    {
        product_edit_question_model(obj);
        edit_question_model(obj);
    }

    //specific for TYP: hence the identifier variable
    obj.check_entered_response = function(identifier){//RS : reevaluate        
        var loop_counter = 0;//because there is not one in ko.utils.foreach...
        var correct = false;
        ko.utils.arrayForEach(obj.responses(), function (item) {            
            if(typeof obj.entered_response() !== 'undefined' && obj.entered_response() != '')
            {
                entered_resp = obj.entered_response().replace(/\s*$/,"");

                if (typeof item._data !== 'undefined')
                {
                    resp = ko.utils.unwrapObservable(item._data()[0].content()).replace(/\s*$/,"");
                }
                else
                {
                    resp = ko.utils.unwrapObservable(item.text).replace(/\s*$/,"");
                }
                if(entered_resp.trim() == resp.trim())
                {
                    correct = true;
                    obj.selected_response(loop_counter);
                }
                else
                {
                    if(correct)
                    {
                        obj.responses()[0].selected(0);                                 
                    }
                    else
                    {
                        if(loop_counter)
                        {                            
                            obj.responses()[loop_counter].selected(0);
                        }
                        obj.selected_response(-1);
                        obj.selected_response(0);
                    }
                }
                ++loop_counter;
            }
            else
            {
                obj.select_response(ko.observable(-1));
            }
        });
    };
    
    obj.check_rec_response = function()
    {
        obj.select_response((obj.responses().length > 1 ? ko.observable(1) : ko.observable(0)));
        
        var type = viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].type();
        
        if (type == "GWR")
        {
            viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].enable_writing_button();
        }
    }
}

//Question level product functions
function product_show_answer(obj, type, ex_id, lab_id)
{
    if(type == "MFL")
    {
        ko.utils.arrayForEach(obj.responses(), function (item) {            
            if(item.correct()){
                obj.selectbox_response(item);
            }                
        });
    }
    else if (type == "MMM")
    {
        ko.utils.arrayForEach(obj.responses(), function (item) {            
            if(item.correct()){
                item.selected(1);
            }
            else
            {
                item.selected(0);
            }
        });
    }
    else if (type == "TAB" || type == "ELS")
    {
        ko.utils.arrayForEach(obj.responses(), function (item) {            
            if(item.correct()){
                item.selected(1);
            }
            else
            {
                item.selected(0);
            }
        });
    }
    else if (type == "TYP")
    {
        ko.utils.arrayForEach(obj.responses(), function (item) {            
            if(item.correct()){
                if(typeof item._data() !== 'undefined')
                {
                    obj.entered_response(item._data()[0].content());
                }
                else
                    obj.entered_response(item.text());
                    
                obj.check_entered_response('TYP');
            }
            else
            {
                item.selected(0);
            }
        });
    }
    else if (product_helper_is_drag_drop_type(type))
    {            
        ko.utils.arrayForEach(obj.responses(), function (item) {            
            if(item.correct()){
                obj.select_response(item.id);
                //show_drag_answer(ex_id,obj.id(),lab_id,type);
            }
            else
            {
                item.selected(0);
            }
        });
    }
    else
    {
        ko.utils.arrayForEach(obj.responses(), function (item) {            
            if(item.correct()){
                obj.select_response(ko.observable(""+item.id()));
            }                
        }); 
    }
}

function product_clear_question(obj)
{
    obj.selected_response(-1);
    ko.utils.arrayForEach(obj.responses(), function (item) {
        item.selected(0);
    });
    obj.selectbox_response(obj.responses()[0]);
    obj.entered_response("");
    obj.check_answer(0);
}

function product_response_model(obj){
    obj.playing_audio = ko.observable(false);

    if(is_editable)
    {
        edit_response_model(obj);
    }
    
    obj.has_data = ko.computed(function () {
        var ret = false;

        if (obj._data)
        {
            ret = true;
        }
        
        return ret;
    });
    
    obj.get_template_columns = function(content_index) {
        var ret = 'col-md-12 col-sm-12 col-xs-12';

        if(obj._data()[content_index].type() == "image-md")
            ret = 'col-md-8 col-sm-8 col-xs-8';
        else if(obj._data()[content_index].type() == "image-sm")
            ret = 'col-lg-3 col-md-4 col-sm-4 col-xs-5';
        
        return ret
    }
}

function product_value_model(obj){
    obj.set_value = ko.computed(function(){
        if(obj.content() && obj.type()){
            var str = '{"type": "'+obj.type()+'", "content": "'+obj.content()+'"}';
            obj.value(str);
        }
    });

    if(is_editable)
    {
        edit_value_model(obj);
    }
}

function product_table_model(obj){

    if(obj.cells().length == 0){
        cell = new value_model('');
        cell.type('text');
        cell.content('');
        obj.cells.push(cell);
    }
    if(obj.rows() == 0){
        obj.rows(1);
    }
    if(obj.columns() == 0){
        obj.columns(1);
    }

    obj.cols_array = ko.computed( function () {
        cols_array = [];
        for (var l = 0, len = obj.columns(); l < len; ++l){
            cols_array.push(l);
        }
        return cols_array;
    });


    obj.remove_row = function(i){
        for (var l = 0, len = obj.cols_array().length; l < len; ++l){
            obj.cells.remove(obj.cells()[i]);
        }
    }

    obj.add_row = function(){
        if(obj.rows() < 14){
            var rows = obj.rows();
            rows++;
            obj.rows(rows);

            for (var l = 0, len = obj.columns(); l < len; ++l){
                cell = new value_model('');
                cell.type('text');
                cell.content('');
                obj.cells.push(cell);
            }
        }
    }

    obj.remove_column = function(i){
        if(obj.columns() > 1){
            for (var l = 0, len = obj.cells().length; l <= len;){
                for (var c = 0, clen = obj.cols_array().length; c < clen; ++c){
                    if (c == i) {
                        obj.cells.remove(obj.cells()[l]);
                    }
                    else{
                        l++;
                    }
                }
            }
            var columns = obj.columns();
            columns--;
            obj.columns(columns);
        }

    }

    obj.add_column = function(){
        if(obj.columns() < 7){
            var adjust = 0;
            for (var l = 0, len = obj.cells().length; l <= len; ++l){
                if(l!=0 && l % obj.columns() == 0){
                    cell = new value_model('');
                    cell.type('text');
                    cell.content('');
                    obj.cells.splice(l+adjust, 0, cell);
                    adjust++;
                }
            }
            var columns = obj.columns();
            columns++;
            obj.columns(columns);
        }
    }

    obj.move_row_up = function(i){
        var cut = obj.cells.splice(i, obj.cols_array().length);
        for (var l = 0, len = obj.cols_array().length; l < len; ++l){
            obj.cells.splice(i - obj.cols_array().length + l, 0, cut[l]);
        }
    }

    obj.move_row_down = function(i){
        var cut = obj.cells.splice(i, obj.cols_array().length);
        for (var l = 0, len = obj.cols_array().length; l < len; ++l){
            obj.cells.splice(i + obj.cols_array().length + l, 0, cut[l]);
        }
    }
}

/*
===========================Product Core Functions============================
*/
function product_core_build_lesson_html(templates)
{   
    for(var i = 0; i < templates.length; ++i)
    {
        if(templates[i].exercise_templates.length > 0)
        {
            if (templates[i].exercise_templates)
                $('#'+templates[i].template.type+'_exercises').html(product_helper_build_exercise_html_block(templates[i].exercise_templates, templates[i].edit_templates));//deploy exercise templates    
            $('#'+templates[i].template.type+'_stimulus').html(product_helper_build_stimuli_html_block(templates[i].stimuli_templates, templates[i].stimuli_edit_templates));
            $('#'+templates[i].template.type+'_tss_stimulus').html(product_helper_build_stimuli_html_block(templates[i].stimuli_templates, templates[i].stimuli_edit_templates));
        }
        // else //single exercise template use 0 in place of second loop
        // {
            // if(templates[i].exercise_templates[0].template)
            // {
                // //fix to a allow one template for OED type
                // if(templates[i].exercise_templates[0].template.type == "oed") {
                    // templates[i].exercise_templates[0].template.type += ''+i;
                    // // insert edit template
                    // if(templates[i].edit_templates && templates[i].edit_templates.content){
                        // var reg_str1 = '<span class="edit_container_1"></span>';
                        // var reg_str2 = '<span class="edit_container_2"></span>';
                        // templates[i].exercise_templates[0].template.content = templates[i].exercise_templates[0].template.content.replace(reg_str1, templates[i].edit_templates.content);
                        // templates[i].exercise_templates[0].template.content = templates[i].exercise_templates[0].template.content.replace(reg_str2, templates[i].edit_templates.content);
                    // }
                // }
                // $('#'+templates[i].template.type+'_nav').html(templates[i].nav_template.content);
                // $('#'+templates[i].exercise_templates[0].template.type+'_exercise_'+0).html(templates[i].exercise_templates[0].template.content);
            // }
            // for(var k = 0; k < templates[i].stimuli_templates.length; ++k)
            // {
                // $('#'+templates[i].stimuli_templates[k].template.type+'_stimulus_'+k).html(templates[i].stimuli_templates[k].template.content);
            // }
        // }
        $('#'+templates[i].template.type+'_nav').html(templates[i].nav_template.content);
        $('#group_bar').html(templates[i].group_bar_template.content);
    }
    product_build_welcome_page();
}

function product_core_get_lab_templates(sco_json)
{   
    var t = new Array();
    for(var i = 0; i < sco_json.labs.length; ++i)
    {
        if( sco_json.labs[i].type == "oed" )
        {
            t[i] = ajax_get_lab_template(sco_json.labs[i].type+sco_json.labs[i].id, lms_config.product_type)            
            t[i]["exercise_templates"] = new Array();
            t[i]["exercise_templates"].push(new exercise_template(ajax_get_subtemplate(sco_json.labs[i].type, 'exercises', lms_config.product_type), helper_get_stimuli_templates(sco_json.labs[i].exercises[0].stimuli)));
            t[i]["edit_templates"] = ajax_get_subtemplate(sco_json.labs[i].type, 'exercises', lms_config.product_type, 'edit_1');
            t[i]["stimuli_templates"] = helper_get_stimuli_templates(sco_json.labs[i].stimuli);
            t[i]["nav_template"] = ajax_get_subtemplate(sco_json.labs[i].type, "nav", lms_config.product_type);
        }        
        else
        {
            
            t[i] = ajax_get_lab_template(sco_json.labs[i].type, lms_config.product_type);
            t[i]["exercise_templates"] = helper_get_subtemplates(sco_json.labs[i].type, sco_json.labs[i].exercises);
            t[i]["edit_templates"] = helper_get_subtemplates(sco_json.labs[i].type, sco_json.labs[i].exercises, 1);
            t[i]["nav_template"] = ajax_get_subtemplate(sco_json.labs[i].type, "nav", lms_config.product_type);                                 
            t[i]["stimuli_templates"] = helper_get_stimuli_templates(sco_json.labs[i].stimuli);
            t[i]["stimuli_edit_templates"] = helper_get_stimuli_templates(sco_json.labs[i].stimuli,1); 
            t[i]["group_bar_template"] = ajax_get_subtemplate(sco_json.labs[i].type, 'group_bar', lms_config.product_type);            
        }                                
    }
    return t;   
}


function product_core_start_lesson()
{
	// initialized = true;
    //log("initialized: "+initialized);
    //Get the exercise group counts to disable the correct radio buttons in the editor
    //Sets the observables in exercise_group_types
    viewModel.labs()[0].get_group_count();
    var starting_group = 0;
    if(viewModel.number_of_sco_groups() == 1)
    {        
        for(var i = 0, len = viewModel.exercise_group_types().length; i < len; ++i)
        {
            if(viewModel.exercise_group_types()[i].count() > 0)
            {
                starting_group = i;
            }
        }
    }
	
	if (viewModel.number_of_sco_groups() > 1) // don't report objects for single dr's
		viewModel.map_objectives_to_group();
    //check for progress
    if(initialized)
    {
        if(typeof SCORE_CAN_ONLY_IMPROVE != "undefined"){
            SCORE_CAN_ONLY_IMPROVE = true;
        }
        //get progress via scorm methods
        viewModel.progress(scorm_progress_obj);
        if(viewModel.progress()){
            viewModel.restoring_progress(true);
            product_print_scorm_data();
            product_load_scorm_progress();
            viewModel.restore_progress();
            viewModel.restoring_progress(false);
            //product_load_scorm_progress();
        }
        else{
            product_first_load_scorm_actions();
            viewModel.select_lab(0);
            viewModel.started_writing_task(0);
            viewModel.labs()[viewModel.selected_lab()].change_group(starting_group);
            race_condition_ended = true;
        }
    }
    else
    {
        //get progress from progress obj
        if(!helper_restore_progress())
        {
            viewModel.select_lab(0);
            viewModel.started_writing_task(0);
            viewModel.labs()[viewModel.selected_lab()].change_group(starting_group);
            race_condition_ended = true;
        }        
    }

    sena_core_set_event_listeners();
    viewModel.on_welcome_page(0);
    product_helper_update_container_height();
    helper_create_scrollbar();
    product_helper_adjust_single_drop_positions();

    //Disable the lab selector if it is not needed
    if (viewModel.type() != "writing")
    {
        $('#lab_selector').hide();
    }

    //viewModel.labs()[viewModel.selected_lab()].change_group(viewModel.labs()[viewModel.selected_lab()].selected_group());
    
    viewModel.use_slide_transition(true); // TK: none user switches should be done at this point.
    //viewModel.labs()[viewModel.selected_lab()].change_group(0);
    sfx_player('navigate-begin');
    
    //doing hackey stuff for testing
    //check count of at least two groups welcome and content
    // if either is 0 single dr
}

function product_core_grade_LO(group) //group is the string name of the group, ie 'Quiz'
{   
    var group_scores = 0;
    var group_exercise_count = 0;
    for (var i = 0, len = viewModel.labs()[0].exercises().length; i < len; ++i)
    {
        if(viewModel.labs()[0].exercises()[i].type()!="RSLT"){ //don't count the rslt page as an exercise
            for(var k = 0, k_len = viewModel.labs()[0].exercises()[i]._data().length; k < k_len; ++k)
            {
                if( viewModel.labs()[0].exercises()[i]._data()[k].type() == "group" ) 
                {
                    for(var w = 0, w_len = viewModel.labs()[0].exercises()[i]._data()[k].contents().length; w < w_len; ++w)
                    {
                        if(viewModel.labs()[0].exercises()[i]._data()[k].contents()[w].type() == "group_name" && viewModel.labs()[0].exercises()[i]._data()[k].contents()[w].content() == group)
                        {
                            group_scores += viewModel.labs()[0].exercises()[i].score();
                            ++group_exercise_count;
                        }
                    }
                }
            }
        }
    }
    return (group_scores + 0.0) / (group_exercise_count + 0.0);
}

/*
===========================Product Helper Functions============================
*/

function product_helper_build_lab_html_block(templates)
{
    var html_output = '';

    for(var i = 0; i < templates.length; ++i)
    {       
        html_output += '<div data-bind="visible: selected_lab() == '+i+', with: labs()['+i+']">';
        html_output += templates[i].template.content;
        html_output += '</div>';
    }
    return html_output;
}

function product_helper_build_exercise_html_block(exercise_templates, edit_templates)
{
    var html_output = '';
    for(var i = 0; i < exercise_templates.length; ++i)
    {
        // insert edit template
        if(edit_templates.length && edit_templates[i].template.content){
            var reg_str = '<span class="edit_container"></span>';
            exercise_templates[i].template.content = exercise_templates[i].template.content.replace(reg_str, edit_templates[i].template.content);
        }
        html_output += '<div data-bind="visible: selected_exercise() == '+i+', with: exercises()['+i+']">'
        html_output += exercise_templates[i].template.content;
        html_output += '</div>';
    }
    return html_output;
}

function product_helper_build_stimuli_html_block(stimuli_templates, stimuli_edit_templates)
{
    var html_output = '';

    for(var i = 0; i < stimuli_templates.length; ++i)
    {
        // insert edit template
        if(stimuli_edit_templates.length && stimuli_edit_templates[i].template.content){
            var reg_str = '<span class="edit_container"></span>';
            stimuli_templates[i].template.content = stimuli_templates[i].template.content.replace(reg_str, stimuli_edit_templates[i].template.content);
        }
        // here u are u sneaky div
        html_output += '<div class="exercise-padding" data-bind="visible: selected_stimuli() =='+i+', with: stimuli()['+i+']">'
        html_output += stimuli_templates[i].template.content;
        html_output += '</div>';
    }
    return html_output;
}

function product_build_welcome_page () { // readies wlc for flipping
    var welcome_div = $('.wlc-top-wrapper');
    if (welcome_div.length) {
        welcome_div.parent().detach().appendTo('.wlc-html');
    } else { // there is no wlc, flip to back immediately
        $('.flipper').addClass('flip');
    }
}

function product_helper_update_container_height()
{
    viewModel.windowHeight(window.innerHeight);
    viewModel.windowWidth(window.innerWidth);
    //Check to see if the current exercise is a dragdrop type
    if (product_helper_is_drag_drop_type(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].type()))
    {
        viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].dragdrop.response_container().width($('.exercises').width() - 20);
    }
            
    viewModel.welcome_page_height(product_helper_get_welcome_page_height());
    
    viewModel.labs()[viewModel.selected_lab()].container_height(product_helper_get_lab_container_height(viewModel.labs()[viewModel.selected_lab()]._data.has_nav(), viewModel.labs()[viewModel.selected_lab()]._data.has_exercise_controls(), viewModel.selected_lab(), viewModel.labs()[viewModel.selected_lab()].type()));    
    
    //Increase page height when there is no nav bar on the welcome page in achievement test and on lab 0 in a writing sco
    if (viewModel._data.test() == 'true' &&  viewModel.labs()[viewModel.selected_lab()].selected_exercise() == 0 || viewModel.type() == "writing" && viewModel.selected_lab() == 0)
        viewModel.labs()[viewModel.selected_lab()].container_height( viewModel.labs()[viewModel.selected_lab()].container_height() + 52);
    
    if(helper_get_current_excercise_type() != "SFL")
    {
        viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].drag_drop_container_width(product_helper_get_drag_drop_container_width(viewModel.labs()[viewModel.selected_lab()].type()));        
    }
    if(helper_get_current_excercise_type() == "MCH")
    {
        viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].resize_cells();        
    }
}

function product_helper_get_lab_container_height(nav,controls,lab_id, type)//this does alot more than lab container height
{
    //get client window height
    var inner_height = $('#framework_exercise').outerHeight();
    var controls_height = 1;
    
    if ($('#lab_selector').outerHeight() == 1)
        controls_height = 0;
    controls_height += ($('#lab_selector').outerHeight()) ? $('#lab_selector').outerHeight() : 0;
    //if($('#scholar_nav')){
    //controls_height += ($('#scholar_nav').outerHeight()) ? $('#scholar_nav').outerHeight() : 0; 
    //}  
    controls_height += ($('#exercise_controls_'+lab_id).outerHeight()) ? $('#exercise_controls_'+lab_id).outerHeight() : 0;
    //controls_height += ($('#exercise_controls_'+lab_id).outerHeight() < 85) ? $('#exercise_controls_'+lab_id).outerHeight() : 0;
    controls_height+= 45; //exercise container padding
    
    return inner_height - controls_height;
    //assume range .7 - .8 is 4:3 .5 - .6 is 16:9
}

function product_helper_get_welcome_page_height()
{
    return window.innerHeight - 60;
}

function product_helper_get_drag_drop_container_width(type)
{
    var inner_width = window.innerWidth;
    
    if(inner_width > 1330)//set in css
    {  
        inner_width = 1280;
    }
    
    return (inner_width - 115);        

}

function product_helper_adjust_single_drop_positions()
{
    if ( viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].type() == "SPK" )
    {
        product_helper_calculate_spk_drag_area(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()])
    }
    if(typeof viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].dragdrop !== 'undefined')
    {
        adjust_drag_item_positions(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].dragdrop);
    }    
}

//Checks to see if the exercise type is part of drag_drop.
//@type = the exercise type
function product_helper_is_drag_drop_type(type)
{
    //Check if type is any of the drag drop types
    if(type == "SFL" || type == "MT1"|| type == "DFL" || type == "SFG" || type == "MF1" || type == "WSB" || type == "SPK")
        return true;
        
    return false;
}

//Sets the config numbers for the drag drop type.
function product_helper_build_drag_drop_config(type)
{
    var ret = undefined;
    
    //dragdrop objects
    //@response_container_type: 1 = right side, 2 = fixed bottom, 3 = hidden
    //@starting_position_type: 1 = stacked, 2 = grid, 3 = randomized
    //@drop_type: 1 = standard drop, 2 = prepare for position switch
    //@double_drop_type: 1 = kick dropped item back to response container, 2 = switch item position
    //@drag_item_adjust_type: 1 = single item - single container, 2 = multiple items - single container
    //@state_calc_type: 1 = Uses select_response, 2 = Uses responses.selected
    //@revert_type: 1 = Kick back to response container, 2 = return to drop region
    if (type == "SFL")
    {
        ret = new drag_drop_config(9,9,1,8,11,1,9);
    }
    else if (type == "MT1")
    {
        ret = new drag_drop_config(3,3,2,2,10,1,2);
    }
    else if (type == "DFL")
    {
        ret = new drag_drop_config(9,9,1,3,5,2,9);
    }
    else if (type == "SFG")
    {
        ret = new drag_drop_config(1,1,1,1,1,2,1);
    }
    else if (type == "MF1")
    {
        ret = new drag_drop_config(5,5,1,1,1,5,5);
    }
    else if (type == "SPK")
    {        
        ret = new drag_drop_config(6,6,6,6,8,6,8);    
    }
    else if (type == "WSB")
    {
        ret = new drag_drop_config(7,3,7,7,2,7,2);
    }    
    return ret;
}

//Shuffles the drag drop responses.
//@array = the array of responses
function product_helper_array_shuffle(array)
{
    var currentIndex = array.length
    , temporaryValue
    , randomIndex
    ;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {

        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;

        // And swap it with the current element.
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }
    
    return array;
}

//Returns a string without the file extension.
//@item = The string with the file extension in it to be removed.
function product_helper_remove_extension(item)
{
    //Split the string at the start of the file extension
    var ret = item.split(".");
    //Return the first half of the string that doesn't contain the extension
    return ret[0];
}

//Adds function to the Date variable type.
//Converts the current time to a formatted string.
Date.prototype.toTime = function() {
    return formatTime(this.getHours()) + ":" + formatTime(this.getMinutes()) + ":" + formatTime(this.getSeconds());
}

//Formats a number to always have 2 digits. If number is less then 10
//it will have a leading 0.
function formatTime(n){
    return n > 9 ? "" + n: "0" + n;
}

function product_helper_get_drag_drop_progress(obj)
{    
    var tmp_str = '';
    for (var i = 0, len = obj.labs().length; i < len; ++i)
    {
        for (var w = 0, tmp_len = obj.labs()[i].exercises().length; w < tmp_len; ++w)
        {
            if(product_helper_is_drag_drop_type(obj.labs()[i].exercises()[w].type()))
            {                                
                tmp_str += obj.labs()[i].exercises()[w].dragdrop.get_progress_str(i,w);                
            }
        }
    }
    return tmp_str;
}

function product_helper_restore_drag_drop_progress(progress_obj, obj)
{
    var dragdrop_progress = progress_obj.split(',');
    var current_exercise = -1;
    var current_lab = -1;
    var exe_progress_strings = new Array();
    var exercise_numbers = new Array();
    var tmp_str = '';
    
    for (var w = 0; w < dragdrop_progress.length; ++w)
    {   
        if(typeof dragdrop_progress[w] === 'undefined' || dragdrop_progress[w] == ''){continue;}
        var progress_data = dragdrop_progress[w].match( /l(\d+)e(\d+)q(\d+)r(\d+)\|q(\d+)/i );
        if (progress_data === null) {continue; }
        if(w != 0 && current_exercise != -1)
        {
            var tmp_ex_num = parseInt(progress_data[2]);
            var tmp_lab_num = parseInt(progress_data[1]);
            if(current_exercise == tmp_ex_num && current_lab == tmp_lab_num)
            {
                
            }
            else
            {
                obj.select_lab(current_lab);
                obj.labs()[current_lab].select_exercise(current_exercise);
                obj.labs()[current_lab].exercises()[current_exercise].dragdrop.restore_progress(tmp_str);
                // exercise_numbers.push(parseInt(progress_data[2]));
                if(tmp_str != '')
                {
                   // exe_progress_strings.push(tmp_str);
                    tmp_str = '';
                }              
            }         
        }        
        current_exercise = parseInt(progress_data[2]);        
        current_lab = parseInt(progress_data[1]);        
        tmp_str += dragdrop_progress[w] + ',';
        // viewModel.select_lab(parseInt(progress_data[1]));
        // viewModel.labs()[viewModel.selected_lab()].select_exercise(parseInt(progress_data[2]));//ex must be showing               
        // var type = viewModel.labs()[progress_data[1]].exercises()[progress_data[2]].type();
    }
    
    if(current_lab != -1)
    {
        obj.select_lab(current_lab);
        obj.labs()[current_lab].select_exercise(current_exercise);
        obj.labs()[current_lab].exercises()[current_exercise].dragdrop.restore_progress(tmp_str);
    }
}

function product_helper_fire_resize_events()
{
    product_helper_update_container_height();
    product_helper_adjust_single_drop_positions();
}

//obj = exercise
function product_helper_set_question_scorm_info(obj)
{
    for(var i = 0; i<obj.questions().length;++i){
        var scorm_type_temp = "";
        for(var j = 0; j<lesson_config_json.exercise_scorm_types.length; ++j){
            //console.log(lesson_config_json.exercise_scorm_types[j].exercise_type + ' and ' + obj.type());
            if(lesson_config_json.exercise_scorm_types[j].exercise_type == obj.type()){
                scorm_type_temp = lesson_config_json.exercise_scorm_types[j].scorm_type;
                break;
            }
        }

        var is_rec = false;        
        for(var j = 0; j<obj.questions()[i]._data().length; ++j){
            if(obj.questions()[i]._data()[j].type()=="question"){
                for(var k = 0; k<obj.questions()[i]._data()[j].contents().length;++k){
                    //console.log(obj.questions()[i]._data()[j].contents()[k].type()+', '+ obj.questions()[i]._data()[j].contents()[k].content());
                    if(obj.questions()[i]._data()[j].contents()[k].type()=="rec"){
                        is_rec = true;
                    }
                }
            }
        }
        //obj.questions()[i].scorm_type = ko.observable(scorm_type_temp);
        obj.questions()[i].scorm_info().type(scorm_type_temp);

        var scorm_description_temp = "";
        var scorm_description_other = "";
        var scorm_description_text = "";
        var scorm_description_post_text = "";

        var scorm_correct_ans_temp = "";

        if(!is_rec){
            //Get question description
            if(obj.type() == "WSB"){
                scorm_description_temp = obj.questions()[i].responses()[0]._data()[0].content(); //Yucky hard-coded 0's
            }
            else if(obj.type() == "SPK" || obj.type() == "FLC" || obj.type() == "MCH" || obj.type()=="HNG"){
                for(var j = 0; j<obj._data().length;++j){
                    if(obj._data()[j].type() == "instructions"){
                        for(var k = 0; k<obj._data()[j].contents().length; ++k){
                            if(obj._data()[j].contents()[k].type() == "text"){
                                scorm_description_temp += obj._data()[j].contents()[k].content();
                            }
                        }  
                    }
                }
                for(var j = 0; j<obj._data().length;++j){
                    if(obj._data()[j].type() == "post_instructions"){
                        for(var k = 0; k<obj._data()[j].contents().length; ++k){
                            if(obj._data()[j].contents()[k].type() == "text"){
                                scorm_description_temp += obj._data()[j].contents()[k].content();
                            }
                        }  
                    }
                }
            }
            else{
                for(var j = 0; j<obj.questions()[i]._data().length; ++j){
                    if(obj.questions()[i]._data()[j].type()=="question"){
                        for(var k = 0; k<obj.questions()[i]._data()[j].contents().length;++k){
                            if(obj.questions()[i]._data()[j].contents()[k].type()=="audio" || obj.questions()[i]._data()[j].contents()[k].type().match(/image/) || obj.questions()[i]._data()[j].contents()[k].type()=="video" || obj.questions()[i]._data()[j].contents()[k].type()=="pdf"){
                                scorm_description_other += obj.questions()[i]._data()[j].contents()[k].content() + ' ';
                            }
                            else if(obj.questions()[i]._data()[j].contents()[k].type()=="text"){
                                scorm_description_text += obj.questions()[i]._data()[j].contents()[k].content() + ' ';
                            }
                        }
                    }
                    else if(obj.questions()[i]._data()[j].type()=="post_question"){
                        scorm_description_post_text += obj.questions()[i]._data()[j].contents.content() + ' ';
                    }
                    else if(obj.questions()[i]._data()[j].type()=="flash_card"){
                        scorm_description_other = obj.questions()[i]._data()[j].contents()[0].name(); //yucky hard coded 0
                    }    
                }
                if(scorm_description_post_text){
                    scorm_description_temp += scorm_description_other + scorm_description_text + '___ ' + scorm_description_post_text;
                }
                else{
                    scorm_description_temp += scorm_description_other + scorm_description_text;
                }
            }
            
            //Get question correct answer
            for(var j = 0; j<obj.questions()[i].responses().length; ++j){
                if(obj.type()=="GWR"){
                    scorm_correct_ans_temp = "any response is correct";
                }
                else if(obj.questions()[i].responses()[j].correct()){
                    for(var k = 0; k<obj.questions()[i].responses()[j]._data().length; ++k){
                        if(obj.type()=="SPK"){
                            scorm_correct_ans_temp += obj.questions()[i].responses()[j]._data()[k].content()[0].content.data() + ', ';
                            scorm_correct_ans_temp += obj.questions()[i].responses()[j]._data()[k].content()[1].content.data() + ' | ';
                        }
                        else if(obj.type()=="TAB"){
                            scorm_correct_ans_temp += obj.questions()[0].responses()[j]._data()[k].content() + ' ';
                        }
                        else if(obj.type() == "FLC"){
                            scorm_correct_ans_temp += "student flipped card";
                        }
                        else if(obj.type() == "HNG"){
                            if(obj.questions()[i].responses()[j]._data()[k].type() == "text"){
                                scorm_correct_ans_temp += obj.questions()[i].responses()[j]._data()[k].content();
                            }
                        }
                        else{
                            scorm_correct_ans_temp += obj.questions()[i].responses()[j]._data()[k].content() + ' ';
                        }
                    }   
                }
                else if(obj.type()=="MCH"){
                    for(var k = 0; k<obj.questions()[i].responses()[j]._data().length; ++k){
                        if(j==(obj.questions()[i].responses().length-1)){
                            scorm_correct_ans_temp += obj.questions()[i].responses()[j]._data()[k].content();
                        }
                        else{
                            scorm_correct_ans_temp += obj.questions()[i].responses()[j]._data()[k].content()+', ';
                        }
                    }
                }
            }
        }
        else{
            scorm_correct_ans_temp = "student recorded";
            scorm_description_temp = "recording";
            obj.questions()[i].scorm_info().type("performance");
        }

        scorm_correct_ans_temp = scorm_correct_ans_temp.replace(/\s/g, "_");
        
        //obj.questions()[i].scorm_description = ko.observable(scorm_description_temp);        
        obj.questions()[i].scorm_info().description(scorm_description_temp); 
        //obj.questions()[i].scorm_correct_ans = ko.observable(scorm_correct_ans_temp);
        obj.questions()[i].scorm_info().correct_ans(scorm_correct_ans_temp);
        //console.log("ex:"+obj.type()+", q:"+i+", type:"+obj.questions()[i].scorm_info().type()+", desc:"+obj.questions()[i].scorm_info().description()+", correct_ans:"+obj.questions()[i].scorm_info().correct_ans());
        //console.log("ex:"+obj.type()+", q:"+i+", type:"+obj.questions()[i].scorm_type()+", desc:"+obj.questions()[i].scorm_description()+", correct_ans:"+obj.questions()[i].scorm_correct_ans());
    }
}

function product_helper_get_question_scorm_info(obj, i, w, k){
    var id = 'l'+i+'e'+w+'q'+k;
    var user_ans = "";
    var result = "";

    var is_rec = false;        
    for(var m = 0; m<obj.questions()[k]._data().length; ++m){
        if(obj.questions()[k]._data()[m].type()=="question"){
            for(var n = 0; n<obj.questions()[k]._data()[m].contents().length;++n){
                if(obj.questions()[k]._data()[m].contents()[n].type()=="rec"){
                    is_rec = true;
                }
            }
        }
    }                   
    if(obj.questions()[k].state()==4){
        result = "correct";
    }
    else if(obj.questions()[k].state()==2 || obj.questions()[k].state()==3){
        result = "incorrect";
    }
    else if(obj.questions()[k].state() == 0){
        result = "not attempted";
    }
    else{
        result = "in progress";
    }
        
    if(is_rec){
        if(obj.questions()[k].state()>0){
            user_ans = "student recorded"
        }
    }
    else{
        if(!product_helper_is_drag_drop_type(obj.type())){
            if(obj.type()=="TYP" || obj.type() == "GIW"){
                if(obj.questions()[k].entered_response()){
                    user_ans = obj.questions()[k].entered_response();
                }
            }
            else if(obj.type() == "CWD"){
                user_ans = obj.questions()[k].cwd_entered_response();    
            }
            else if(obj.type()=="TAB"){ //only look for response data from the first question since it's the only one that has any
                for(var m = 0; m<obj.questions()[k].responses().length; ++m){
                    if(obj.questions()[k].responses()[m].selected()){
                        for(var n = 0; n<obj.questions()[0].responses()[m]._data().length; ++n){
                            user_ans += obj.questions()[0].responses()[m]._data()[n].content() + ' ';
                        }
                    }
                }
            }
            else if(obj.type()=="FLC"){
                if(obj.questions()[k].state()>0){
                    user_ans += "student flipped card";
                }   
            }
            else if(obj.type()=="MCH"){
                var selected_check = false;
                for(var m = 0; m<obj.questions()[k].responses().length; ++m){
                    if(obj.questions()[k].responses()[m].selected()){
                        selected_check = true;
                    }
                }
                if(selected_check){
                    for(var m = 0; m<obj.questions()[k].responses().length; ++m){
                        for(var n = 0; n<obj.questions()[k].responses()[m]._data().length; ++n){
                            if(m==(obj.questions()[k].responses().length-1)){
                                user_ans += obj.questions()[k].responses()[m]._data()[n].content();
                            }
                            else{
                                user_ans += obj.questions()[k].responses()[m]._data()[n].content() + ', ';
                            }
                        }
                    } 
                }   
            }
            else if(obj.type()=="HNG"){
                user_ans += obj.questions()[k].word();
                user_ans = user_ans.replace(/\s/g, '');
                var progress_check = user_ans.replace(/_/g, '');
                if(progress_check && !(obj.questions()[k].state()==4 || obj.questions()[k].state() ==2)){
                    result = "in progress";
                }
            }
            else if(obj.type()=="TTT"){
                for(var m = 0; m<obj.questions()[k].responses().length; ++m){
                    if(obj.questions()[k].responses()[m].selected()){
                        for(var n = 0; n<obj.questions()[k].responses()[m]._data().length; ++n){
                            user_ans += obj.questions()[k].responses()[m]._data()[n].content();  
                        }  
                    }
                }
                if(obj.questions()[k].state()>0 && user_ans == ""){
                    user_ans = "wrong cell selected";
                }
            }
            else{
                for(var m = 0; m<obj.questions()[k].responses().length; ++m){
                    if(obj.questions()[k].responses()[m].selected()){
                        for(var n = 0; n<obj.questions()[k].responses()[m]._data().length; ++n){
                            user_ans += obj.questions()[k].responses()[m]._data()[n].content() + ' ';  
                        }  
                    }
                }
            }
        }
        else if(obj.type()=="WSB"){
            user_ans = product_helper_get_WSB_user_ans(obj, k)[0];
            if(product_helper_get_WSB_user_ans(obj, k)[1] && !(obj.questions()[k].state()== 4 || obj.questions()[k].state()== 2)){
                result = "in progress";
            }
        }
        else if(obj.type() == "MT1"){
            //console.log("q:"+k+", state:"+obj.questions()[k].state());
            if(obj.questions()[k].state() != 4){
                user_ans += product_helper_get_MT1_user_ans(obj, k);
            }
            else if(obj.questions()[k].state() > 0){
                for(var m = 0; m<obj.questions()[k].responses().length; ++m){
                    if(obj.questions()[k].responses()[m].selected()){
                        for(var n = 0; n<obj.questions()[k].responses()[m]._data().length; ++n){
                            user_ans += obj.questions()[k].responses()[m]._data()[n].content() + ' ';
                        }   
                    }
                }
            }
        }
        else if(obj.type() == "SPK"){
            if(obj.questions()[k].state()>0){
                for(var m = 0; m<obj.questions()[k].responses().length; ++m){
                    for(var n = 0; n<obj.questions()[k].responses()[m]._data().length; ++n){
                        user_ans += obj.questions()[k].responses()[m]._data()[n].content()[0].content.data() + ', ';
                        user_ans += obj.questions()[k].responses()[m]._data()[n].content()[1].content.data() + ' | ';
                    }
                }
            }   
        }
        else if(obj.type() == "DFL" || obj.type() == "SFL"){
            user_ans += product_helper_get_DFL_user_ans(obj, k);
            //console.log("DLF q: "+ k+ ", state: "+obj.questions()[k].state());
        }
        else if(obj.type() == "MF1"){
            user_ans += product_helper_get_MF1_user_ans(obj, k);
        }
    }
    
    // if(obj.questions()[k].state()==3){
    //     for(var r = 1; r<obj.questions()[k].responses().length; ++r){
    //         var temp_match_str = obj.questions()[k].responses()[r]._data()[0].content();
    //         if(user_ans.search(temp_match_str)== -1){
    //             result = "incorrect";
    //             break;
    //         }
    //         else{
    //             result = "correct";
    //         }
    //     }
    // }

    // else if(obj.type() == "SPK" && obj.started())
    // {
    //     for(var k = 0, k_len = obj.attempt_times().length; k < k_len; ++k)
    //     {
    //         user_ans +=obj.attempt_times()[k];
    //     }
    // }
    //console.log(obj.type());
    //console.log(k);
    //console.log(obj.questions()[k].scorm_info());

    user_ans = user_ans.replace(/\s/g, "_");

    obj.questions()[k].scorm_info().user_ans(user_ans);
    obj.questions()[k].scorm_info().id(id);        
    obj.questions()[k].scorm_info().result(result);
    //console.log("ex:"+obj.type()+", q:"+k+", type:"+obj.questions()[k].scorm_info().type()+", desc:"+obj.questions()[k].scorm_info().description()+", correct_ans:"+obj.questions()[k].scorm_info().correct_ans());
    //console.log("id:"+id+", user_ans:"+user_ans+", result:"+result);
}

function product_helper_get_WSB_user_ans(obj, question_num){ //WSB's drop id's and response nums are super hectic, so needed this mess to find the user's response
    var user_ans = "";
    var no_response = true;
    var total_ex_responses = 0;
    var corrected_drop_id = 0;
    var progress = false;
    for(var i = 0; i<question_num; ++i){
        total_ex_responses += obj.questions()[i].responses().length-1; //-1 because the first response is the answer
    }
    for(var j=1;j<obj.questions()[question_num].responses().length;++j){
        for(var k=0; k<obj.dragdrop.pep_objs().length;++k){
            if(obj.dragdrop.pep_objs()[k].dropped()){
                //console.log("q " + i +" pep id " +obj.dragdrop.pep_objs()[k].pep()[0].id + " r " + j + " response num " + obj.dragdrop.pep_objs()[k].response_num()+" drop region " + obj.dragdrop.pep_objs()[k].drop_region()[0].id + " correct drop region " + obj.dragdrop.pep_objs()[k].correct_drop_region());
                if(obj.dragdrop.pep_objs()[k].drop_region()[0].id==(j+obj.questions()[question_num].responses().length-1) && obj.dragdrop.pep_objs()[k].pep()[0].id == question_num){                        
                    //console.log(obj.dragdrop.pep_objs()[k].response_num()-total_ex_responses);
                    user_ans += obj.questions()[i].responses()[obj.dragdrop.pep_objs()[k].response_num()-total_ex_responses]._data()[0].content() + " ";
                    no_response = false;
                    progress = true;
                    break;
                }
            } 
        }
        if(no_response){
            user_ans += "___ ";
        }
        no_response = true;
    }
    return [user_ans, progress];
}

function product_helper_get_MT1_user_ans(obj, question_num){
    var user_ans = "";
    for(var k=0; k<obj.dragdrop.pep_objs().length;++k){
        if(obj.dragdrop.pep_objs()[k].drop_region()[0].id == question_num){
            for(var m = 0; m<obj.questions()[obj.dragdrop.pep_objs()[k].pep()[0].id].responses().length; ++m){
                if(obj.questions()[obj.dragdrop.pep_objs()[k].pep()[0].id].responses()[m].correct()){
                    user_ans += obj.questions()[obj.dragdrop.pep_objs()[k].pep()[0].id].responses()[m]._data()[0].content(); //yucky hard coded 0
                }
            }
            break;                          
        } 
    }
    return user_ans;
}

function product_helper_get_DFL_user_ans(obj, question_num){
    var user_ans = "";
    for(var k=0; k<obj.dragdrop.pep_objs().length;++k){
        if(obj.dragdrop.pep_objs()[k].dropped() && obj.dragdrop.pep_objs()[k].drop_region()[0].id == question_num){
            user_ans += obj.questions()[obj.dragdrop.pep_objs()[k].correct_drop_region()].responses()[obj.dragdrop.pep_objs()[k].response_num()]._data()[0].content() + ' ';                       
        } 
    }
    return user_ans;
}

function product_helper_get_MF1_user_ans(obj, question_num){
    var user_ans = "";
    for(var k=0; k<obj.dragdrop.pep_objs().length;++k){
        if(obj.dragdrop.pep_objs()[k].dropped() && obj.dragdrop.pep_objs()[k].drop_region()[0].id == question_num){
            user_ans += obj.questions()[obj.dragdrop.pep_objs()[k].drop_region()[0].id].responses()[obj.dragdrop.pep_objs()[k].response_num()]._data()[0].content() + ' ';                       
        } 
    }
    return user_ans;
}

//assing in the div element the audio is contained in will play that audio
//calling play_audio() with nothing passed in will pause all audios not in the stimuli
function play_audio(value)
{
    var audios = $('.audio_player');
    var playing_audio = $('.playing_audio');
    var stim_audio = $('.stim_audio');
    
    if(typeof value != "undefined"){
        if(value.children[0].paused == true)
        {
            for (var l = 0; l < stim_audio.length; ++l)
            {
                if(typeof stim_audio[l].pause == "function")
                {
                    stim_audio[l].pause();
                }
            }
            for (var l = 0; l < audios.length; ++l)
            {
                audios[l].pause();
            }
            if (playing_audio.length)
            {
                playing_audio[0].children[1].className = playing_audio[0].children[1].className.replace( /(?:^|\s)glyphicon-stop(?!\S)/g , ' glyphicon-play' );
                playing_audio[0].className = playing_audio[0].className.replace( /(?:^|\s)playing_audio(?!\S)/g , ' paused_audio' );    
            }

            value.children[0].load();
			console.log('about to play audio');
            value.children[0].play();

            value.children[1].className = value.children[1].className.replace( /(?:^|\s)glyphicon-play(?!\S)/g , ' glyphicon-stop' );
            value.className = value.className.replace( /(?:^|\s)paused_audio(?!\S)/g , ' playing_audio' );
            $(value.children[0]).bind("ended", function() {
                value.children[1].className = value.children[1].className.replace( /(?:^|\s)glyphicon-stop(?!\S)/g , ' glyphicon-play' );
                value.className = value.className.replace( /(?:^|\s)playing_audio(?!\S)/g , ' paused_audio' );
                $(value.children[0]).unbind("ended");
            });
        }
        else
        {
            for (var l = 0; l < audios.length; ++l)
            {
                audios[l].pause();
            }
            value.children[1].className = value.children[1].className.replace( /(?:^|\s)glyphicon-stop(?!\S)/g , ' glyphicon-play' );
            value.className = value.className.replace( /(?:^|\s)playing_audio(?!\S)/g , ' paused_audio' );     
        }
    }
    else
    {
        for (var l = 0; l < audios.length; ++l)
        {
            audios[l].pause();
        }
        if (playing_audio.length)
        {
            playing_audio[0].children[1].className = playing_audio[0].children[1].className.replace( /(?:^|\s)glyphicon-stop(?!\S)/g , ' glyphicon-play' );
            playing_audio[0].className = playing_audio[0].className.replace( /(?:^|\s)playing_audio(?!\S)/g , ' paused_audio' );      
        }
    }
}

function sfx_player(audio_file){
    if(viewModel.sfx_on()){
        var sfx_player = document.getElementById('sfx_player');
        var source= document.createElement('source');
        if (sfx_player.canPlayType('audio/mpeg;')) {
            source.type= 'audio/mpeg';
            source.src= 'assets/sena/sounds/'+audio_file+'.mp3';
        } else {
            source.type= 'audio/ogg';
            source.src= 'assets/sena/sounds/'+audio_file+'.ogg';
        }
        while (sfx_player.firstChild) {
            sfx_player.removeChild(sfx_player.firstChild);
        }
        sfx_player.appendChild(source);
        sfx_player.load();
        sfx_player.play();
    }
}

function sena_core_set_event_listeners()
{
    $('.modal').on('shown.bs.modal', function () {
        product_helper_fire_resize_events()
    });
    $('#myTargetWordsModal').on('hidden.bs.modal', function () {
        play_audio();
    });

    if ('ontouchstart' in document.documentElement == false) {    
        $('[data-toggle="tooltip"]').tooltip();
    }

    $('#myTargetWordsModal').on('shown.bs.modal', function () {
        sfx_player('navigate-modal');
    });

    $('#learning-point').on('shown.bs.modal', function () {
        sfx_player('navigate-modal');
    });

     $('#feedback-modal').on('shown.bs.modal', function () {
        if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].state() == 1 &&
            viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].showing_answer()){
            sfx_player('attempt-fail');
        }
        else if(viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].state() == 2 &&
                !viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()].showing_answer()){
            sfx_player('attempt-try-again');
        }
        else{
            sfx_player('attempt-success');
        }
    });

    // document.body.onmousedown = function(){sfx_player('control-down');}
}


function sena_slide_switch (obj, value) {

    obj.adjust_video_container();

    var cur_grp, tar_grp, from, to;
    cur_grp = obj.previous_group();
    tar_grp = obj.selected_group();
    obj.is_sliding(true);
    // direction needs to check current group first,
    // if going to the same group, then compare ex number
    
    if (cur_grp === tar_grp) {
        // we are in the same grp, check ex index instead
        from = obj.selected_exercise();
        to = value;
    } else {
        // we are changing grps, check the grp indices
        from = cur_grp;
        to = tar_grp;
    }
    
    var viewport_width = $(window).width();
    var wrapper = $('.stim_ex_wrapper');
    var direction = from - to > 0 ? viewport_width : viewport_width * -1;
    var opp = direction * -1;
    wrapper.one('transitionend', function () { // bind first
        wrapper.css('visibility', 'hidden');
        wrapper.addClass('no_transition');
        // none transition move. callback to init ex once done moving and visible
        wrapper.animate({left: opp}, 100, function () { // this should match the speed in css transition.
            wrapper.css('visibility', 'visible');
            wrapper.removeClass('no_transition');
            wrapper.animate({left: '0px'}, 100, function () {
                product_post_ex_switch(obj, value);
                $('.response_container').css({ // temp fix to get dd response container to show up
                    'left' : '40px',
                    'bottom' : '150px'
                });
            });
        })
    });
    
    wrapper.css('left', direction); // once done moving out, will trigger the above event
}

function product_helper_wlc (obj) {
    var has_free_header = false;
    var has_free_type_area = false;
    for (var i = 0; i < obj._data().length; ++i) { // find a better way to do this
        if (obj._data()[i].type() == "free_header_text") 
            has_free_header = true;
        else if (obj._data()[i].type() == "free_type_text_area") 
            has_free_type_area = true;
    }
    
    if (!has_free_header)
        obj._data().push({"type" : ko.observable("free_header_text"), "content" : ko.observable("Free Header Placeholder")});
    if (!has_free_type_area)
        obj._data().push({"type" : ko.observable("free_type_text_area"), "content" : ko.observable("Free Type Text Area")});
}

/**
 * detect IE
 * returns version of IE or false, if browser is not Internet Explorer
 */
function detectIE() {
    var ua = window.navigator.userAgent;

    var msie = ua.indexOf('MSIE ');
    if (msie > 0) {
        // IE 10 or older => return version number
        return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
    }

    var trident = ua.indexOf('Trident/');
    if (trident > 0) {
        // IE 11 => return version number
        var rv = ua.indexOf('rv:');
        return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
    }

    var edge = ua.indexOf('Edge/');
    if (edge > 0) {
       // IE 12 => return version number
       return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
    }

    // other browser
    return false;
}

function detectAndroidChrome() {
    var ret = false;
    
    var ua = navigator.userAgent.toLowerCase();
    var isAndroid = ua.indexOf("android") > -1;
    
    if(isAndroid) {
        ret = true;
    }
    
    ret = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
    
    return ret;
}

function detectAndroidOrMacFirefox() {
    var ua, isAndroid, isMac;
    ua = navigator.userAgent.toLowerCase();
    isAndroid = ua.indexOf("android") > -1;
    isMac = navigator.platform === 'MacIntel';
    
    //log(navigator.userAgent.toLowerCase().indexOf('firefox') > -1 && isAndroid);
    return navigator.userAgent.toLowerCase().indexOf('firefox') > -1 && (isAndroid || isMac);
}


function product_helper_get_objective_content_by_type(type)
{
    for(var i = 0, len = viewModel._data().length; i < len; ++i)
    {
        if(viewModel._data()[i].type() == "objectives")
        {
            for(var k = 0, k_len = viewModel._data()[i].contents().length; k < k_len; ++k)
            {
                if(viewModel._data()[i].contents()[k].type() == type)
                {
                    return viewModel._data()[i].contents()[k].content();
                }
            }
        }
    }
    return "Not Selected";
}

// this needs to be called in post_ex_switch to fix MF1 respose container width
function product_helper_adjust_MF1_response_container() { 
    var exercise_model = viewModel.labs()[viewModel.selected_lab()].exercises()[viewModel.labs()[viewModel.selected_lab()].selected_exercise()];
    if (exercise_model.type() == "MF1" )
        exercise_model.dragdrop.adjust_response_container();
}

/*
    Checks the config file for any override templates for any specified template. Will return a list 
    off template numbers that exist. Will return an array of 1, if none are found.
    @exercise_type = The exercise type that will be searched in the config.
*/
function product_helper_get_override_templates(exercise_type)
{
    //Start array off at 1 for the default template
    var ret = [1];
    
    for (var i = 0; i < lesson_config_json.template_overrides.length; ++i)
    {
        //Check to see if the current type is the one we are searching for
        if (lesson_config_json.template_overrides[i].type == exercise_type)
        {
            //Merge the array from the config with ret
            ret = ret.concat(lesson_config_json.template_overrides[i].overrides)
            //Exit the loop since we found what we want
            break;
        }
    }
    
    //Return the final array of all available templates for the exercise
    return ret;
}

/*
    Checks the current question to see if it is a rec question or not.
    @_data = The question _data where the rec information is stored.
*/
function product_helper_check_rec_question(_data)
{
    var ret = false;

    //Loop through the question data 
    for (var d = 0; d < _data.length; ++d)
    {
        //Make sure it's question type, rec is only in a question
        if (_data[d].type() == "question")
        {
            for (var i = 0; i < _data[d].contents().length; ++i)
            {
                //Check to make sure it contains a rec
                if (_data[d].contents()[i].type() == "rec")
                    ret = true;
            }
        }
    }
    return ret;
}

// Handles highlighting and text scrolling for audio and video stimulus.
// Should be called as callback for media player's timeupdate event.
// obj = stimulus model, player = initiated mediaelementplayer object
function product_helper_av_text_events(obj, player) {
	//Update the position observable
	obj.player_pos(player.currentTime * 1000);

	//Get the current time
	var new_time = player.currentTime * 1000;

	var text_number_selecter = 0;

	if (obj.contents()[obj.slideshow_image_position()].value.images().length > 0)
	{
		//Check to see if we are past the first paragraph
		if (new_time >= obj.contents()[obj.slideshow_image_position()].value.images()[0].time())
		{
			for (i = 0 , i_len = obj.contents()[obj.slideshow_image_position()].value.images().length; i < i_len; ++i)
			{
				if(obj.contents()[obj.slideshow_image_position()].value.images()[i].time() < new_time)
				{
					text_number_selecter = obj.contents()[obj.slideshow_image_position()].value.images()[i].id();
				}
			}
			//Check to see if the last paragraph is selected. Exit since there is not one after
			if (obj.selected_audio_text() + 1 >= obj.contents()[obj.slideshow_image_position()].value.images().length)
			{
				if (new_time < obj.contents()[obj.slideshow_image_position()].value.images()[obj.selected_audio_text()].time())
				{
					obj.selected_audio_text(text_number_selecter -1);
					
					//$('.stimulus').animate({scrollTop: (obj.offset_top_scroll()-obj.offset_height_scroll()-100)+"px"});
					$('.video_text_wrapper').animate({scrollTop: (obj.offset_top_scroll()-obj.offset_height_scroll()-100)+"px"});
				}
				
				if (new_time >= (player.duration * 1000))
					// $('.stimulus').animate({scrollTop: "0px"});
					$('.video_text_wrapper').animate({scrollTop: "0px"});
			}
			//If the time is greater then the time of the next paragraph then change to that paragraph
			else if (new_time >= obj.contents()[obj.slideshow_image_position()].value.images()[obj.selected_audio_text() + 1].time())
			{
				obj.selected_audio_text(text_number_selecter);
				obj.scroll_setter();
				// $('.stimulus').animate({scrollTop: (obj.offset_top_scroll())+"px"});
				$('.video_text_wrapper').animate({scrollTop: (obj.offset_top_scroll())+"px"});
			}
			else if (new_time < obj.contents()[obj.slideshow_image_position()].value.images()[obj.selected_audio_text()].time())
			{
				obj.selected_audio_text(text_number_selecter);
				obj.scroll_setter();                                
				// $('.stimulus').animate({scrollTop: (obj.offset_top_scroll())+"px"});
				$('.video_text_wrapper').animate({scrollTop: (obj.offset_top_scroll())+"px"});
			}
		}
		else //Make sure it doesn't set on page load
		{
			obj.selected_audio_text(0);
		}
	}
}
